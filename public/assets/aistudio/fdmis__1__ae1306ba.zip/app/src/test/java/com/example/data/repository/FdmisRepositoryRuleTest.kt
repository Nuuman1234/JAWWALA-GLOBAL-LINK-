package com.example.data.repository

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.base.FirestoreEmulatorTestBase
import com.example.data.firebase.AuthRepository
import com.example.data.firebase.DirectoryRepository
import com.example.data.firebase.OperationsRepository
import com.example.data.local.OfficialDirectoryCatalog
import com.example.data.model.AccountStatus
import com.example.data.model.BvasStatus
import com.example.data.model.IncidentUrgency
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.model.VerificationStatus
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class FdmisRepositoryRuleTest : FirestoreEmulatorTestBase() {

    private suspend fun ensureAdminBootstrapped(email: String): UserAccount {
        val uid = signInTestUser(email)
        val authRepo = AuthRepository(firestore, auth)
        val existingSnap = withTimeout(TIMEOUT_MS) {
            firestore.collection("users").document(uid).get().await()
        }
        if (existingSnap.exists()) {
            return checkNotNull(existingSnap.toObject(UserAccount::class.java))
        }
        val lock = withTimeout(TIMEOUT_MS) { authRepo.getBootstrapLock().getOrThrow() }
        return if (lock == null) {
            withTimeout(TIMEOUT_MS) {
                authRepo.initializeFullControlAdmin("Chief Situation Admin", "08000000000").getOrThrow()
            }
        } else {
            checkNotNull(
                withTimeout(TIMEOUT_MS) { authRepo.ensureUserProfileOrCheckBootstrap("Staff User").getOrThrow() }
            )
        }
    }

    @Test
    fun fullWorkflow_preloadedDirectoryImportCorrectionCheckInIncidentAndResultVerification() = runBlocking {
        val uniqueSuffix = UUID.randomUUID().toString().take(6)
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dataset = OfficialDirectoryCatalog.loadFromContext(context)

        val adminAccount = ensureAdminBootstrapped("chief_admin@fdmis.test")
        val dirRepo = DirectoryRepository(firestore, auth)
        val opsRepo = OperationsRepository(firestore, null, auth)

        assertEquals(UserRole.FULL_CONTROL_ADMIN.name, adminAccount.role)

        // 1. Idempotent preloaded PDF directory import (11+11 wards, 298+177=475 PUs)
        val firstImport = withTimeout(IMPORT_TIMEOUT_MS) {
            dirRepo.importPreloadedOfficialDirectory(adminAccount, dataset).getOrThrow()
        }
        assertTrue(firstImport.countsVerified)
        assertEquals(298, firstImport.funtuaVerifiedInDatabase)
        assertEquals(177, firstImport.dandumeVerifiedInDatabase)
        assertEquals(475, firstImport.totalVerifiedInDatabase)
        assertEquals(0, firstImport.duplicateRecordsDetected)
        assertEquals(0, firstImport.invalidOrIncompleteRecords)

        // Running import a second time must be idempotent (0 newly added, still exact totals)
        val secondImport = withTimeout(IMPORT_TIMEOUT_MS) {
            dirRepo.importPreloadedOfficialDirectory(adminAccount, dataset).getOrThrow()
        }
        assertEquals(0, secondImport.totalNewlyImported)
        assertEquals(475, secondImport.totalVerifiedInDatabase)

        val targetPuDocId = "pu_20-07-01-001"
        val targetPu = withTimeout(FLOW_TIMEOUT_MS) {
            dirRepo.observePollingUnits(adminAccount).first { list -> list.any { it.id == targetPuDocId } }
        }.first { it.id == targetPuDocId }

        // 2. Controlled master-directory correction by Full Control Admin creates backup + audit log
        withTimeout(TIMEOUT_MS) {
            dirRepo.correctMasterPollingUnit(
                actor = adminAccount,
                pu = targetPu,
                correctedName = targetPu.name,
                correctedLocation = "Verified Central Mahuta Landmark",
                latitude = null,
                longitude = null,
                coordinatesVerified = false,
                registeredVoters = 650L,
                reason = "Updated verified registered voter count"
            ).getOrThrow()
        }
        val backups = withTimeout(TIMEOUT_MS) {
            firestore.collection("directory_backups").whereEqualTo("targetDocId", targetPuDocId).get().await()
        }
        assertFalse(backups.isEmpty)

        // 3. Register a field agent user (must land as PENDING_APPROVAL) & verify security denials
        val agentEmail = "agent_$uniqueSuffix@fdmis.test"
        signInTestUser(agentEmail)
        val pendingAgent = withTimeout(TIMEOUT_MS) {
            AuthRepository(firestore, auth).ensureUserProfileOrCheckBootstrap("Musa Agent").getOrThrow()
        }
        assertNotNull(pendingAgent)
        assertEquals(UserRole.PENDING.name, pendingAgent!!.role)
        assertEquals(AccountStatus.PENDING_APPROVAL.name, pendingAgent.status)

        var deniedForPending = false
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                dirRepo.observePollingUnits(
                    pendingAgent.copy(role = UserRole.FUNTUA_SUPER_ADMIN.name)
                ).first()
            }
        } catch (e: Exception) {
            val ffe = e.unwrapFirestoreException()
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, ffe?.code)
            deniedForPending = true
        }
        assertTrue(deniedForPending)

        // 4. Admin assigns agent to preloaded Dandume PU
        ensureAdminBootstrapped("chief_admin@fdmis.test")
        val updatedPu = withTimeout(FLOW_TIMEOUT_MS) {
            dirRepo.observePollingUnits(adminAccount).first { list -> list.any { it.id == targetPuDocId && it.registeredVoters == 650L } }
        }.first { it.id == targetPuDocId }

        withTimeout(TIMEOUT_MS) {
            dirRepo.assignAgentToPollingUnit(adminAccount, updatedPu, pendingAgent).getOrThrow()
        }

        // 5. Agent signs in, checks in, reports incident, and submits result
        signInTestUser(agentEmail)
        val activeAgent = withTimeout(TIMEOUT_MS) {
            AuthRepository(firestore, auth).ensureUserProfileOrCheckBootstrap().getOrThrow()!!
        }
        assertEquals(UserRole.POLLING_UNIT_AGENT.name, activeAgent.role)
        assertEquals(targetPuDocId, activeAgent.assignedPollingUnitId)

        withTimeout(TIMEOUT_MS) {
            opsRepo.submitCheckIn(
                actor = activeAgent,
                pu = updatedPu,
                arrivalTimeText = "07:55 AM",
                comments = "Materials arrived safely",
                batteryPercent = 88,
                networkStatus = "Mobile Data"
            ).getOrThrow()
        }

        val incId = withTimeout(TIMEOUT_MS) {
            opsRepo.submitIncident(
                actor = activeAgent,
                pu = updatedPu,
                lgaId = updatedPu.lgaId,
                wardId = updatedPu.wardId,
                title = "BVAS battery delay",
                category = "BVAS malfunction or technical problem",
                description = "Backup power bank connected to BVAS terminal",
                urgency = IncidentUrgency.MEDIUM
            ).getOrThrow()
        }
        assertTrue(incId.isNotBlank())

        val resultId = withTimeout(TIMEOUT_MS) {
            opsRepo.submitPollingUnitResult(
                actor = activeAgent,
                pu = updatedPu,
                registeredVoters = 650L,
                accreditedVoters = 420L,
                validVotes = 405L,
                rejectedVotes = 15L,
                bvasStatus = BvasStatus.FUNCTIONAL.label,
                bvasNotes = "Accreditation completed cleanly",
                submissionNotes = "Form EC8A signed by agents"
            ).getOrThrow()
        }

        // 6. Admin verifies & publishes result, and checks immutable history + audit logs
        ensureAdminBootstrapped("chief_admin@fdmis.test")
        val sub = withTimeout(FLOW_TIMEOUT_MS) {
            opsRepo.observeResults(adminAccount).first { list -> list.any { it.id == resultId } }
        }.first { it.id == resultId }

        withTimeout(TIMEOUT_MS) {
            opsRepo.reviewResultSubmission(
                actor = adminAccount,
                submission = sub,
                newStatus = VerificationStatus.VERIFIED,
                reviewNote = "Verified against Form EC8A",
                publishToPublic = true
            ).getOrThrow()
        }

        val history = withTimeout(TIMEOUT_MS) { opsRepo.getResultHistory(resultId).getOrThrow() }
        assertTrue(history.size >= 2)

        val logs = withTimeout(FLOW_TIMEOUT_MS) {
            dirRepo.observeAuditLogs(adminAccount).first { list ->
                list.any { it.action == "RESULT_VERIFIED" && it.affectedId == resultId }
            }
        }
        assertTrue(logs.any { it.action == "MASTER_DIRECTORY_PRELOADED" })
        assertTrue(logs.any { it.action == "MASTER_PU_CORRECTED" && it.affectedId == targetPuDocId })

        // 7. Unauthenticated caller is strictly denied
        auth.signOut()
        var unauthDenied = false
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                dirRepo.observePollingUnits(adminAccount).first()
            }
        } catch (e: Exception) {
            val ffe = e.unwrapFirestoreException()
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, ffe?.code)
            unauthDenied = true
        }
        assertTrue(unauthDenied)
    }

    private companion object {
        const val TIMEOUT_MS = 8000L
        const val IMPORT_TIMEOUT_MS = 25000L
        const val FLOW_TIMEOUT_MS = 5000L
    }
}
