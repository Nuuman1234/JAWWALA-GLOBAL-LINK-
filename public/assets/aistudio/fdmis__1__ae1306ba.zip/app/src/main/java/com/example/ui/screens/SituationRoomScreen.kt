package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HowToVote
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AuditLog
import com.example.data.model.IncidentReport
import com.example.data.model.IncidentUrgency
import com.example.data.model.LgaDefinition
import com.example.data.model.PollingUnit
import com.example.data.model.PuOperationalStatus
import com.example.data.model.ResultSubmission
import com.example.data.model.TimelineEvent
import com.example.data.model.UserAccount
import com.example.data.model.VerificationStatus
import com.example.data.model.Ward
import com.example.ui.components.CompactSyncBanner
import com.example.ui.components.EmptyOperationalState
import com.example.ui.components.KpiTile
import com.example.ui.components.LgaFilterBar
import com.example.ui.components.UrgencyBadge
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.AlertCritical
import com.example.ui.theme.AlertCriticalContainer
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CivicGoldContainer
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.OnCivicGoldContainer
import com.example.ui.theme.SoftGreySurface
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.WhiteBackground
import com.example.ui.viewmodel.SituationMetrics
import com.example.ui.viewmodel.SyncDashboardMetrics

@Composable
fun SituationRoomScreen(
    user: UserAccount,
    metrics: SituationMetrics,
    syncMetrics: SyncDashboardMetrics,
    wards: List<Ward>,
    pollingUnits: List<PollingUnit>,
    incidents: List<IncidentReport>,
    results: List<ResultSubmission>,
    timeline: List<TimelineEvent>,
    auditLogs: List<AuditLog>,
    selectedLgaId: String?,
    onSelectLga: (String?) -> Unit,
    onSyncNow: () -> Unit,
    onNavigateToDirectory: () -> Unit,
    onNavigateToFieldOps: () -> Unit,
    onNavigateToIncidents: () -> Unit,
    onNavigateToResults: () -> Unit,
    onNavigateToOpsHub: () -> Unit
) {
    val activeCriticalIncidents = incidents.filter {
        it.statusEnum.isActive() && it.urgency == IncidentUrgency.CRITICAL.name
    }
    val filteredWards = remember(wards, selectedLgaId) {
        wards.filter { selectedLgaId == null || it.lgaId == selectedLgaId }
            .sortedWith(compareBy({ it.lgaId }, { it.wardCode }))
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // White Mode Institutional Command Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_situation_banner),
                        contentDescription = "Situation Room Tactical Grid",
                        modifier = Modifier.matchParentSize(),
                        contentScale = ContentScale.Crop,
                        alpha = 0.06f
                    )
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .background(EmeraldPrimary)
                        )
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "2027 ELECTION SITUATION ROOM",
                                style = MonoCodeStyle,
                                color = EmeraldPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Funtua–Dandume Federal Constituency",
                                style = MaterialTheme.typography.headlineSmall,
                                color = EmeraldDeep
                            )
                            Text(
                                text = "Katsina State · ${user.roleEnum.label}" +
                                    if (user.assignedLgaId.isNotBlank()) " · ${user.assignedLgaId.uppercase()}" else "",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondaryLight
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(top = 4.dp)
                            ) {
                                Surface(
                                    color = EmeraldContainer,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "Live Verified Telemetry",
                                        style = MonoCodeStyle,
                                        color = EmeraldDeep,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                Surface(
                                    color = CivicGoldContainer,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "Master Directory: 22 Wards · 475 PUs",
                                        style = MonoCodeStyle,
                                        color = OnCivicGoldContainer,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Visible Offline-First & Synchronization Banner
        item {
            CompactSyncBanner(
                metrics = syncMetrics,
                onSyncNow = onSyncNow,
                onOpenSyncDashboard = onNavigateToFieldOps
            )
        }

        // Area Filter Bar
        item {
            LgaFilterBar(
                selectedLgaId = selectedLgaId,
                onSelectLga = onSelectLga,
                canViewAllLgas = user.roleEnum.canManageAllLgas()
            )
        }

        // Critical Incident Alert Banner (only shown when real critical incidents exist)
        if (activeCriticalIncidents.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AlertCriticalContainer),
                    border = BorderStroke(1.dp, AlertCritical)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Filled.Error, contentDescription = "Critical Alert", tint = AlertCritical)
                            Text(
                                text = "${activeCriticalIncidents.size} ACTIVE CRITICAL INCIDENT(S)",
                                style = MaterialTheme.typography.titleSmall,
                                color = AlertCritical,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        activeCriticalIncidents.take(2).forEach { inc ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(inc.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = AlertCritical)
                                    Text("${inc.puCode} · ${inc.lgaId.uppercase()}", style = MonoCodeStyle, color = AlertCritical.copy(alpha = 0.85f))
                                }
                                UrgencyBadge(inc.urgencyEnum)
                            }
                        }
                        Button(
                            onClick = onNavigateToIncidents,
                            colors = ButtonDefaults.buttonColors(containerColor = AlertCritical),
                            modifier = Modifier.testTag("critical_banner_review_btn")
                        ) {
                            Text("Review Critical Alerts")
                        }
                    }
                }
            }
        }

        // Core Situation Room KPI Grid (Zero Fake Data)
        item {
            Text("Operational Command Metrics", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    KpiTile("LGAs Covered", "${metrics.totalLgas}", "Official: 2 LGAs", EmeraldPrimary, Modifier.weight(1f))
                    KpiTile("Wards Registered", "${metrics.totalWardsRegistered}", "Official target: 22", EmeraldPrimary, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    KpiTile("PUs Registered", "${metrics.totalPollingUnitsRegistered}", "Official target: 475", EmeraldPrimary, Modifier.weight(1f), onNavigateToDirectory)
                    KpiTile("PUs Reporting", "${metrics.pollingUnitsReporting}", "Outstanding: ${metrics.pusOutstandingSubmission}", StatusVerified, Modifier.weight(1f), onNavigateToFieldOps)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    KpiTile("Agents Assigned", "${metrics.agentsAssigned}", "Checked in: ${metrics.agentsCheckedIn}", StatusInfo, Modifier.weight(1f), onNavigateToFieldOps)
                    KpiTile("Active Incidents", "${metrics.activeIncidents}", "Critical: ${metrics.criticalIncidents} · New: ${metrics.pendingIncidentReviews}", if (metrics.criticalIncidents > 0) AlertCritical else EmeraldPrimary, Modifier.weight(1f), onNavigateToIncidents)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    KpiTile("Results Pending", "${metrics.resultsPendingVerification}", "Total submitted: ${metrics.resultsSubmitted}", StatusInfo, Modifier.weight(1f), onNavigateToResults)
                    KpiTile("Results Verified", "${metrics.resultsVerified}", "Official EC8A verified", StatusVerified, Modifier.weight(1f), onNavigateToResults)
                }
            }
        }

        // Verified vs Unverified Submission Clarity Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SoftGreySurface),
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = EmeraldPrimary)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Verified vs Pending vs Outstanding Results",
                            style = MaterialTheme.typography.titleSmall,
                            color = EmeraldDeep
                        )
                        Text(
                            text = "Verified: ${metrics.resultsVerified} · Pending Verification: ${metrics.resultsPendingVerification} · Outstanding PUs: ${metrics.pusOutstandingSubmission}. Unverified field entries are excluded from public totals until approved.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryLight
                        )
                    }
                }
            }
        }

        // Official Constituency LGA Breakdown
        item {
            Text("Constituency LGA Breakdown", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
        }
        items(LgaDefinition.entries.filter { selectedLgaId == null || it.id == selectedLgaId }) { lga ->
            val lgaWards = wards.count { it.lgaId == lga.id }
            val lgaPus = pollingUnits.filter { it.lgaId == lga.id }
            val lgaReporting = lgaPus.count { it.statusEnum.isReporting() }
            val lgaResultsVerified = results.count { it.lgaId == lga.id && it.verificationEnum == VerificationStatus.VERIFIED }
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Filled.LocationCity, contentDescription = null, tint = EmeraldPrimary)
                            Column {
                                Text(lga.displayName, style = MaterialTheme.typography.titleMedium, color = TextPrimaryLight)
                                Text("LGA Code: ${lga.lgaCode}", style = MonoCodeStyle, color = TextSecondaryLight)
                            }
                        }
                        Text(
                            text = "${lgaPus.size} / ${lga.expectedPollingUnits} PUs",
                            style = MonoCodeStyle,
                            color = EmeraldPrimary
                        )
                    }
                    Text(
                        text = "Wards: $lgaWards / ${lga.expectedWards}  ·  Reporting: $lgaReporting  ·  Verified Results: $lgaResultsVerified",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryLight
                    )
                    if (lgaPus.isNotEmpty()) {
                        val progress = (lgaReporting.toFloat() / lgaPus.size.toFloat()).coerceIn(0f, 1f)
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = EmeraldPrimary,
                            trackColor = EmeraldContainer
                        )
                    }
                }
            }
        }

        // Ward-Level Reporting Progress
        if (filteredWards.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Ward-Level Reporting Progress (${filteredWards.size} Wards)", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
                        filteredWards.forEach { ward ->
                            val wardPus = pollingUnits.filter { it.wardId == ward.id }
                            val reporting = wardPus.count { it.statusEnum.isReporting() }
                            val verified = results.count { it.wardId == ward.id && it.verificationEnum == VerificationStatus.VERIFIED }
                            val totalExpected = wardPus.size.coerceAtLeast(1)
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${ward.name} (${ward.wardCode})",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextPrimaryLight,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = "Rep $reporting/${wardPus.size} · Ver $verified",
                                        style = MonoCodeStyle,
                                        color = EmeraldPrimary
                                    )
                                }
                                LinearProgressIndicator(
                                    progress = { (reporting.toFloat() / totalExpected.toFloat()).coerceIn(0f, 1f) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(4.dp)
                                        .clip(RoundedCornerShape(2.dp)),
                                    color = EmeraldPrimary,
                                    trackColor = SoftGreySurface
                                )
                            }
                        }
                    }
                }
            }
        }

        // Empty State or Real Operational Status Breakdown
        if (pollingUnits.isEmpty()) {
            item {
                EmptyOperationalState(
                    title = "Master directory sync pending.",
                    description = "Official wards and polling units for Funtua (11 wards, 298 PUs) and Dandume 20/07 (11 wards, 177 PUs) are preloaded and ready for verification sync in the Directory tab.",
                    icon = Icons.Filled.HowToVote,
                    actionLabel = "Open Directory",
                    onAction = onNavigateToDirectory
                )
            }
        } else {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Polling Unit Status Distribution", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
                        val grouped = pollingUnits.groupingBy { it.statusEnum }.eachCount()
                        grouped.entries.sortedByDescending { it.value }.forEach { (status, count) ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(status.label, style = MaterialTheme.typography.bodyMedium, color = TextPrimaryLight)
                                Text(
                                    "$count PU(s)",
                                    style = MonoCodeStyle,
                                    color = EmeraldPrimary
                                )
                            }
                            LinearProgressIndicator(
                                progress = { (count.toFloat() / pollingUnits.size.toFloat()).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(2.dp)),
                                color = if (status == PuOperationalStatus.INCIDENT_REPORTED) AlertCritical else EmeraldPrimary,
                                trackColor = SoftGreySurface
                            )
                        }
                    }
                }
            }
        }

        // Recent Election-Day Timeline Preview
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Live Election-Day Timeline", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
                OutlinedButton(onClick = onNavigateToOpsHub) {
                    Icon(Icons.Filled.Timeline, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Full Hub")
                }
            }
        }

        if (timeline.isEmpty()) {
            item {
                EmptyOperationalState(
                    title = "No election-day timeline events recorded yet.",
                    description = "Agent check-ins, polling unit status transitions, incidents, and result verifications appear here chronologically as field operations occur.",
                    icon = Icons.Filled.Timeline
                )
            }
        } else {
            items(timeline.take(5)) { event ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = when (event.eventType) {
                                "INCIDENT_REPORTED" -> Icons.Filled.ReportProblem
                                "RESULT_VERIFIED" -> Icons.Filled.CheckCircle
                                else -> Icons.Filled.Assessment
                            },
                            contentDescription = event.eventType,
                            tint = if (event.eventType == "INCIDENT_REPORTED") AlertCritical else EmeraldPrimary
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(event.title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryLight)
                            Text(event.description, style = MaterialTheme.typography.bodySmall, color = TextSecondaryLight)
                            Text("${formatTimestamp(event.createdAt)} · ${event.actorName}", style = MonoCodeStyle, color = TextSecondaryLight)
                        }
                    }
                }
            }
        }

        // Recent Administrative Activities (Full Control Admin only, backed by audit logs)
        if (user.roleEnum.canViewAuditLogs() && auditLogs.isNotEmpty()) {
            item {
                Text("Recent Administrative Activity", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
            }
            items(auditLogs.take(5), key = { "audit_${it.id}" }) { log ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SoftGreySurface),
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, tint = EmeraldPrimary)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(log.action, style = MonoCodeStyle, color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                            Text(log.details, style = MaterialTheme.typography.bodySmall, color = TextPrimaryLight)
                            Text("${log.actorName} · ${formatTimestamp(log.createdAt)}", style = MonoCodeStyle, color = TextSecondaryLight)
                        }
                    }
                }
            }
        }
    }
}
