package com.example.data.local

import android.content.Context
import org.json.JSONObject
import java.io.InputStream

data class OfficialWardRecord(
    val lgaId: String,
    val lgaCode: String,
    val wardCode: String,
    val name: String,
    val expectedPollingUnits: Int
) {
    val docId: String
        get() = "${lgaId}_${wardCode.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")}"
}

data class OfficialPuRecord(
    val lgaId: String,
    val wardCode: String,
    val wardName: String,
    val puCode: String,
    val name: String,
    val status: String
) {
    val wardDocId: String
        get() = "${lgaId}_${wardCode.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")}"

    val docId: String
        get() = "pu_${puCode.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")}"
}

data class OfficialDirectoryDataset(
    val datasetVersion: String,
    val verificationAdvisories: List<String>,
    val wards: List<OfficialWardRecord>,
    val pollingUnits: List<OfficialPuRecord>
)

data class DirectoryValidationReport(
    val datasetVersion: String,
    val funtuaWardCount: Int,
    val dandumeWardCount: Int,
    val funtuaPuCount: Int,
    val dandumePuCount: Int,
    val totalPuCount: Int,
    val duplicateCodeCount: Int,
    val duplicateCodes: List<String>,
    val invalidOrIncompleteCount: Int,
    val invalidReasons: List<String>,
    val advisoryRecordCount: Int,
    val advisories: List<String>,
    val isValid: Boolean
)

object OfficialDirectoryCatalog {
    private const val ASSET_FILE_NAME = "official_pu_directory.json"
    private val ADVISORY_PU_CODES = listOf(
        "20-14-02-009",
        "20-14-02-010",
        "20-14-03-015",
        "20-14-06-012",
        "20-14-06-014",
        "20-14-06-015",
        "20-14-09-008",
        "20-07-01-003",
        "20-07-05-007",
        "20-07-09-003"
    )

    fun loadFromContext(context: Context): OfficialDirectoryDataset {
        return context.assets.open(ASSET_FILE_NAME).use { loadFromInputStream(it) }
    }

    fun loadFromInputStream(stream: InputStream): OfficialDirectoryDataset {
        val rawJson = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        val root = JSONObject(rawJson)
        val version = root.optString("datasetVersion", "2027-official-pdf-v1")

        val advisoriesArr = root.optJSONArray("verificationAdvisories")
        val advisories = buildList {
            if (advisoriesArr != null) {
                for (i in 0 until advisoriesArr.length()) {
                    add(advisoriesArr.optString(i))
                }
            }
        }

        val wardsArr = root.getJSONArray("wards")
        val wards = buildList {
            for (i in 0 until wardsArr.length()) {
                val obj = wardsArr.getJSONObject(i)
                add(
                    OfficialWardRecord(
                        lgaId = obj.getString("lgaId"),
                        lgaCode = obj.getString("lgaCode"),
                        wardCode = obj.getString("wardCode"),
                        name = obj.getString("name"),
                        expectedPollingUnits = obj.getInt("expectedPollingUnits")
                    )
                )
            }
        }

        val pusArr = root.getJSONArray("pollingUnits")
        val pus = buildList {
            for (i in 0 until pusArr.length()) {
                val obj = pusArr.getJSONObject(i)
                add(
                    OfficialPuRecord(
                        lgaId = obj.getString("lgaId"),
                        wardCode = obj.getString("wardCode"),
                        wardName = obj.getString("wardName"),
                        puCode = obj.getString("puCode"),
                        name = obj.getString("name"),
                        status = obj.optString("status", "EXISTING PU")
                    )
                )
            }
        }

        return OfficialDirectoryDataset(
            datasetVersion = version,
            verificationAdvisories = advisories,
            wards = wards,
            pollingUnits = pus
        )
    }

    fun validate(dataset: OfficialDirectoryDataset): DirectoryValidationReport {
        val funtuaWards = dataset.wards.filter { it.lgaId == "funtua" }
        val dandumeWards = dataset.wards.filter { it.lgaId == "dandume" }
        val funtuaPus = dataset.pollingUnits.filter { it.lgaId == "funtua" }
        val dandumePus = dataset.pollingUnits.filter { it.lgaId == "dandume" }

        val wardKeys = dataset.wards.associateBy { "${it.lgaId}:${it.wardCode}" }
        val invalidReasons = mutableListOf<String>()

        dataset.wards.forEachIndexed { idx, w ->
            if (w.lgaId !in listOf("funtua", "dandume") || w.wardCode.isBlank() || w.name.isBlank()) {
                invalidReasons.add("Ward #$idx has blank required field or unknown LGA: ${w.lgaId}/${w.wardCode}")
            }
        }

        val codeCounts = mutableMapOf<String, Int>()
        dataset.pollingUnits.forEachIndexed { idx, pu ->
            if (pu.puCode.isBlank() || pu.name.isBlank() || pu.wardCode.isBlank() || pu.wardName.isBlank()) {
                invalidReasons.add("PU #$idx missing required code/name/ward")
            }
            if (!wardKeys.containsKey("${pu.lgaId}:${pu.wardCode}")) {
                invalidReasons.add("PU ${pu.puCode} references missing ward ${pu.lgaId}:${pu.wardCode}")
            }
            if (pu.lgaId == "funtua" && !pu.puCode.startsWith("20-14-")) {
                invalidReasons.add("Funtua PU ${pu.puCode} has unexpected prefix")
            }
            if (pu.lgaId == "dandume" && !pu.puCode.startsWith("20-07-")) {
                invalidReasons.add("Dandume PU ${pu.puCode} has unexpected prefix")
            }
            codeCounts[pu.puCode] = (codeCounts[pu.puCode] ?: 0) + 1
        }

        dataset.wards.forEach { w ->
            val actualCount = dataset.pollingUnits.count { it.lgaId == w.lgaId && it.wardCode == w.wardCode }
            if (actualCount != w.expectedPollingUnits) {
                invalidReasons.add("Ward ${w.wardCode} (${w.name}) expected ${w.expectedPollingUnits} PUs, found $actualCount")
            }
        }

        val duplicates = codeCounts.filterValues { it > 1 }.keys.toList()
        val advisoryMatches = dataset.pollingUnits.count { it.puCode in ADVISORY_PU_CODES }

        val valid = funtuaWards.size == 11 &&
            dandumeWards.size == 11 &&
            funtuaPus.size == 298 &&
            dandumePus.size == 177 &&
            dataset.pollingUnits.size == 475 &&
            duplicates.isEmpty() &&
            invalidReasons.isEmpty()

        return DirectoryValidationReport(
            datasetVersion = dataset.datasetVersion,
            funtuaWardCount = funtuaWards.size,
            dandumeWardCount = dandumeWards.size,
            funtuaPuCount = funtuaPus.size,
            dandumePuCount = dandumePus.size,
            totalPuCount = dataset.pollingUnits.size,
            duplicateCodeCount = duplicates.size,
            duplicateCodes = duplicates,
            invalidOrIncompleteCount = invalidReasons.size,
            invalidReasons = invalidReasons,
            advisoryRecordCount = advisoryMatches,
            advisories = dataset.verificationAdvisories,
            isValid = valid
        )
    }

    fun toScopedWards(
        dataset: OfficialDirectoryDataset,
        lgaIdFilter: String?
    ): List<com.example.data.model.Ward> {
        return dataset.wards
            .filter { lgaIdFilter.isNullOrBlank() || it.lgaId == lgaIdFilter }
            .map { w ->
                com.example.data.model.Ward(
                    id = w.docId,
                    lgaId = w.lgaId,
                    wardCode = w.wardCode,
                    name = w.name,
                    expectedPollingUnits = w.expectedPollingUnits.toLong(),
                    isTestData = false
                )
            }
            .sortedWith(compareBy({ it.lgaId }, { it.wardCode }, { it.name }))
    }

    fun toScopedPollingUnits(
        dataset: OfficialDirectoryDataset,
        user: com.example.data.model.UserAccount
    ): List<com.example.data.model.PollingUnit> {
        val allowed = dataset.pollingUnits.filter { pu ->
            when (user.roleEnum) {
                com.example.data.model.UserRole.FULL_CONTROL_ADMIN -> true
                com.example.data.model.UserRole.FUNTUA_SUPER_ADMIN -> pu.lgaId == "funtua"
                com.example.data.model.UserRole.DANDUME_SUPER_ADMIN -> pu.lgaId == "dandume"
                com.example.data.model.UserRole.WARD_COORDINATOR ->
                    user.assignedWardId.isNotBlank() && pu.wardDocId == user.assignedWardId
                com.example.data.model.UserRole.POLLING_UNIT_AGENT ->
                    user.assignedPollingUnitId.isNotBlank() && pu.docId == user.assignedPollingUnitId
                com.example.data.model.UserRole.PENDING -> false
            }
        }
        return allowed.map { pu ->
            com.example.data.model.PollingUnit(
                id = pu.docId,
                lgaId = pu.lgaId,
                wardId = pu.wardDocId,
                wardName = pu.wardName,
                puCode = pu.puCode,
                name = pu.name,
                locationDescription = "${pu.wardName} Ward · ${pu.status}",
                puStatusLabel = pu.status,
                isMasterRecord = true,
                isTestData = false
            )
        }.sortedWith(compareBy({ it.lgaId }, { it.wardName }, { it.puCode }))
    }
}

