package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// White Mode Only — Authoritative FDMIS Institutional Light Palette
val WhiteBackground = Color(0xFFFFFFFF)
val SoftGreySurface = Color(0xFFF5F7F6)
val SoftGreyVariant = Color(0xFFECEFED)
val BorderLight = Color(0xFFE2E8E5)

val EmeraldPrimary = Color(0xFF087A55)
val EmeraldDeep = Color(0xFF14532D)
val EmeraldDark = Color(0xFF14532D)
val EmeraldContainer = Color(0xFFE6F4EF)
val OnEmeraldContainer = Color(0xFF14532D)

val CivicGold = Color(0xFFC69A35)
val CivicGoldLight = Color(0xFFE6C56B)
val CivicGoldContainer = Color(0xFFFBF5E4)
val OnCivicGoldContainer = Color(0xFF5C4308)

val SlateNeutral = Color(0xFF43524C)
val SlateContainer = Color(0xFFEAF0ED)
val OnSlateContainer = Color(0xFF17211D)

val SurfaceLight = WhiteBackground
val SurfaceCardLight = WhiteBackground
val SurfaceVariantLight = SoftGreySurface
val OutlineLight = BorderLight
val TextPrimaryLight = Color(0xFF17211D)
val TextSecondaryLight = Color(0xFF64716B)

// Operational Alert & Status Semantic Colors (paired with text + icons)
val AlertCritical = Color(0xFFDC2626)
val AlertCriticalContainer = Color(0xFFFEE2E2)
val AlertHigh = Color(0xFFD97706)
val AlertHighContainer = Color(0xFFFFEDD5)
val AlertWarning = Color(0xFFD97706)
val AlertWarningContainer = Color(0xFFFEF3C7)
val StatusVerified = Color(0xFF15803D)
val StatusVerifiedContainer = Color(0xFFDCFCE7)
val StatusInfo = Color(0xFF2563EB)
val StatusInfoContainer = Color(0xFFEFF6FF)
