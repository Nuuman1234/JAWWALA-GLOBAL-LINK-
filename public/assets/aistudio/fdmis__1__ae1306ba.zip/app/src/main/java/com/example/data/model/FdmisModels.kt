package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class LgaDefinition(
    val id: String,
    val displayName: String,
    val lgaCode: String,
    val expectedWards: Int,
    val expectedPollingUnits: Int
) {
    FUNTUA(
        id = "funtua",
        displayName = "Funtua LGA",
        lgaCode = "20-14",
        expectedWards = 11,
        expectedPollingUnits = 298
    ),
    DANDUME(
        id = "dandume",
        displayName = "Dandume LGA",
        lgaCode = "20/07",
        expectedWards = 11,
        expectedPollingUnits = 177
    );

    companion object {
        fun fromId(id: String): LgaDefinition? = entries.find { it.id == id }
        val totalExpectedWards: Int = entries.sumOf { it.expectedWards }
        val totalExpectedPollingUnits: Int = entries.sumOf { it.expectedPollingUnits }
    }
}

enum class UserRole(val label: String, val shortLabel: String) {
    FULL_CONTROL_ADMIN("Full Control Admin", "Full Admin"),
    FUNTUA_SUPER_ADMIN("Funtua Super Admin", "Funtua Admin"),
    DANDUME_SUPER_ADMIN("Dandume Super Admin", "Dandume Admin"),
    WARD_COORDINATOR("Ward Coordinator", "Ward Coord"),
    POLLING_UNIT_AGENT("Polling Unit Agent", "PU Agent"),
    PENDING("Pending Assignment", "Pending");

    fun canManageUsers(): Boolean = this == FULL_CONTROL_ADMIN || this == FUNTUA_SUPER_ADMIN || this == DANDUME_SUPER_ADMIN
    fun canManageAllLgas(): Boolean = this == FULL_CONTROL_ADMIN
    fun canManageDirectory(): Boolean = this == FULL_CONTROL_ADMIN || this == FUNTUA_SUPER_ADMIN || this == DANDUME_SUPER_ADMIN
    fun canCorrectMasterDirectory(): Boolean = this == FULL_CONTROL_ADMIN
    fun canAssignFieldUsers(): Boolean = this == FULL_CONTROL_ADMIN || this == FUNTUA_SUPER_ADMIN || this == DANDUME_SUPER_ADMIN || this == WARD_COORDINATOR
    fun canVerifyResults(): Boolean = this == FULL_CONTROL_ADMIN || this == FUNTUA_SUPER_ADMIN || this == DANDUME_SUPER_ADMIN
    fun canApprovePublicResults(): Boolean = this == FULL_CONTROL_ADMIN
    fun canViewAuditLogs(): Boolean = this == FULL_CONTROL_ADMIN
    fun canManageSettings(): Boolean = this == FULL_CONTROL_ADMIN
    fun canReviewIncidents(): Boolean = this != POLLING_UNIT_AGENT && this != PENDING

    companion object {
        fun fromString(value: String): UserRole = entries.find { it.name == value } ?: PENDING
    }
}

enum class AccountStatus(val label: String) {
    ACTIVE("Active"),
    PENDING_APPROVAL("Pending Approval"),
    SUSPENDED("Suspended / Revoked");

    companion object {
        fun fromString(value: String): AccountStatus = entries.find { it.name == value } ?: PENDING_APPROVAL
    }
}

enum class PuOperationalStatus(val label: String, val stepOrder: Int) {
    NOT_STARTED("Not Started", 0),
    AGENT_ASSIGNED("Agent Assigned", 1),
    AGENT_CHECKED_IN("Agent Checked In", 2),
    MATERIALS_ARRIVED("Election Materials Arrived", 3),
    VOTING_STARTED("Voting Started", 4),
    VOTING_IN_PROGRESS("Voting In Progress", 5),
    VOTING_COMPLETED("Voting Completed", 6),
    COUNTING_STARTED("Result Counting Started", 7),
    RESULT_SUBMITTED("Result Submitted", 8),
    RESULT_UNDER_REVIEW("Result Under Review", 9),
    RESULT_VERIFIED("Result Verified", 10),
    INCIDENT_REPORTED("Incident Reported", 11),
    COMMUNICATION_LOST("Communication Lost", 12);

    fun isReporting(): Boolean = this != NOT_STARTED && this != AGENT_ASSIGNED && this != COMMUNICATION_LOST

    companion object {
        fun fromString(value: String): PuOperationalStatus = entries.find { it.name == value } ?: NOT_STARTED
    }
}

enum class IncidentCategory(val label: String) {
    LATE_MATERIALS("Late arrival of election materials"),
    MISSING_MATERIALS("Missing election materials"),
    SECURITY_CONCERN("Security concern"),
    VIOLENCE_THREAT("Violence or threat"),
    ELECTORAL_MALPRACTICE("Electoral malpractice allegation"),
    BVAS_MALFUNCTION("BVAS malfunction or technical problem"),
    OFFICIALS_ABSENT("Absence or extreme lateness of election officials"),
    AGENT_ACCESS("Agent access problem"),
    VOTER_ISSUE("Voter-related issue"),
    RESULT_ISSUE("Result-related issue"),
    COMMUNICATION_PROBLEM("Communication problem"),
    OTHER("Other")
}

enum class IncidentUrgency(val label: String) {
    LOW("Low"),
    MEDIUM("Medium"),
    HIGH("High"),
    CRITICAL("Critical");

    companion object {
        fun fromString(value: String): IncidentUrgency = entries.find { it.name == value } ?: LOW
    }
}

enum class IncidentStatus(val label: String) {
    NEW("New"),
    UNDER_REVIEW("Under Review"),
    ESCALATED("Escalated"),
    RESOLVED("Resolved"),
    CLOSED("Closed");

    fun isActive(): Boolean = this == NEW || this == UNDER_REVIEW || this == ESCALATED

    companion object {
        fun fromString(value: String): IncidentStatus = entries.find { it.name == value } ?: NEW
    }
}

enum class VerificationStatus(val label: String) {
    DRAFT("Draft"),
    SUBMITTED("Submitted"),
    UNDER_REVIEW("Under Review"),
    VERIFIED("Verified"),
    REJECTED("Rejected"),
    REQUIRES_CORRECTION("Requires Correction");

    companion object {
        fun fromString(value: String): VerificationStatus = entries.find { it.name == value } ?: SUBMITTED
    }
}

enum class BvasStatus(val label: String) {
    FUNCTIONAL("BVAS Functional"),
    SLOW_ACCREDITATION("Slow Accreditation"),
    MALFUNCTION("BVAS Malfunction"),
    REPLACED("BVAS Replaced"),
    NOT_APPLICABLE("Not Reported")
}

@IgnoreExtraProperties
data class BootstrapLock(
    @DocumentId val id: String = "",
    val initializedByUid: String = "",
    val initializedByEmail: String = "",
    val cycleYear: Long = 2027L,
    val constituencyName: String = "Funtua-Dandume Federal Constituency",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class GlobalSettings(
    @DocumentId val id: String = "",
    val inactivityTimeoutMinutes: Long = 30L,
    val mfaPrepared: Boolean = true,
    val publicSummaryEnabled: Boolean = true,
    val smsFallbackConfigured: Boolean = false,
    val whatsappConfigured: Boolean = false,
    val emailConfigured: Boolean = false,
    val updatedByUid: String = "",
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class UserAccount(
    @DocumentId val id: String = "",
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val phone: String? = null,
    val role: String = UserRole.PENDING.name,
    val status: String = AccountStatus.PENDING_APPROVAL.name,
    val assignedLgaId: String = "",
    val assignedWardId: String = "",
    val assignedPollingUnitId: String = "",
    val sessionRevoked: Boolean = false,
    val revokedReason: String? = null,
    @ServerTimestamp val lastLoginAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val roleEnum: UserRole get() = UserRole.fromString(role)
    val statusEnum: AccountStatus get() = AccountStatus.fromString(status)
    val isAuthorizedActive: Boolean get() = statusEnum == AccountStatus.ACTIVE && !sessionRevoked && roleEnum != UserRole.PENDING
}

@IgnoreExtraProperties
data class Ward(
    @DocumentId val id: String = "",
    val lgaId: String = "",
    val wardCode: String = "",
    val name: String = "",
    val coordinatorUid: String = "",
    val coordinatorName: String = "",
    val expectedPollingUnits: Long = 0L,
    val isTestData: Boolean = false,
    val createdByUid: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PollingUnit(
    @DocumentId val id: String = "",
    val lgaId: String = "",
    val wardId: String = "",
    val wardName: String = "",
    val puCode: String = "",
    val name: String = "",
    val locationDescription: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val coordinatesVerified: Boolean = false,
    val assignedAgentUid: String = "",
    val assignedAgentName: String = "",
    val operationalStatus: String = PuOperationalStatus.NOT_STARTED.name,
    val registeredVoters: Long = 0L,
    val puStatusLabel: String = "EXISTING PU",
    val isMasterRecord: Boolean = true,
    val isTestData: Boolean = false,
    val createdByUid: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val statusEnum: PuOperationalStatus get() = PuOperationalStatus.fromString(operationalStatus)
}

@IgnoreExtraProperties
data class DirectoryBackup(
    @DocumentId val id: String = "",
    val entityType: String = "polling_units",
    val targetDocId: String = "",
    val lgaId: String = "",
    val puCode: String = "",
    val previousName: String = "",
    val previousLocationDescription: String = "",
    val previousRegisteredVoters: Long = 0L,
    val previousCoordinatesVerified: Boolean = false,
    val previousLatitude: Double? = null,
    val previousLongitude: Double? = null,
    val correctionReason: String = "",
    val backedUpByUid: String = "",
    val backedUpByEmail: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

data class DirectoryImportSummary(
    val datasetVersion: String,
    val funtuaNewlyImported: Int,
    val dandumeNewlyImported: Int,
    val totalNewlyImported: Int,
    val funtuaVerifiedInDatabase: Int,
    val dandumeVerifiedInDatabase: Int,
    val totalVerifiedInDatabase: Int,
    val duplicateRecordsDetected: Int,
    val invalidOrIncompleteRecords: Int,
    val recordsRequiringManualVerification: Int,
    val advisories: List<String>,
    val countsVerified: Boolean
)

@IgnoreExtraProperties
data class AgentCheckIn(
    @DocumentId val id: String = "",
    val puId: String = "",
    val puCode: String = "",
    val puName: String = "",
    val lgaId: String = "",
    val wardId: String = "",
    val agentUid: String = "",
    val agentName: String = "",
    val arrivalTimeText: String = "",
    val comments: String = "",
    val batteryPercent: Long = -1L,
    val networkStatus: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val clientSubmissionId: String = "",
    val isTestData: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class IncidentReport(
    @DocumentId val id: String = "",
    val title: String = "",
    val category: String = "",
    val description: String = "",
    val urgency: String = IncidentUrgency.MEDIUM.name,
    val status: String = IncidentStatus.NEW.name,
    val lgaId: String = "",
    val wardId: String = "",
    val puId: String = "",
    val puCode: String = "",
    val puName: String = "",
    val reporterUid: String = "",
    val reporterName: String = "",
    val evidenceBase64: String? = null,
    val evidenceFileName: String? = null,
    val internalNotes: String = "",
    val escalatedTo: String = "",
    val reviewedByUid: String = "",
    val clientSubmissionId: String = "",
    val isTestData: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val urgencyEnum: IncidentUrgency get() = IncidentUrgency.fromString(urgency)
    val statusEnum: IncidentStatus get() = IncidentStatus.fromString(status)
}

@IgnoreExtraProperties
data class ResultSubmission(
    @DocumentId val id: String = "",
    val puId: String = "",
    val puCode: String = "",
    val puName: String = "",
    val lgaId: String = "",
    val wardId: String = "",
    val wardName: String = "",
    val submittedByUid: String = "",
    val submittedByName: String = "",
    val registeredVoters: Long = 0L,
    val accreditedVoters: Long = 0L,
    val validVotes: Long = 0L,
    val rejectedVotes: Long = 0L,
    val totalVotesCast: Long = 0L,
    val bvasStatus: String = BvasStatus.FUNCTIONAL.label,
    val bvasNotes: String = "",
    val submissionNotes: String = "",
    val ec8aImageBase64: String? = null,
    val ec8aFileName: String? = null,
    val verificationStatus: String = VerificationStatus.SUBMITTED.name,
    val publiclyApproved: Boolean = false,
    val reviewNote: String = "",
    val reviewedByUid: String = "",
    val reviewedByName: String = "",
    val version: Long = 1L,
    val clientSubmissionId: String = "",
    val isTestData: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val verificationEnum: VerificationStatus get() = VerificationStatus.fromString(verificationStatus)
}

@IgnoreExtraProperties
data class ResultHistoryEntry(
    @DocumentId val id: String = "",
    val action: String = "",
    val previousStatus: String = "",
    val newStatus: String = "",
    val note: String = "",
    val actorUid: String = "",
    val actorName: String = "",
    val registeredVoters: Long = 0L,
    val accreditedVoters: Long = 0L,
    val validVotes: Long = 0L,
    val rejectedVotes: Long = 0L,
    val totalVotesCast: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PublicVerifiedResult(
    @DocumentId val id: String = "",
    val puCode: String = "",
    val puName: String = "",
    val wardName: String = "",
    val lgaId: String = "",
    val registeredVoters: Long = 0L,
    val accreditedVoters: Long = 0L,
    val validVotes: Long = 0L,
    val rejectedVotes: Long = 0L,
    val totalVotesCast: Long = 0L,
    val approvedByUid: String = "",
    @ServerTimestamp val verifiedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class TimelineEvent(
    @DocumentId val id: String = "",
    val eventType: String = "",
    val title: String = "",
    val description: String = "",
    val lgaId: String = "",
    val wardId: String = "",
    val puId: String = "",
    val puCode: String = "",
    val actorUid: String = "",
    val actorName: String = "",
    val isTestData: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class NotificationItem(
    @DocumentId val id: String = "",
    val title: String = "",
    val body: String = "",
    val type: String = "",
    val targetLgaId: String = "all",
    val targetWardId: String = "",
    val isCritical: Boolean = false,
    val createdByUid: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AuditLog(
    @DocumentId val id: String = "",
    val actorUid: String = "",
    val actorName: String = "",
    val actorEmail: String = "",
    val actorRole: String = "",
    val action: String = "",
    val affectedEntity: String = "",
    val affectedId: String = "",
    val details: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)
