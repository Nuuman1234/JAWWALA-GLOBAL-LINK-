package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "fdmis_session_prefs")

class SessionPreferences(private val context: Context) {
    private val keyLastActiveMs = longPreferencesKey("last_active_ms")
    private val keyShowTestData = booleanPreferencesKey("show_test_data")

    val lastActiveMillis: Flow<Long> = context.dataStore.data.map { prefs ->
        prefs[keyLastActiveMs] ?: 0L
    }

    val showTestData: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[keyShowTestData] ?: false
    }

    fun observeLastSuccessfulSyncMillis(uid: String): Flow<Long> {
        val key = longPreferencesKey("last_sync_ms_$uid")
        return context.dataStore.data.map { prefs -> prefs[key] ?: 0L }
    }

    suspend fun recordActivity(timestampMillis: Long = System.currentTimeMillis()) {
        context.dataStore.edit { prefs ->
            prefs[keyLastActiveMs] = timestampMillis
        }
    }

    suspend fun recordSuccessfulSync(uid: String, timestampMillis: Long = System.currentTimeMillis()) {
        val key = longPreferencesKey("last_sync_ms_$uid")
        context.dataStore.edit { prefs ->
            prefs[key] = timestampMillis
        }
    }

    suspend fun setShowTestData(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[keyShowTestData] = enabled
        }
    }
}
