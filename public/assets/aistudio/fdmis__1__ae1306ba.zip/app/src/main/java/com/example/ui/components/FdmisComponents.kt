package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Pending
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.IncidentUrgency
import com.example.data.model.LgaDefinition
import com.example.data.model.PollingUnit
import com.example.data.model.PuOperationalStatus
import com.example.data.model.VerificationStatus
import com.example.ui.theme.AlertCritical
import com.example.ui.theme.AlertCriticalContainer
import com.example.ui.theme.AlertHigh
import com.example.ui.theme.AlertHighContainer
import com.example.ui.theme.AlertWarning
import com.example.ui.theme.AlertWarningContainer
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CivicGold
import com.example.ui.theme.CivicGoldContainer
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.MonoMetricStyle
import com.example.ui.theme.OnCivicGoldContainer
import com.example.ui.theme.SoftGreySurface
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusInfoContainer
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.StatusVerifiedContainer
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.WhiteBackground
import com.example.util.ImageCompression
import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun StatusBadge(
    label: String,
    icon: ImageVector,
    containerColor: Color,
    contentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = containerColor,
        contentColor = contentColor,
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun UrgencyBadge(urgency: IncidentUrgency) {
    when (urgency) {
        IncidentUrgency.CRITICAL -> StatusBadge(
            label = "CRITICAL",
            icon = Icons.Filled.Error,
            containerColor = AlertCriticalContainer,
            contentColor = AlertCritical
        )
        IncidentUrgency.HIGH -> StatusBadge(
            label = "HIGH",
            icon = Icons.Filled.Warning,
            containerColor = AlertHighContainer,
            contentColor = AlertHigh
        )
        IncidentUrgency.MEDIUM -> StatusBadge(
            label = "MEDIUM",
            icon = Icons.Filled.ReportProblem,
            containerColor = AlertWarningContainer,
            contentColor = AlertWarning
        )
        IncidentUrgency.LOW -> StatusBadge(
            label = "LOW",
            icon = Icons.Filled.Info,
            containerColor = StatusInfoContainer,
            contentColor = StatusInfo
        )
    }
}

@Composable
fun VerificationBadge(status: VerificationStatus) {
    when (status) {
        VerificationStatus.VERIFIED -> StatusBadge(
            label = status.label,
            icon = Icons.Filled.CheckCircle,
            containerColor = StatusVerifiedContainer,
            contentColor = StatusVerified
        )
        VerificationStatus.UNDER_REVIEW -> StatusBadge(
            label = status.label,
            icon = Icons.Filled.Pending,
            containerColor = StatusInfoContainer,
            contentColor = StatusInfo
        )
        VerificationStatus.SUBMITTED -> StatusBadge(
            label = status.label,
            icon = Icons.Filled.Info,
            containerColor = CivicGoldContainer,
            contentColor = OnCivicGoldContainer
        )
        VerificationStatus.REQUIRES_CORRECTION -> StatusBadge(
            label = status.label,
            icon = Icons.Filled.Warning,
            containerColor = AlertHighContainer,
            contentColor = AlertHigh
        )
        VerificationStatus.REJECTED -> StatusBadge(
            label = status.label,
            icon = Icons.Filled.Error,
            containerColor = AlertCriticalContainer,
            contentColor = AlertCritical
        )
        VerificationStatus.DRAFT -> StatusBadge(
            label = status.label,
            icon = Icons.Filled.Pending,
            containerColor = SoftGreySurface,
            contentColor = TextSecondaryLight
        )
    }
}

@Composable
fun PuStatusBadge(status: PuOperationalStatus) {
    val (bg, fg, icon) = when (status) {
        PuOperationalStatus.RESULT_VERIFIED -> Triple(StatusVerifiedContainer, StatusVerified, Icons.Filled.CheckCircle)
        PuOperationalStatus.INCIDENT_REPORTED, PuOperationalStatus.COMMUNICATION_LOST ->
            Triple(AlertCriticalContainer, AlertCritical, Icons.Filled.Warning)
        PuOperationalStatus.RESULT_SUBMITTED, PuOperationalStatus.RESULT_UNDER_REVIEW ->
            Triple(StatusInfoContainer, StatusInfo, Icons.Filled.Info)
        PuOperationalStatus.VOTING_STARTED, PuOperationalStatus.VOTING_IN_PROGRESS,
        PuOperationalStatus.VOTING_COMPLETED, PuOperationalStatus.COUNTING_STARTED ->
            Triple(EmeraldContainer, EmeraldDeep, Icons.Filled.CheckCircle)
        PuOperationalStatus.AGENT_CHECKED_IN, PuOperationalStatus.MATERIALS_ARRIVED ->
            Triple(CivicGoldContainer, OnCivicGoldContainer, Icons.Filled.LocationOn)
        else -> Triple(SoftGreySurface, TextSecondaryLight, Icons.Filled.Pending)
    }
    StatusBadge(label = status.label, icon = icon, containerColor = bg, contentColor = fg)
}

@Composable
fun KpiTile(
    title: String,
    value: String,
    subtitle: String? = null,
    accentColor: Color = EmeraldPrimary,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Card(
        modifier = modifier
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        colors = CardDefaults.cardColors(containerColor = WhiteBackground),
        border = BorderStroke(1.dp, BorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .width(26.dp)
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(accentColor)
            )
            Text(
                text = value,
                style = MonoMetricStyle,
                color = TextPrimaryLight
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimaryLight,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryLight,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun LgaFilterBar(
    selectedLgaId: String?,
    onSelectLga: (String?) -> Unit,
    canViewAllLgas: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (canViewAllLgas) {
            FilterChip(
                selected = selectedLgaId == null,
                onClick = { onSelectLga(null) },
                label = { Text("All Areas (2 LGAs)") },
                modifier = Modifier.testTag("filter_lga_all"),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldPrimary,
                    selectedLabelColor = Color.White,
                    containerColor = SoftGreySurface
                )
            )
        }
        LgaDefinition.entries.forEach { lga ->
            FilterChip(
                selected = selectedLgaId == lga.id,
                onClick = { onSelectLga(lga.id) },
                label = { Text("${lga.displayName} (${lga.lgaCode})") },
                modifier = Modifier.testTag("filter_lga_${lga.id}"),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldPrimary,
                    selectedLabelColor = Color.White,
                    containerColor = SoftGreySurface
                )
            )
        }
    }
}

/**
 * Searchable LGA -> Ward -> Polling Unit selector backed strictly by the preloaded master directory.
 */
@Composable
fun SearchablePollingUnitField(
    label: String,
    pollingUnits: List<PollingUnit>,
    selectedPu: PollingUnit?,
    onSelectPu: (PollingUnit?) -> Unit,
    enabled: Boolean = true,
    allowNullWardLevelOption: Boolean = false,
    nullOptionLabel: String = "Ward / LGA Level (No specific PU)",
    testTag: String = "searchable_pu_selector",
    modifier: Modifier = Modifier
) {
    var openPicker by remember { mutableStateOf(false) }

    OutlinedCard(
        onClick = { if (enabled) openPicker = true },
        enabled = enabled,
        modifier = modifier
            .fillMaxWidth()
            .testTag(testTag),
        colors = CardDefaults.outlinedCardColors(
            containerColor = if (enabled) WhiteBackground else SoftGreySurface
        ),
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondaryLight
                )
                Text(
                    text = selectedPu?.let { "${it.puCode} · ${it.name}" }
                        ?: if (allowNullWardLevelOption) nullOptionLabel else "Tap to search & select Polling Unit",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimaryLight,
                    fontWeight = FontWeight.Medium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                selectedPu?.let {
                    Text(
                        text = "${it.wardName} · ${it.lgaId.uppercase()}",
                        style = MonoCodeStyle,
                        color = EmeraldPrimary
                    )
                }
            }
            Icon(
                imageVector = Icons.Filled.ArrowDropDown,
                contentDescription = "Select Polling Unit",
                tint = if (enabled) EmeraldPrimary else TextSecondaryLight
            )
        }
    }

    if (openPicker) {
        var query by remember { mutableStateOf("") }
        var lgaFilter by remember { mutableStateOf<String?>(null) }
        var wardFilter by remember { mutableStateOf<String?>(null) }

        val availableLgas = remember(pollingUnits) {
            pollingUnits.map { it.lgaId }.distinct()
        }
        val availableWards = remember(pollingUnits, lgaFilter) {
            pollingUnits
                .filter { lgaFilter == null || it.lgaId == lgaFilter }
                .map { it.wardId to it.wardName }
                .distinctBy { it.first }
                .sortedBy { it.second }
        }
        val filtered = remember(pollingUnits, query, lgaFilter, wardFilter) {
            pollingUnits.filter { pu ->
                (lgaFilter == null || pu.lgaId == lgaFilter) &&
                    (wardFilter == null || pu.wardId == wardFilter) &&
                    (query.isBlank() ||
                        pu.puCode.contains(query, ignoreCase = true) ||
                        pu.name.contains(query, ignoreCase = true) ||
                        pu.wardName.contains(query, ignoreCase = true))
            }
        }

        AlertDialog(
            onDismissRequest = { openPicker = false },
            containerColor = WhiteBackground,
            title = { Text("Select Official Polling Unit", color = EmeraldDeep) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        label = { Text("Search code, PU name, or ward") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (availableLgas.size > 1) {
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = lgaFilter == null,
                                onClick = { lgaFilter = null; wardFilter = null },
                                label = { Text("All LGAs") }
                            )
                            availableLgas.forEach { lga ->
                                FilterChip(
                                    selected = lgaFilter == lga,
                                    onClick = { lgaFilter = lga; wardFilter = null },
                                    label = { Text(lga.uppercase()) }
                                )
                            }
                        }
                    }
                    if (availableWards.size > 1) {
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = wardFilter == null,
                                onClick = { wardFilter = null },
                                label = { Text("All Wards") }
                            )
                            availableWards.forEach { (wId, wName) ->
                                FilterChip(
                                    selected = wardFilter == wId,
                                    onClick = { wardFilter = if (wardFilter == wId) null else wId },
                                    label = { Text(wName) }
                                )
                            }
                        }
                    }
                    if (allowNullWardLevelOption) {
                        OutlinedCard(
                            onClick = {
                                onSelectPu(null)
                                openPicker = false
                            },
                            colors = CardDefaults.outlinedCardColors(containerColor = SoftGreySurface),
                            border = BorderStroke(1.dp, BorderLight),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = nullOptionLabel,
                                style = MaterialTheme.typography.labelLarge,
                                color = EmeraldDeep,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(270.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (filtered.isEmpty()) {
                            item {
                                Text(
                                    text = "No matching polling unit in preloaded directory.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondaryLight,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        } else {
                            items(filtered, key = { it.id }) { pu ->
                                val isSelected = selectedPu?.id == pu.id
                                Card(
                                    onClick = {
                                        onSelectPu(pu)
                                        openPicker = false
                                    },
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) EmeraldContainer else SoftGreySurface
                                    ),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSelected) EmeraldPrimary else BorderLight
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(pu.puCode, style = MonoCodeStyle, color = EmeraldPrimary)
                                        Text(pu.name, style = MaterialTheme.typography.titleSmall, color = TextPrimaryLight)
                                        Text("${pu.wardName} · ${pu.lgaId.uppercase()}", style = MaterialTheme.typography.bodySmall, color = TextSecondaryLight)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { openPicker = false }) { Text("Close") }
            }
        )
    }
}

@Composable
fun EmptyOperationalState(
    title: String = "No operational data has been submitted yet.",
    description: String,
    icon: ImageVector = Icons.Filled.Security,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    OutlinedCard(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.outlinedCardColors(containerColor = SoftGreySurface),
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                modifier = Modifier.size(40.dp),
                tint = EmeraldPrimary
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimaryLight,
                textAlign = TextAlign.Center
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondaryLight,
                textAlign = TextAlign.Center
            )
            if (actionLabel != null && onAction != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = onAction,
                    modifier = Modifier.testTag("empty_state_action")
                ) {
                    Text(actionLabel)
                }
            }
        }
    }
}

@Composable
fun TestDataTag() {
    StatusBadge(
        label = "TEST DATA",
        icon = Icons.Filled.Warning,
        containerColor = AlertWarningContainer,
        contentColor = AlertWarning
    )
}

@Composable
fun Base64EvidencePreview(
    base64: String?,
    label: String,
    modifier: Modifier = Modifier
) {
    val bitmap: Bitmap? = remember(base64) { ImageCompression.decodeBase64ToBitmap(base64) }
    if (bitmap != null) {
        Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(text = label, style = MonoCodeStyle, color = TextSecondaryLight)
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = label,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(10.dp)),
                contentScale = ContentScale.Crop
            )
        }
    }
}

fun formatTimestamp(ts: Timestamp?): String {
    if (ts == null) return "Pending server time"
    return SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault()).format(ts.toDate())
}
