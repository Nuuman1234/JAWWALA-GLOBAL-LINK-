const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ADMIN_UID = "admin_uid_1";
const FUNTUA_ADMIN_UID = "funtua_admin_1";
const DANDUME_ADMIN_UID = "dandume_admin_1";
const FUNTUA_WARD_COORD_UID = "funtua_wc_1";
const FUNTUA_AGENT_UID = "funtua_agent_1";
const OUTSIDER_UID = "outsider_1";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function tsNow() {
  return new Date();
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

async function seedHierarchy() {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("system_settings").doc("bootstrap").set({
      initializedByUid: ADMIN_UID,
      initializedByEmail: "admin@fdmis.test",
      cycleYear: 2027,
      constituencyName: "Funtua-Dandume Federal Constituency",
      createdAt: tsNow(),
    });
    await db.collection("admins").doc(ADMIN_UID).set({
      uid: ADMIN_UID,
      email: "admin@fdmis.test",
      grantedByUid: ADMIN_UID,
      createdAt: tsNow(),
    });
    await db.collection("users").doc(ADMIN_UID).set({
      uid: ADMIN_UID,
      email: "admin@fdmis.test",
      displayName: "Full Control Admin",
      role: "FULL_CONTROL_ADMIN",
      status: "ACTIVE",
      assignedLgaId: "",
      assignedWardId: "",
      assignedPollingUnitId: "",
      sessionRevoked: false,
      createdAt: tsNow(),
      updatedAt: tsNow(),
    });
    await db.collection("users").doc(FUNTUA_ADMIN_UID).set({
      uid: FUNTUA_ADMIN_UID,
      email: "funtua.admin@fdmis.test",
      displayName: "Funtua Super Admin",
      role: "FUNTUA_SUPER_ADMIN",
      status: "ACTIVE",
      assignedLgaId: "funtua",
      assignedWardId: "",
      assignedPollingUnitId: "",
      sessionRevoked: false,
      createdAt: tsNow(),
      updatedAt: tsNow(),
    });
    await db.collection("users").doc(DANDUME_ADMIN_UID).set({
      uid: DANDUME_ADMIN_UID,
      email: "dandume.admin@fdmis.test",
      displayName: "Dandume Super Admin",
      role: "DANDUME_SUPER_ADMIN",
      status: "ACTIVE",
      assignedLgaId: "dandume",
      assignedWardId: "",
      assignedPollingUnitId: "",
      sessionRevoked: false,
      createdAt: tsNow(),
      updatedAt: tsNow(),
    });
    await db.collection("users").doc(FUNTUA_WARD_COORD_UID).set({
      uid: FUNTUA_WARD_COORD_UID,
      email: "wc@fdmis.test",
      displayName: "Funtua Ward Coordinator",
      role: "WARD_COORDINATOR",
      status: "ACTIVE",
      assignedLgaId: "funtua",
      assignedWardId: "ward_f_1",
      assignedPollingUnitId: "",
      sessionRevoked: false,
      createdAt: tsNow(),
      updatedAt: tsNow(),
    });
    await db.collection("users").doc(FUNTUA_AGENT_UID).set({
      uid: FUNTUA_AGENT_UID,
      email: "agent@fdmis.test",
      displayName: "Funtua PU Agent",
      role: "POLLING_UNIT_AGENT",
      status: "ACTIVE",
      assignedLgaId: "funtua",
      assignedWardId: "ward_f_1",
      assignedPollingUnitId: "pu_f_1",
      sessionRevoked: false,
      createdAt: tsNow(),
      updatedAt: tsNow(),
    });

    await db.collection("wards").doc("ward_f_1").set({
      lgaId: "funtua",
      wardCode: "20-10-01",
      name: "Dandutse",
      coordinatorUid: FUNTUA_WARD_COORD_UID,
      coordinatorName: "Funtua Ward Coordinator",
      expectedPollingUnits: 25,
      isTestData: false,
      createdByUid: ADMIN_UID,
      createdAt: tsNow(),
      updatedAt: tsNow(),
    });
    await db.collection("wards").doc("ward_d_1").set({
      lgaId: "dandume",
      wardCode: "20-07-01",
      name: "Dandume A",
      coordinatorUid: "",
      coordinatorName: "",
      expectedPollingUnits: 16,
      isTestData: false,
      createdByUid: ADMIN_UID,
      createdAt: tsNow(),
      updatedAt: tsNow(),
    });

    await db.collection("polling_units").doc("pu_f_1").set({
      lgaId: "funtua",
      wardId: "ward_f_1",
      wardName: "Dandutse",
      puCode: "20/10/01/001",
      name: "Primary School Unit I",
      locationDescription: "Town Center",
      coordinatesVerified: false,
      assignedAgentUid: FUNTUA_AGENT_UID,
      assignedAgentName: "Funtua PU Agent",
      operationalStatus: "AGENT_ASSIGNED",
      registeredVoters: 500,
      isTestData: false,
      createdByUid: ADMIN_UID,
      createdAt: tsNow(),
      updatedAt: tsNow(),
    });
    await db.collection("polling_units").doc("pu_d_1").set({
      lgaId: "dandume",
      wardId: "ward_d_1",
      wardName: "Dandume A",
      puCode: "20/07/01/001",
      name: "Dandume Central Unit",
      locationDescription: "Market Square",
      coordinatesVerified: false,
      assignedAgentUid: "",
      assignedAgentName: "",
      operationalStatus: "NOT_STARTED",
      registeredVoters: 400,
      isTestData: false,
      createdByUid: ADMIN_UID,
      createdAt: tsNow(),
      updatedAt: tsNow(),
    });
  });
}

test("Unauthenticated users cannot read or list protected collections", async () => {
  await seedHierarchy();
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("polling_units").get());
  await assertFails(unauthDb.collection("users").doc(ADMIN_UID).get());
  await assertFails(unauthDb.collection("audit_logs").get());
  await assertFails(unauthDb.collection("incidents").get());
});

test("User self-registration cannot escalate role after bootstrap", async () => {
  await seedHierarchy();
  const outsiderDb = testEnv.authenticatedContext(OUTSIDER_UID, {
    email: "outsider@fdmis.test",
    email_verified: true,
  }).firestore();

  // Attempt to self-assign FULL_CONTROL_ADMIN must fail
  await assertFails(
    outsiderDb.collection("users").doc(OUTSIDER_UID).set({
      uid: OUTSIDER_UID,
      email: "outsider@fdmis.test",
      displayName: "Outsider",
      role: "FULL_CONTROL_ADMIN",
      status: "ACTIVE",
      assignedLgaId: "",
      assignedWardId: "",
      assignedPollingUnitId: "",
      sessionRevoked: false,
      createdAt: tsNow(),
      updatedAt: tsNow(),
    })
  );

  // Self-registration as PENDING / PENDING_APPROVAL succeeds
  await assertSucceeds(
    outsiderDb.collection("users").doc(OUTSIDER_UID).set({
      uid: OUTSIDER_UID,
      email: "outsider@fdmis.test",
      displayName: "Outsider",
      role: "PENDING",
      status: "PENDING_APPROVAL",
      assignedLgaId: "",
      assignedWardId: "",
      assignedPollingUnitId: "",
      sessionRevoked: false,
      createdAt: tsNow(),
      updatedAt: tsNow(),
    })
  );

  // Ghost field injection fails
  await assertFails(
    outsiderDb.collection("users").doc("ghost_user").set({
      uid: "ghost_user",
      email: "ghost@fdmis.test",
      displayName: "Ghost",
      role: "PENDING",
      status: "PENDING_APPROVAL",
      assignedLgaId: "",
      assignedWardId: "",
      assignedPollingUnitId: "",
      sessionRevoked: false,
      isAdmin: true,
      createdAt: tsNow(),
      updatedAt: tsNow(),
    })
  );
});

test("Geographic isolation: Funtua Super Admin cannot read or modify Dandume data", async () => {
  await seedHierarchy();
  const funtuaDb = testEnv.authenticatedContext(FUNTUA_ADMIN_UID).firestore();

  // Funtua query with where lgaId == funtua succeeds
  await assertSucceeds(
    funtuaDb.collection("polling_units").where("lgaId", "==", "funtua").get()
  );

  // Unfiltered query or Dandume query fails
  await assertFails(funtuaDb.collection("polling_units").get());
  await assertFails(
    funtuaDb.collection("polling_units").where("lgaId", "==", "dandume").get()
  );
  await assertFails(funtuaDb.collection("polling_units").doc("pu_d_1").get());
  await assertFails(
    funtuaDb.collection("wards").doc("ward_d_2").set({
      lgaId: "dandume",
      wardCode: "20-07-02",
      name: "Dandume B",
      coordinatorUid: "",
      coordinatorName: "",
      expectedPollingUnits: 12,
      isTestData: false,
      createdByUid: FUNTUA_ADMIN_UID,
      createdAt: tsNow(),
      updatedAt: tsNow(),
    })
  );
});

test("Emergency access revocation immediately blocks agent operations", async () => {
  await seedHierarchy();
  const agentDb = testEnv.authenticatedContext(FUNTUA_AGENT_UID).firestore();

  // Active agent can check in to assigned PU
  await assertSucceeds(
    agentDb.collection("check_ins").doc("ci_1").set({
      puId: "pu_f_1",
      puCode: "20/10/01/001",
      puName: "Primary School Unit I",
      lgaId: "funtua",
      wardId: "ward_f_1",
      agentUid: FUNTUA_AGENT_UID,
      agentName: "Funtua PU Agent",
      arrivalTimeText: "08:05 AM",
      comments: "Arrived on time",
      batteryPercent: 92,
      networkStatus: "4G",
      clientSubmissionId: "sub_1",
      isTestData: false,
      createdAt: tsNow(),
    })
  );

  // Full Control Admin triggers Emergency Access Revocation
  const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();
  await assertSucceeds(
    adminDb.collection("users").doc(FUNTUA_AGENT_UID).update({
      status: "SUSPENDED",
      sessionRevoked: true,
      revokedReason: "Phone reported lost",
      updatedAt: tsNow(),
    })
  );

  // Suspended/revoked agent is immediately blocked from reading PU or submitting check-in
  await assertFails(agentDb.collection("polling_units").doc("pu_f_1").get());
  await assertFails(
    agentDb.collection("check_ins").doc("ci_2").set({
      puId: "pu_f_1",
      puCode: "20/10/01/001",
      puName: "Primary School Unit I",
      lgaId: "funtua",
      wardId: "ward_f_1",
      agentUid: FUNTUA_AGENT_UID,
      agentName: "Funtua PU Agent",
      arrivalTimeText: "08:15 AM",
      comments: "Attempt after revocation",
      batteryPercent: 90,
      networkStatus: "4G",
      clientSubmissionId: "sub_2",
      isTestData: false,
      createdAt: tsNow(),
    })
  );
});

test("Result submission integrity: agent cannot self-verify or overwrite verified result", async () => {
  await seedHierarchy();
  const agentDb = testEnv.authenticatedContext(FUNTUA_AGENT_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();

  // Agent cannot submit directly as VERIFIED
  await assertFails(
    agentDb.collection("result_submissions").doc("res_bad").set({
      puId: "pu_f_1",
      puCode: "20/10/01/001",
      puName: "Primary School Unit I",
      lgaId: "funtua",
      wardId: "ward_f_1",
      wardName: "Dandutse",
      submittedByUid: FUNTUA_AGENT_UID,
      submittedByName: "Funtua PU Agent",
      registeredVoters: 500,
      accreditedVoters: 320,
      validVotes: 310,
      rejectedVotes: 10,
      totalVotesCast: 320,
      bvasStatus: "Functional",
      bvasNotes: "Smooth accreditation",
      submissionNotes: "Submitted",
      verificationStatus: "VERIFIED",
      publiclyApproved: true,
      reviewNote: "",
      reviewedByUid: "",
      reviewedByName: "",
      version: 1,
      clientSubmissionId: "res_sub_bad",
      isTestData: false,
      createdAt: tsNow(),
      updatedAt: tsNow(),
    })
  );

  // Agent submits normally as SUBMITTED
  await assertSucceeds(
    agentDb.collection("result_submissions").doc("res_1").set({
      puId: "pu_f_1",
      puCode: "20/10/01/001",
      puName: "Primary School Unit I",
      lgaId: "funtua",
      wardId: "ward_f_1",
      wardName: "Dandutse",
      submittedByUid: FUNTUA_AGENT_UID,
      submittedByName: "Funtua PU Agent",
      registeredVoters: 500,
      accreditedVoters: 320,
      validVotes: 310,
      rejectedVotes: 10,
      totalVotesCast: 320,
      bvasStatus: "Functional",
      bvasNotes: "Smooth accreditation",
      submissionNotes: "EC8A uploaded",
      verificationStatus: "SUBMITTED",
      publiclyApproved: false,
      reviewNote: "",
      reviewedByUid: "",
      reviewedByName: "",
      version: 1,
      clientSubmissionId: "res_sub_1",
      isTestData: false,
      createdAt: tsNow(),
      updatedAt: tsNow(),
    })
  );

  // Admin verifies the result
  await assertSucceeds(
    adminDb.collection("result_submissions").doc("res_1").update({
      verificationStatus: "VERIFIED",
      reviewNote: "Matched EC8A",
      reviewedByUid: ADMIN_UID,
      reviewedByName: "Full Control Admin",
      updatedAt: tsNow(),
    })
  );

  // Agent cannot modify a VERIFIED result
  await assertFails(
    agentDb.collection("result_submissions").doc("res_1").update({
      validVotes: 400,
      updatedAt: tsNow(),
    })
  );
});

test("Audit logs are admin-only readable and strictly immutable", async () => {
  await seedHierarchy();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();
  const funtuaDb = testEnv.authenticatedContext(FUNTUA_ADMIN_UID).firestore();
  const agentDb = testEnv.authenticatedContext(FUNTUA_AGENT_UID).firestore();

  await assertSucceeds(
    adminDb.collection("audit_logs").doc("log_1").set({
      actorUid: ADMIN_UID,
      actorName: "Full Control Admin",
      actorEmail: "admin@fdmis.test",
      actorRole: "FULL_CONTROL_ADMIN",
      action: "USER_ROLE_UPDATED",
      affectedEntity: "users",
      affectedId: FUNTUA_AGENT_UID,
      details: "Assigned to PU 20/10/01/001",
      createdAt: tsNow(),
    })
  );

  // Only Full Control Admin can read audit logs
  await assertSucceeds(adminDb.collection("audit_logs").get());
  await assertFails(funtuaDb.collection("audit_logs").get());
  await assertFails(agentDb.collection("audit_logs").get());

  // Nobody can update or delete an audit log
  await assertFails(
    adminDb.collection("audit_logs").doc("log_1").update({ details: "Tampered" })
  );
  await assertFails(adminDb.collection("audit_logs").doc("log_1").delete());
});

test("Controlled master directory: ordinary admins cannot create, delete, or rename PUs; Full Control Admin backup+correction succeeds", async () => {
  await seedHierarchy();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();
  const funtuaDb = testEnv.authenticatedContext(FUNTUA_ADMIN_UID).firestore();

  // Funtua Super Admin CANNOT create a new ward or PU
  await assertFails(
    funtuaDb.collection("wards").doc("funtua_new_ward").set({
      lgaId: "funtua",
      wardCode: "20-14-99",
      name: "Unauthorized Ward",
      coordinatorUid: "",
      coordinatorName: "",
      expectedPollingUnits: 5,
      isTestData: false,
      createdByUid: FUNTUA_ADMIN_UID,
      createdAt: tsNow(),
      updatedAt: tsNow(),
    })
  );
  await assertFails(
    funtuaDb.collection("polling_units").doc("pu_f_new").set({
      lgaId: "funtua",
      wardId: "ward_f_1",
      wardName: "Dandutse",
      puCode: "20-14-01-999",
      name: "Unauthorized PU",
      locationDescription: "",
      coordinatesVerified: false,
      assignedAgentUid: "",
      assignedAgentName: "",
      operationalStatus: "NOT_STARTED",
      registeredVoters: 0,
      isTestData: false,
      createdByUid: FUNTUA_ADMIN_UID,
      createdAt: tsNow(),
      updatedAt: tsNow(),
    })
  );

  // Funtua Super Admin CANNOT rename or delete existing master PU
  await assertFails(
    funtuaDb.collection("polling_units").doc("pu_f_1").update({
      name: "Tampered Master PU Name",
      updatedAt: tsNow(),
    })
  );
  await assertFails(funtuaDb.collection("polling_units").doc("pu_f_1").delete());
  await assertFails(adminDb.collection("polling_units").doc("pu_f_1").delete());
  await assertFails(adminDb.collection("wards").doc("ward_f_1").delete());

  // Funtua Super Admin CAN assign an agent & update operational status
  await assertSucceeds(
    funtuaDb.collection("polling_units").doc("pu_f_1").update({
      assignedAgentUid: FUNTUA_AGENT_UID,
      assignedAgentName: "Assigned Agent Updated",
      operationalStatus: "AGENT_ASSIGNED",
      updatedAt: tsNow(),
    })
  );

  // Full Control Admin CAN write backup snapshot and perform controlled PU correction
  await assertSucceeds(
    adminDb.collection("directory_backups").doc("bak_1").set({
      entityType: "polling_units",
      targetDocId: "pu_f_1",
      lgaId: "funtua",
      puCode: "20/10/01/001",
      previousName: "Primary School Unit I",
      previousLocationDescription: "Town Center",
      previousRegisteredVoters: 500,
      previousCoordinatesVerified: false,
      correctionReason: "Aligning spelling with INEC physical register",
      backedUpByUid: ADMIN_UID,
      backedUpByEmail: "admin@fdmis.test",
      createdAt: tsNow(),
    })
  );
  await assertSucceeds(
    adminDb.collection("polling_units").doc("pu_f_1").update({
      name: "Primary School Unit I Corrected",
      updatedAt: tsNow(),
    })
  );

  // Backups are immutable and non-admins cannot read them
  await assertFails(funtuaDb.collection("directory_backups").get());
  await assertFails(adminDb.collection("directory_backups").doc("bak_1").delete());
});

test("Offline attachments are idempotent, immutable, and isolated from cross-user or cross-LGA access", async () => {
  await seedHierarchy();
  const agentDb = testEnv.authenticatedContext(FUNTUA_AGENT_UID).firestore();
  const dandumeDb = testEnv.authenticatedContext(DANDUME_ADMIN_UID).firestore();
  const fakeSha = "a".repeat(64);

  // Authorized agent can upload attachment linked to their reportId
  await assertSucceeds(
    agentDb.collection("report_attachments").doc("att_1").set({
      attachmentId: "att_1",
      reportId: "inc_1",
      reportType: "INCIDENT_REPORT",
      ownerUid: FUNTUA_AGENT_UID,
      lgaId: "funtua",
      wardId: "ward_f_1",
      puId: "pu_f_1",
      fileName: "evidence.jpg",
      sha256Hash: fakeSha,
      sizeBytes: 1200,
      base64Data: "ZmFrZV9qcGVn",
      createdAt: tsNow(),
    })
  );

  // Duplicate overwrite or deletion of attachment is blocked (idempotent & immutable)
  await assertFails(
    agentDb.collection("report_attachments").doc("att_1").update({ fileName: "tampered.jpg" })
  );
  await assertFails(agentDb.collection("report_attachments").doc("att_1").delete());

  // Dandume Super Admin cannot read Funtua attachment
  await assertFails(dandumeDb.collection("report_attachments").doc("att_1").get());

  // Spoofed ownerUid is rejected
  await assertFails(
    dandumeDb.collection("report_attachments").doc("att_2").set({
      attachmentId: "att_2",
      reportId: "inc_2",
      reportType: "INCIDENT_REPORT",
      ownerUid: FUNTUA_AGENT_UID,
      lgaId: "dandume",
      wardId: "ward_d_1",
      puId: "pu_d_1",
      fileName: "spoof.jpg",
      sha256Hash: fakeSha,
      sizeBytes: 1200,
      base64Data: "ZmFrZV9qcGVn",
      createdAt: tsNow(),
    })
  );
});


