package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Pending
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.firebase.OfflineAttachmentDraft
import com.example.data.local.OfflineAttachmentEntity
import com.example.data.local.OfflineQueueEntity
import com.example.data.local.OfflineSyncStatus
import com.example.data.local.SyncHistoryEntity
import com.example.ui.theme.AlertCritical
import com.example.ui.theme.AlertCriticalContainer
import com.example.ui.theme.AlertHigh
import com.example.ui.theme.AlertHighContainer
import com.example.ui.theme.AlertWarning
import com.example.ui.theme.AlertWarningContainer
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.SoftGreySurface
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusInfoContainer
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.StatusVerifiedContainer
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.WhiteBackground
import com.example.ui.viewmodel.SyncDashboardMetrics
import com.example.util.ImageCompression
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReportSyncStatusBadge(
    status: OfflineSyncStatus,
    hasConflict: Boolean = false,
    modifier: Modifier = Modifier
) {
    val label = if (hasConflict) "CONFLICT · ${status.label}" else status.label
    val (bg, fg, icon) = when {
        hasConflict -> Triple(AlertCriticalContainer, AlertCritical, Icons.Filled.Warning)
        status == OfflineSyncStatus.SAVED_LOCALLY -> Triple(SoftGreySurface, TextPrimaryLight, Icons.Filled.Save)
        status == OfflineSyncStatus.PENDING_SYNC -> Triple(AlertWarningContainer, AlertWarning, Icons.Filled.Pending)
        status == OfflineSyncStatus.SYNCING -> Triple(StatusInfoContainer, StatusInfo, Icons.Filled.Sync)
        status == OfflineSyncStatus.SYNC_FAILED -> Triple(AlertCriticalContainer, AlertCritical, Icons.Filled.Error)
        status == OfflineSyncStatus.SYNCED -> Triple(StatusVerifiedContainer, StatusVerified, Icons.Filled.CheckCircle)
        status == OfflineSyncStatus.UNDER_REVIEW -> Triple(StatusInfoContainer, StatusInfo, Icons.Filled.Visibility)
        status == OfflineSyncStatus.VERIFIED -> Triple(EmeraldContainer, EmeraldDeep, Icons.Filled.Verified)
        else -> Triple(SoftGreySurface, TextSecondaryLight, Icons.Filled.Save)
    }
    StatusBadge(
        label = label,
        icon = icon,
        containerColor = bg,
        contentColor = fg,
        modifier = modifier
    )
}

@Composable
fun CompactSyncBanner(
    metrics: SyncDashboardMetrics,
    onSyncNow: () -> Unit,
    onOpenSyncDashboard: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val dateFmt = remember { SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault()) }
    val (bannerBg, borderCol, titleText, statusIcon, iconTint) = when {
        !metrics.isOnline -> Quint(
            AlertWarningContainer,
            AlertWarning,
            "Offline Mode · Auto-Save Active",
            Icons.Filled.CloudOff,
            AlertWarning
        )
        !metrics.backendReachable -> Quint(
            AlertHighContainer,
            AlertHigh,
            "Network Connected · Server Unreachable",
            Icons.Filled.CloudOff,
            AlertHigh
        )
        metrics.syncingCount > 0 -> Quint(
            StatusInfoContainer,
            StatusInfo,
            "Synchronizing Field Queue...",
            Icons.Filled.Sync,
            StatusInfo
        )
        metrics.syncFailedCount > 0 -> Quint(
            AlertCriticalContainer,
            AlertCritical,
            "${metrics.syncFailedCount} Sync Failure(s) · Retained Safely",
            Icons.Filled.Error,
            AlertCritical
        )
        else -> Quint(
            SoftGreySurface,
            BorderLight,
            "Online · Offline-First Protection Ready",
            Icons.Filled.CloudDone,
            StatusVerified
        )
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("compact_sync_banner"),
        colors = CardDefaults.cardColors(containerColor = bannerBg),
        border = BorderStroke(1.dp, borderCol)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(statusIcon, contentDescription = titleText, tint = iconTint, modifier = Modifier.size(18.dp))
                    Text(
                        text = titleText,
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimaryLight,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                if (metrics.isOnline && metrics.outstandingSyncCount > 0) {
                    TextButton(
                        onClick = onSyncNow,
                        modifier = Modifier.testTag("banner_sync_now_btn")
                    ) {
                        Icon(Icons.Filled.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(4.dp))
                        Text("Sync")
                    }
                } else if (onOpenSyncDashboard != null) {
                    TextButton(
                        onClick = onOpenSyncDashboard,
                        modifier = Modifier.testTag("banner_open_sync_dashboard_btn")
                    ) {
                        Text("Sync Status")
                    }
                }
            }
            Text(
                text = "Saved: ${metrics.savedLocallyCount} · Pending: ${metrics.pendingSyncCount} · Syncing: ${metrics.syncingCount} · Failed: ${metrics.syncFailedCount} · Synced: ${metrics.syncedCount}",
                style = MonoCodeStyle,
                color = TextPrimaryLight
            )
            Text(
                text = if (metrics.lastSuccessfulSyncMillis > 0L) {
                    "Last Successful Sync: ${dateFmt.format(Date(metrics.lastSuccessfulSyncMillis))}"
                } else {
                    "Last Successful Sync: Not synced in current session yet"
                },
                style = MonoCodeStyle,
                color = TextSecondaryLight
            )
        }
    }
}

@Composable
fun SyncDashboardSummaryCard(
    metrics: SyncDashboardMetrics,
    onSyncNow: () -> Unit,
    onArchiveConfirmed: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val dateFmt = remember { SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.getDefault()) }
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = WhiteBackground),
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Offline Synchronization Dashboard", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
                StatusBadge(
                    label = when {
                        !metrics.isOnline -> "Offline"
                        !metrics.backendReachable -> "Server Unreachable"
                        else -> "Server Reachable"
                    },
                    icon = if (metrics.isOnline && metrics.backendReachable) Icons.Filled.CloudDone else Icons.Filled.CloudOff,
                    containerColor = if (metrics.isOnline && metrics.backendReachable) StatusVerifiedContainer else AlertWarningContainer,
                    contentColor = if (metrics.isOnline && metrics.backendReachable) StatusVerified else AlertWarning
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                KpiTile("Saved Locally", "${metrics.savedLocallyCount}", "Drafts protected", EmeraldPrimary, Modifier.weight(1f))
                KpiTile("Pending Sync", "${metrics.pendingSyncCount}", "Waiting for server", AlertWarning, Modifier.weight(1f))
                KpiTile("Syncing", "${metrics.syncingCount}", "Uploading now", StatusInfo, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                KpiTile("Sync Failed", "${metrics.syncFailedCount}", "Conflicts: ${metrics.conflictCount}", AlertCritical, Modifier.weight(1f))
                KpiTile("Synced", "${metrics.syncedCount}", "Review: ${metrics.underReviewCount} · Ver: ${metrics.verifiedCount}", StatusVerified, Modifier.weight(1f))
            }

            Surface(
                color = SoftGreySurface,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (metrics.lastSuccessfulSyncMillis > 0L) {
                        "Last Successful Sync Time: ${dateFmt.format(Date(metrics.lastSuccessfulSyncMillis))}"
                    } else {
                        "Last Successful Sync Time: No completed sync recorded yet"
                    },
                    style = MonoCodeStyle,
                    color = TextPrimaryLight,
                    modifier = Modifier.padding(10.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onSyncNow,
                    enabled = metrics.isOnline,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("sync_offline_queue_btn")
                ) {
                    Icon(Icons.Filled.Sync, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Sync Now (${metrics.outstandingSyncCount})")
                }
                if (onArchiveConfirmed != null && metrics.syncedCount > 0) {
                    OutlinedButton(
                        onClick = onArchiveConfirmed,
                        modifier = Modifier.testTag("archive_confirmed_queue_btn")
                    ) {
                        Text("Archive Confirmed")
                    }
                }
            }
        }
    }
}

@Composable
fun CameraAndPickerEvidenceSection(
    ownerUid: String,
    label: String,
    attachedFileName: String?,
    attachedLocalPath: String?,
    attachedBase64: String?,
    attachmentUploadStatus: OfflineSyncStatus?,
    onAttachmentCaptured: (OfflineAttachmentDraft, String) -> Unit,
    onRemoveAttachment: (() -> Unit)? = null,
    testTagPrefix: String = "evidence"
) {
    val context = LocalContext.current
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    var imageError by remember { mutableStateOf<String?>(null) }

    val handleSelectedUri: (Uri?) -> Unit = { uri ->
        if (uri != null) {
            ImageCompression.compressAndPersistUri(context, ownerUid, uri, testTagPrefix).fold(
                onSuccess = { compressed ->
                    imageError = null
                    onAttachmentCaptured(
                        OfflineAttachmentDraft(
                            fileName = compressed.fileName,
                            localFilePath = compressed.localFilePath,
                            sha256Hash = compressed.sha256Hash,
                            sizeBytes = compressed.sizeBytes
                        ),
                        compressed.base64
                    )
                },
                onFailure = { err ->
                    imageError = err.localizedMessage ?: "Failed to save image locally"
                }
            )
        }
    }

    val takePictureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
        val captureUri = pendingCameraUri
        if (saved && captureUri != null) {
            handleSelectedUri(captureUri)
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val (uri, _) = ImageCompression.createCameraCaptureUri(context)
            pendingCameraUri = uri
            takePictureLauncher.launch(uri)
        } else {
            imageError = "Camera permission is required to capture a photograph directly."
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        handleSelectedUri(uri)
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = TextPrimaryLight)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
                onClick = {
                    val hasCam = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                    if (hasCam) {
                        val (uri, _) = ImageCompression.createCameraCaptureUri(context)
                        pendingCameraUri = uri
                        takePictureLauncher.launch(uri)
                    } else {
                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("${testTagPrefix}_camera_btn")
            ) {
                Icon(Icons.Filled.CameraAlt, contentDescription = "Capture with Camera", modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.size(6.dp))
                Text("Camera Photo")
            }
            OutlinedButton(
                onClick = {
                    photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("${testTagPrefix}_picker_btn")
            ) {
                Icon(Icons.Filled.AddAPhoto, contentDescription = "Pick from Gallery", modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.size(6.dp))
                Text("Gallery Picker")
            }
        }

        imageError?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = AlertCritical)
        }

        val bitmap = remember(attachedLocalPath, attachedBase64) {
            ImageCompression.decodeLocalPathToBitmap(attachedLocalPath)
                ?: ImageCompression.decodeBase64ToBitmap(attachedBase64)
        }
        if (bitmap != null || !attachedFileName.isNullOrBlank()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SoftGreySurface),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = attachedFileName ?: "Persisted Offline Photo",
                            style = MonoCodeStyle,
                            color = EmeraldDeep,
                            modifier = Modifier.weight(1f)
                        )
                        if (attachmentUploadStatus != null) {
                            ReportSyncStatusBadge(status = attachmentUploadStatus)
                        }
                    }
                    if (bitmap != null) {
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = attachedFileName ?: "Persisted local evidence",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                    if (onRemoveAttachment != null) {
                        TextButton(onClick = onRemoveAttachment) {
                            Text("Clear Photo")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LocalReportDetailDialog(
    report: OfflineQueueEntity,
    attachments: List<OfflineAttachmentEntity>,
    history: List<SyncHistoryEntity>,
    onDismiss: () -> Unit,
    onEditReport: (() -> Unit)? = null
) {
    val status = OfflineSyncStatus.fromString(report.syncStatus)
    val dateFmt = remember { SimpleDateFormat("dd MMM yyyy HH:mm:ss", Locale.getDefault()) }
    val payloadEntries = remember(report.payloadJson) {
        runCatching {
            val obj = JSONObject(report.payloadJson)
            buildList {
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    if (k.contains("Base64", ignoreCase = true)) continue
                    val v = obj.opt(k)?.toString().orEmpty()
                    if (v.isNotBlank()) add(k to v)
                }
            }
        }.getOrElse { emptyList() }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = WhiteBackground,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(report.title, color = EmeraldDeep, style = MaterialTheme.typography.titleMedium)
                ReportSyncStatusBadge(status = status, hasConflict = report.hasConflict)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Report ID: ${report.clientSubmissionId}", style = MonoCodeStyle, color = EmeraldPrimary)
                Text("Type: ${report.itemType} · Created: ${dateFmt.format(Date(report.createdAtMillis))}", style = MonoCodeStyle, color = TextSecondaryLight)
                report.syncedAtMillis?.let {
                    Text("Server Verified: ${dateFmt.format(Date(it))}", style = MonoCodeStyle, color = StatusVerified)
                }
                report.conflictMessage?.let {
                    Card(colors = CardDefaults.cardColors(containerColor = AlertCriticalContainer)) {
                        Text(it, style = MaterialTheme.typography.bodySmall, color = AlertCritical, modifier = Modifier.padding(8.dp))
                    }
                } ?: report.lastError?.let {
                    Text("Last Error: $it", style = MaterialTheme.typography.bodySmall, color = AlertCritical)
                }

                HorizontalDivider(color = BorderLight)
                Text("Recorded Payload", style = MaterialTheme.typography.labelLarge, color = EmeraldDeep)
                payloadEntries.forEach { (k, v) ->
                    Text("$k: $v", style = MaterialTheme.typography.bodySmall, color = TextPrimaryLight)
                }

                if (attachments.isNotEmpty()) {
                    HorizontalDivider(color = BorderLight)
                    Text("Protected Local Attachments (${attachments.size})", style = MaterialTheme.typography.labelLarge, color = EmeraldDeep)
                    attachments.forEach { att ->
                        val attStatus = OfflineSyncStatus.fromString(att.uploadStatus)
                        val bmp = remember(att.localFilePath) { ImageCompression.decodeLocalPathToBitmap(att.localFilePath) }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SoftGreySurface),
                            border = BorderStroke(1.dp, BorderLight),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(att.fileName, style = MonoCodeStyle, color = TextPrimaryLight, modifier = Modifier.weight(1f))
                                    ReportSyncStatusBadge(status = attStatus)
                                }
                                Text("SHA-256: ${att.sha256Hash.take(16)}... · ${att.sizeBytes / 1024} KB", style = MonoCodeStyle, color = TextSecondaryLight)
                                if (bmp != null) {
                                    Image(
                                        bitmap = bmp.asImageBitmap(),
                                        contentDescription = att.fileName,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(140.dp)
                                            .clip(RoundedCornerShape(6.dp)),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                            }
                        }
                    }
                }

                if (history.isNotEmpty()) {
                    HorizontalDivider(color = BorderLight)
                    Text("Synchronization Audit Log", style = MaterialTheme.typography.labelLarge, color = EmeraldDeep)
                    history.take(8).forEach { entry ->
                        Text(
                            text = "${dateFmt.format(Date(entry.timestampMillis))} · ${entry.eventType}: ${entry.message}",
                            style = MonoCodeStyle,
                            color = TextSecondaryLight
                        )
                    }
                }
            }
        },
        confirmButton = {
            if (onEditReport != null && status.isUnsentOrEditable()) {
                Button(
                    onClick = onEditReport,
                    modifier = Modifier.testTag("dialog_edit_offline_report_btn")
                ) {
                    Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Edit Offline")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

private data class Quint<A, B, C, D, E>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D,
    val fifth: E
)
