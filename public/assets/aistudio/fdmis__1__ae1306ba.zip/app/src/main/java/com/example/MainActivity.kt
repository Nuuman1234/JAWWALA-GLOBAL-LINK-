package com.example

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.FolderShared
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.firebase.AuthRepository
import com.example.data.firebase.DirectoryRepository
import com.example.data.firebase.FdmisFirestoreProvider
import com.example.data.firebase.OperationsRepository
import com.example.data.firebase.attemptAutoSignIn
import com.example.data.firebase.authStateFlow
import com.example.data.firebase.signOutUser
import com.example.data.local.FdmisDatabase
import com.example.data.local.OfficialDirectoryCatalog
import com.example.data.local.OfflineItemType
import com.example.data.local.OfflineSyncJobService
import com.example.data.local.SessionPreferences
import com.example.data.model.UserAccount
import com.example.ui.screens.AdminAndOpsScreen
import com.example.ui.screens.AuthGateScreen
import com.example.ui.screens.DirectoryScreen
import com.example.ui.screens.FieldOpsScreen
import com.example.ui.screens.IncidentsScreen
import com.example.ui.screens.ResultsScreen
import com.example.ui.screens.SituationRoomScreen
import com.example.ui.theme.AlertWarning
import com.example.ui.theme.AlertWarningContainer
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.FdmisTheme
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.WhiteBackground
import com.example.ui.viewmodel.FdmisViewModel
import com.example.util.DeviceTelemetry
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

enum class FdmisTab(val label: String, val shortLabel: String, val icon: ImageVector) {
    SITUATION_ROOM("Situation Room", "Command", Icons.Filled.Dashboard),
    DIRECTORY("Directory & Map", "Directory", Icons.Filled.FolderShared),
    FIELD_OPS("Field Operations", "Field Ops", Icons.Filled.HowToReg),
    INCIDENTS("Incident Monitoring", "Incidents", Icons.Filled.ReportProblem),
    RESULTS("Results & Verification", "Results", Icons.Filled.Assessment),
    OPS_HUB("Admin & Operations Hub", "Ops Hub", Icons.Filled.AdminPanelSettings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(
                android.graphics.Color.WHITE,
                android.graphics.Color.WHITE
            ),
            navigationBarStyle = SystemBarStyle.light(
                android.graphics.Color.WHITE,
                android.graphics.Color.WHITE
            )
        )
        setContent {
            FdmisTheme(darkTheme = false) {
                FdmisAppRoot()
            }
        }
    }
}

@Composable
fun FdmisAppRoot() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val currentUser by Firebase.auth.authStateFlow().collectAsStateWithLifecycle(initialValue = Firebase.auth.currentUser)
    var attemptedAutoSignIn by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (!attemptedAutoSignIn && Firebase.auth.currentUser == null) {
            attemptedAutoSignIn = true
            attemptAutoSignIn(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = {},
                onUnauthenticated = {},
                scope = scope
            )
        }
    }

    val signedInUser = currentUser
    if (signedInUser == null) {
        AuthGateScreen(
            isSignedIn = false,
            isCheckingProfile = false,
            needsBootstrap = false,
            userAccount = null,
            errorMessage = null,
            onAuthSuccess = {},
            onInitializeAdmin = { _, _ -> },
            onRegisterPending = { _, _ -> },
            onRefreshProfile = {},
            onSignOut = {}
        )
    } else {
        key(signedInUser.uid) {
            val viewModel: FdmisViewModel = viewModel(
                key = signedInUser.uid,
                factory = viewModelFactory {
                    initializer {
                        val appCtx = context.applicationContext
                        val firestore = FdmisFirestoreProvider.getInstance(appCtx)
                        val offlineDao = FdmisDatabase.getInstance(appCtx).offlineQueueDao()
                        val prefs = SessionPreferences(appCtx)
                        val officialDataset = OfficialDirectoryCatalog.loadFromContext(appCtx)
                        FdmisViewModel(
                            currentUserId = signedInUser.uid,
                            authRepo = AuthRepository(firestore, offlineDao = offlineDao),
                            dirRepo = DirectoryRepository(firestore),
                            opsRepo = OperationsRepository(firestore, offlineDao),
                            offlineDao = offlineDao,
                            sessionPrefs = prefs,
                            officialDirectory = officialDataset,
                            onScheduleBackgroundSync = { OfflineSyncJobService.schedule(appCtx) }
                        )
                    }
                }
            )
            AuthenticatedSessionHost(
                viewModel = viewModel,
                onSignOut = {
                    signOutUser(credentialManager = credentialManager, scope = scope)
                }
            )
        }
    }
}

@Composable
private fun AuthenticatedSessionHost(
    viewModel: FdmisViewModel,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val authGate by viewModel.authGate.collectAsStateWithLifecycle()
    val liveUser by viewModel.userAccount.collectAsStateWithLifecycle()
    val sessionExpired by viewModel.sessionExpiredByInactivity.collectAsStateWithLifecycle()

    DisposableEffect(context, viewModel, lifecycleOwner) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        viewModel.onNetworkConnectivityChanged(DeviceTelemetry.readSnapshot(context, false).isOnline)
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                viewModel.onNetworkConnectivityChanged(true)
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                val validated = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                if (validated) {
                    viewModel.onNetworkConnectivityChanged(true)
                }
            }

            override fun onLost(network: Network) {
                val stillOnline = DeviceTelemetry.readSnapshot(context, false).isOnline
                viewModel.onNetworkConnectivityChanged(stillOnline)
            }
        }
        val req = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        runCatching { cm?.registerNetworkCallback(req, callback) }

        val lifecycleObserver = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.onNetworkConnectivityChanged(DeviceTelemetry.readSnapshot(context, false).isOnline)
                viewModel.onAppResumed()
            }
        }
        lifecycleOwner.lifecycle.addObserver(lifecycleObserver)

        onDispose {
            runCatching { cm?.unregisterNetworkCallback(callback) }
            lifecycleOwner.lifecycle.removeObserver(lifecycleObserver)
        }
    }

    LaunchedEffect(sessionExpired) {
        if (sessionExpired) {
            onSignOut()
        }
    }

    val effectiveUser = liveUser ?: authGate.userAccount
    if (effectiveUser != null && effectiveUser.isAuthorizedActive && !sessionExpired) {
        MainSituationRoomShell(
            user = effectiveUser,
            viewModel = viewModel,
            onSignOut = onSignOut
        )
    } else {
        AuthGateScreen(
            isSignedIn = true,
            isCheckingProfile = authGate.isCheckingProfile,
            needsBootstrap = authGate.needsBootstrap,
            userAccount = effectiveUser,
            errorMessage = authGate.errorMessage,
            onAuthSuccess = { viewModel.refreshUserProfile() },
            onInitializeAdmin = { name, phone -> viewModel.initializeFullControlAdmin(name, phone) },
            onRegisterPending = { name, phone -> viewModel.registerPendingAccount(name, phone) },
            onRefreshProfile = { viewModel.refreshUserProfile() },
            onSignOut = onSignOut
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainSituationRoomShell(
    user: UserAccount,
    viewModel: FdmisViewModel,
    onSignOut: () -> Unit
) {
    val showTestData by viewModel.showTestData.collectAsStateWithLifecycle()
    val selectedLga by viewModel.selectedLgaFilter.collectAsStateWithLifecycle()
    val metrics by viewModel.metrics.collectAsStateWithLifecycle()
    val wards by viewModel.wards.collectAsStateWithLifecycle()
    val pollingUnits by viewModel.pollingUnits.collectAsStateWithLifecycle()
    val managedUsers by viewModel.managedUsers.collectAsStateWithLifecycle()
    val checkIns by viewModel.checkIns.collectAsStateWithLifecycle()
    val incidents by viewModel.incidents.collectAsStateWithLifecycle()
    val results by viewModel.results.collectAsStateWithLifecycle()
    val publicResults by viewModel.publicResults.collectAsStateWithLifecycle()
    val timeline by viewModel.timeline.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()
    val offlineQueue by viewModel.offlineQueue.collectAsStateWithLifecycle()
    val offlineAttachments by viewModel.offlineAttachments.collectAsStateWithLifecycle()
    val syncHistory by viewModel.syncHistory.collectAsStateWithLifecycle()
    val syncMetrics by viewModel.syncDashboardMetrics.collectAsStateWithLifecycle()
    val pendingEditRequest by viewModel.pendingEditRequest.collectAsStateWithLifecycle()
    val globalSettings by viewModel.globalSettings.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()
    val importSummary by viewModel.latestImportSummary.collectAsStateWithLifecycle()

    val visibleWards = remember(wards, showTestData) { wards.filter { showTestData || !it.isTestData } }
    val visiblePus = remember(pollingUnits, showTestData) { pollingUnits.filter { showTestData || !it.isTestData } }
    val visibleCheckIns = remember(checkIns, showTestData) { checkIns.filter { showTestData || !it.isTestData } }
    val visibleIncidents = remember(incidents, showTestData) { incidents.filter { showTestData || !it.isTestData } }
    val visibleResults = remember(results, showTestData) { results.filter { showTestData || !it.isTestData } }
    val visibleTimeline = remember(timeline, showTestData) { timeline.filter { showTestData || !it.isTestData } }
    val pendingOfflineCount = syncMetrics.outstandingSyncCount

    var currentTab by rememberSaveable { mutableStateOf(FdmisTab.SITUATION_ROOM) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(pendingEditRequest) {
        when (pendingEditRequest?.itemType) {
            OfflineItemType.CHECK_IN, OfflineItemType.STATUS_UPDATE -> currentTab = FdmisTab.FIELD_OPS
            OfflineItemType.INCIDENT_REPORT -> currentTab = FdmisTab.INCIDENTS
            OfflineItemType.RESULT_SUBMISSION -> currentTab = FdmisTab.RESULTS
            null -> {}
        }
    }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    BackHandler(enabled = currentTab != FdmisTab.SITUATION_ROOM) {
        viewModel.recordUserInteraction()
        currentTab = FdmisTab.SITUATION_ROOM
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Row(modifier = Modifier.fillMaxSize()) {
            if (useNavigationRail) {
                NavigationRail(
                    containerColor = WhiteBackground
                ) {
                    FdmisTab.entries.forEach { tab ->
                        NavigationRailItem(
                            selected = currentTab == tab,
                            onClick = {
                                viewModel.recordUserInteraction()
                                currentTab = tab
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.shortLabel, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = EmeraldPrimary,
                                selectedTextColor = EmeraldDeep,
                                indicatorColor = EmeraldContainer,
                                unselectedIconColor = TextSecondaryLight,
                                unselectedTextColor = TextSecondaryLight
                            ),
                            modifier = Modifier.testTag("nav_${tab.name.lowercase()}")
                        )
                    }
                }
            }

            Scaffold(
                modifier = Modifier.weight(1f),
                containerColor = WhiteBackground,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                topBar = {
                    Column {
                        TopAppBar(
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = WhiteBackground,
                                titleContentColor = EmeraldDeep
                            ),
                            title = {
                                Column {
                                    Text(
                                        text = currentTab.label,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = EmeraldDeep,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "FDMIS · ${user.roleEnum.shortLabel}",
                                        style = MonoCodeStyle,
                                        color = TextSecondaryLight,
                                        maxLines = 1
                                    )
                                }
                            },
                            actions = {
                                if (pendingOfflineCount > 0) {
                                    Surface(
                                        onClick = {
                                            viewModel.recordUserInteraction()
                                            currentTab = FdmisTab.FIELD_OPS
                                        },
                                        color = AlertWarningContainer,
                                        contentColor = AlertWarning,
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.padding(end = 6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(Icons.Filled.CloudOff, contentDescription = "Pending Sync", modifier = Modifier.size(14.dp))
                                            Text("$pendingOfflineCount", style = MonoCodeStyle)
                                        }
                                    }
                                }
                                IconButton(
                                    onClick = onSignOut,
                                    modifier = Modifier.testTag("sign_out_button")
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Sign Out", tint = EmeraldDeep)
                                }
                            }
                        )
                        HorizontalDivider(color = BorderLight, thickness = 1.dp)
                        if (isBusy) {
                            LinearProgressIndicator(
                                modifier = Modifier.fillMaxWidth(),
                                color = EmeraldPrimary,
                                trackColor = EmeraldContainer
                            )
                        }
                    }
                },
                bottomBar = {
                    if (!useNavigationRail) {
                        Column {
                            HorizontalDivider(color = BorderLight, thickness = 1.dp)
                            NavigationBar(containerColor = WhiteBackground) {
                                FdmisTab.entries.forEach { tab ->
                                    NavigationBarItem(
                                        selected = currentTab == tab,
                                        onClick = {
                                            viewModel.recordUserInteraction()
                                            currentTab = tab
                                        },
                                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                                        label = { Text(tab.shortLabel, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = EmeraldPrimary,
                                            selectedTextColor = EmeraldDeep,
                                            indicatorColor = EmeraldContainer,
                                            unselectedIconColor = TextSecondaryLight,
                                            unselectedTextColor = TextSecondaryLight
                                        ),
                                        modifier = Modifier.testTag("nav_${tab.name.lowercase()}")
                                    )
                                }
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (currentTab) {
                        FdmisTab.SITUATION_ROOM -> SituationRoomScreen(
                            user = user,
                            metrics = metrics,
                            syncMetrics = syncMetrics,
                            wards = visibleWards,
                            pollingUnits = visiblePus,
                            incidents = visibleIncidents,
                            results = visibleResults,
                            timeline = visibleTimeline,
                            auditLogs = auditLogs,
                            selectedLgaId = selectedLga,
                            onSelectLga = viewModel::setLgaFilter,
                            onSyncNow = { viewModel.syncOfflineQueueNow(silentIfEmpty = false) },
                            onNavigateToDirectory = { currentTab = FdmisTab.DIRECTORY },
                            onNavigateToFieldOps = { currentTab = FdmisTab.FIELD_OPS },
                            onNavigateToIncidents = { currentTab = FdmisTab.INCIDENTS },
                            onNavigateToResults = { currentTab = FdmisTab.RESULTS },
                            onNavigateToOpsHub = { currentTab = FdmisTab.OPS_HUB }
                        )
                        FdmisTab.DIRECTORY -> DirectoryScreen(
                            user = user,
                            wards = visibleWards,
                            pollingUnits = visiblePus,
                            managedUsers = managedUsers,
                            selectedLgaId = selectedLga,
                            validationReport = viewModel.validationReport,
                            importSummary = importSummary,
                            onSelectLga = viewModel::setLgaFilter,
                            onVerifyAndSyncMasterDirectory = { viewModel.importMasterDirectory(silentIfAlreadySynced = false) },
                            onCorrectMasterPu = viewModel::correctMasterPollingUnit,
                            onAssignAgent = viewModel::assignAgentToPu
                        )
                        FdmisTab.FIELD_OPS -> FieldOpsScreen(
                            user = user,
                            pollingUnits = visiblePus,
                            checkIns = visibleCheckIns,
                            offlineQueue = offlineQueue,
                            offlineAttachments = offlineAttachments,
                            syncHistory = syncHistory,
                            syncMetrics = syncMetrics,
                            editRequest = pendingEditRequest,
                            onConsumeEditRequest = viewModel::clearPendingEditRequest,
                            onAutoSaveCheckInDraft = viewModel::autoSaveCheckInDraft,
                            onSubmitCheckIn = viewModel::submitCheckIn,
                            onUpdatePuStatus = viewModel::updatePuStatus,
                            onSyncQueue = { viewModel.syncOfflineQueueNow(silentIfEmpty = false) },
                            onArchiveConfirmedQueue = viewModel::archiveConfirmedQueueEntries,
                            onEditOfflineReport = viewModel::openOfflineReportForEditing
                        )
                        FdmisTab.INCIDENTS -> IncidentsScreen(
                            user = user,
                            pollingUnits = visiblePus,
                            incidents = visibleIncidents,
                            syncMetrics = syncMetrics,
                            editRequest = pendingEditRequest,
                            onConsumeEditRequest = viewModel::clearPendingEditRequest,
                            onSyncNow = { viewModel.syncOfflineQueueNow(silentIfEmpty = false) },
                            onAutoSaveIncidentDraft = viewModel::autoSaveIncidentDraft,
                            onSubmitIncident = viewModel::submitIncident,
                            onUpdateIncident = viewModel::updateIncidentWorkflow
                        )
                        FdmisTab.RESULTS -> ResultsScreen(
                            user = user,
                            pollingUnits = visiblePus,
                            results = visibleResults,
                            publicResults = publicResults,
                            globalSettings = globalSettings,
                            syncMetrics = syncMetrics,
                            editRequest = pendingEditRequest,
                            onConsumeEditRequest = viewModel::clearPendingEditRequest,
                            onSyncNow = { viewModel.syncOfflineQueueNow(silentIfEmpty = false) },
                            onAutoSaveResultDraft = viewModel::autoSaveResultDraft,
                            onSubmitResult = viewModel::submitResult,
                            onReviewResult = viewModel::reviewResult,
                            onLoadHistory = viewModel::loadResultHistory
                        )
                        FdmisTab.OPS_HUB -> AdminAndOpsScreen(
                            user = user,
                            timeline = visibleTimeline,
                            notifications = notifications,
                            pollingUnits = visiblePus,
                            wards = visibleWards,
                            incidents = visibleIncidents,
                            results = visibleResults,
                            managedUsers = managedUsers,
                            auditLogs = auditLogs,
                            globalSettings = globalSettings,
                            showTestData = showTestData,
                            onPostAnnouncement = viewModel::postAnnouncement,
                            onUpdateUserRole = viewModel::updateUserRoleAndScope,
                            onRevokeEmergency = viewModel::revokeUserEmergency,
                            onUpdateGlobalSettings = viewModel::updateGlobalSettings,
                            onToggleTestData = viewModel::toggleShowTestData,
                            onShowMessage = viewModel::showMessage
                        )
                    }
                }
            }
        }
    }
}
