package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.DirectoryValidationReport
import com.example.data.model.DirectoryImportSummary
import com.example.data.model.LgaDefinition
import com.example.data.model.PollingUnit
import com.example.data.model.PuOperationalStatus
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.model.Ward
import com.example.ui.components.EmptyOperationalState
import com.example.ui.components.LgaFilterBar
import com.example.ui.components.PuStatusBadge
import com.example.ui.components.StatusBadge
import com.example.ui.components.TestDataTag
import com.example.ui.theme.AlertCritical
import com.example.ui.theme.AlertWarning
import com.example.ui.theme.AlertWarningContainer
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CivicGold
import com.example.ui.theme.CivicGoldContainer
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.OnCivicGoldContainer
import com.example.ui.theme.SoftGreySurface
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusInfoContainer
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.StatusVerifiedContainer
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.WhiteBackground

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DirectoryScreen(
    user: UserAccount,
    wards: List<Ward>,
    pollingUnits: List<PollingUnit>,
    managedUsers: List<UserAccount>,
    selectedLgaId: String?,
    validationReport: DirectoryValidationReport,
    importSummary: DirectoryImportSummary?,
    onSelectLga: (String?) -> Unit,
    onVerifyAndSyncMasterDirectory: () -> Unit,
    onCorrectMasterPu: (PollingUnit, String, String, Double?, Double?, Boolean, Long, String) -> Unit,
    onAssignAgent: (PollingUnit, UserAccount) -> Unit
) {
    val canAssign = user.roleEnum.canAssignFieldUsers()
    val canCorrectMaster = user.roleEnum.canCorrectMasterDirectory()
    var subTab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedWardId by remember { mutableStateOf<String?>(null) }
    var showAdvisories by remember { mutableStateOf(false) }

    var assignTargetPu by remember { mutableStateOf<PollingUnit?>(null) }
    var correctionTargetPu by remember { mutableStateOf<PollingUnit?>(null) }

    val officialPusOnly = remember(pollingUnits) { pollingUnits.filter { !it.isTestData } }
    val funtuaDbCount = remember(officialPusOnly) { officialPusOnly.count { it.lgaId == LgaDefinition.FUNTUA.id } }
    val dandumeDbCount = remember(officialPusOnly) { officialPusOnly.count { it.lgaId == LgaDefinition.DANDUME.id } }
    val totalDbCount = officialPusOnly.size

    val filteredWards = remember(wards, selectedLgaId) {
        wards.filter { selectedLgaId == null || it.lgaId == selectedLgaId }
            .sortedWith(compareBy({ it.lgaId }, { it.wardCode }))
    }
    val filteredPus = remember(pollingUnits, selectedLgaId, selectedWardId, searchQuery) {
        pollingUnits.filter { pu ->
            (selectedLgaId == null || pu.lgaId == selectedLgaId) &&
                (selectedWardId == null || pu.wardId == selectedWardId) &&
                (searchQuery.isBlank() ||
                    pu.puCode.contains(searchQuery, ignoreCase = true) ||
                    pu.name.contains(searchQuery, ignoreCase = true) ||
                    pu.wardName.contains(searchQuery, ignoreCase = true))
        }.sortedBy { it.puCode }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        val tabs = listOf("Directory", "Verified Map")
        SecondaryTabRow(
            selectedTabIndex = subTab.coerceIn(0, tabs.lastIndex),
            containerColor = WhiteBackground
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = subTab == index,
                    onClick = { subTab = index },
                    text = { Text(title, maxLines = 1) }
                )
            }
        }

        if (subTab == 0) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Preloaded Master Directory Summary & Validation Report Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                        border = BorderStroke(1.dp, BorderLight)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Preloaded Official PU Register",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = EmeraldDeep
                                    )
                                    Text(
                                        text = "Controlled Master Dataset · ${validationReport.datasetVersion}",
                                        style = MonoCodeStyle,
                                        color = TextSecondaryLight
                                    )
                                }
                                StatusBadge(
                                    label = if (validationReport.isValid && totalDbCount >= 475) "Verified 475" else "Master Sync",
                                    icon = Icons.Filled.Verified,
                                    containerColor = if (validationReport.isValid) StatusVerifiedContainer else AlertWarningContainer,
                                    contentColor = if (validationReport.isValid) StatusVerified else AlertWarning
                                )
                            }

                            Surface(
                                color = SoftGreySurface,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, BorderLight),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "Funtua (20-14): $funtuaDbCount / ${validationReport.funtuaPuCount} PUs · ${validationReport.funtuaWardCount} Wards",
                                        style = MonoCodeStyle,
                                        color = TextPrimaryLight
                                    )
                                    Text(
                                        text = "Dandume (20/07): $dandumeDbCount / ${validationReport.dandumePuCount} PUs · ${validationReport.dandumeWardCount} Wards",
                                        style = MonoCodeStyle,
                                        color = TextPrimaryLight
                                    )
                                    Text(
                                        text = "Combined Database: $totalDbCount / ${validationReport.totalPuCount} PUs · Duplicates: ${validationReport.duplicateCodeCount} · Invalid: ${validationReport.invalidOrIncompleteCount}",
                                        style = MonoCodeStyle,
                                        color = EmeraldPrimary
                                    )
                                    importSummary?.let { summary ->
                                        Text(
                                            text = "Last Sync Verification: +${summary.totalNewlyImported} newly added · Counts Verified: ${if (summary.countsVerified) "YES" else "PENDING"}",
                                            style = MonoCodeStyle,
                                            color = StatusVerified
                                        )
                                    }
                                }
                            }

                            Text(
                                text = "Ordinary ward/PU creation and deletion are disabled. Only Full Control Admin may apply audited, backup-protected master record corrections.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryLight
                            )

                            if (validationReport.advisories.isNotEmpty()) {
                                OutlinedButton(
                                    onClick = { showAdvisories = !showAdvisories },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        imageVector = if (showAdvisories) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.size(6.dp))
                                    Text("Manual Verification Advisories (${validationReport.advisories.size})")
                                }
                                if (showAdvisories) {
                                    Surface(
                                        color = CivicGoldContainer,
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(10.dp),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            validationReport.advisories.forEach { advisory ->
                                                Text(
                                                    text = "• $advisory",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = OnCivicGoldContainer
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            if (canCorrectMaster) {
                                Button(
                                    onClick = onVerifyAndSyncMasterDirectory,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("verify_sync_master_directory_btn")
                                ) {
                                    Icon(Icons.Filled.Sync, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.size(8.dp))
                                    Text("Verify & Sync Master Directory (Idempotent)")
                                }
                            }
                        }
                    }
                }

                item {
                    LgaFilterBar(
                        selectedLgaId = selectedLgaId,
                        onSelectLga = {
                            onSelectLga(it)
                            selectedWardId = null
                        },
                        canViewAllLgas = user.roleEnum.canManageAllLgas()
                    )
                }

                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Search PU code, name, or ward") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("directory_search_input")
                    )
                }

                // Wards Section
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Registered Wards (${filteredWards.size})",
                            style = MaterialTheme.typography.titleMedium,
                            color = EmeraldDeep
                        )
                        if (selectedWardId != null) {
                            TextButton(onClick = { selectedWardId = null }) {
                                Text("Clear Ward Filter")
                            }
                        }
                    }
                }

                if (filteredWards.isEmpty()) {
                    item {
                        EmptyOperationalState(
                            title = "Awaiting Master Directory Sync",
                            description = "Funtua (11 wards, 298 PUs) and Dandume 20/07 (11 wards, 177 PUs) are preloaded from official INEC source PDFs and will appear once synchronized by Full Control Admin.",
                            actionLabel = if (canCorrectMaster) "Sync Master Directory Now" else null,
                            onAction = if (canCorrectMaster) onVerifyAndSyncMasterDirectory else null
                        )
                    }
                } else {
                    items(filteredWards, key = { it.id }) { ward ->
                        val wardPuCount = pollingUnits.count { it.wardId == ward.id }
                        val isSelected = selectedWardId == ward.id
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedWardId = if (isSelected) null else ward.id },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) EmeraldContainer else WhiteBackground
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) EmeraldPrimary else BorderLight
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = ward.name,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = TextPrimaryLight
                                        )
                                        if (ward.isTestData) TestDataTag()
                                    }
                                    Text(
                                        text = "${ward.lgaId.uppercase()} · Code ${ward.wardCode} · $wardPuCount / ${ward.expectedPollingUnits} PUs",
                                        style = MonoCodeStyle,
                                        color = TextSecondaryLight
                                    )
                                }
                                Text(
                                    text = if (isSelected) "Filtered" else "Filter",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = EmeraldPrimary
                                )
                            }
                        }
                    }
                }

                // Polling Units Section
                item {
                    Text(
                        text = "Polling Units (${filteredPus.size})",
                        style = MaterialTheme.typography.titleMedium,
                        color = EmeraldDeep
                    )
                }

                if (filteredPus.isEmpty()) {
                    item {
                        EmptyOperationalState(
                            title = "No matching polling units found.",
                            description = "Adjust your LGA, Ward, or search filter, or synchronize the preloaded master directory."
                        )
                    }
                } else {
                    items(filteredPus, key = { it.id }) { pu ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                            border = BorderStroke(1.dp, BorderLight)
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = pu.puCode,
                                        style = MonoCodeStyle,
                                        color = EmeraldPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Surface(
                                            color = if (pu.puStatusLabel.contains("NEW", ignoreCase = true)) StatusInfoContainer else SoftGreySurface,
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = pu.puStatusLabel,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (pu.puStatusLabel.contains("NEW", ignoreCase = true)) StatusInfo else TextSecondaryLight,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                            )
                                        }
                                        if (pu.isTestData) TestDataTag()
                                        PuStatusBadge(pu.statusEnum)
                                    }
                                }
                                Text(pu.name, style = MaterialTheme.typography.titleMedium, color = TextPrimaryLight)
                                Text(
                                    text = "${pu.wardName} (${pu.lgaId.uppercase()}) · ${pu.locationDescription.ifBlank { "Official directory entry" }}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondaryLight
                                )
                                Text(
                                    text = "Agent: ${pu.assignedAgentName.ifBlank { "Unassigned" }} · Reg: ${pu.registeredVoters}",
                                    style = MonoCodeStyle,
                                    color = TextSecondaryLight
                                )
                                if (canAssign || canCorrectMaster) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (canCorrectMaster) {
                                            TextButton(
                                                onClick = { correctionTargetPu = pu },
                                                modifier = Modifier.testTag("correct_master_pu_${pu.id}")
                                            ) {
                                                Icon(Icons.Filled.EditNote, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.size(4.dp))
                                                Text("Controlled Edit")
                                            }
                                        }
                                        if (canAssign) {
                                            TextButton(
                                                onClick = { assignTargetPu = pu },
                                                modifier = Modifier.testTag("assign_agent_${pu.id}")
                                            ) {
                                                Icon(Icons.Filled.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.size(4.dp))
                                                Text("Assign Agent")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            VerifiedCoordinateMapPanel(pollingUnits = filteredPus)
        }
    }

    assignTargetPu?.let { targetPu ->
        AssignAgentDialog(
            pu = targetPu,
            users = managedUsers.filter {
                it.roleEnum != UserRole.FULL_CONTROL_ADMIN &&
                    (it.assignedLgaId.isBlank() || it.assignedLgaId == targetPu.lgaId)
            },
            onDismiss = { assignTargetPu = null },
            onAssign = { agent ->
                onAssignAgent(targetPu, agent)
                assignTargetPu = null
            }
        )
    }

    correctionTargetPu?.let { targetPu ->
        ControlledMasterPuCorrectionDialog(
            pu = targetPu,
            onDismiss = { correctionTargetPu = null },
            onConfirmCorrection = { name, location, lat, lng, coordsVerified, regVoters, reason ->
                onCorrectMasterPu(targetPu, name, location, lat, lng, coordsVerified, regVoters, reason)
                correctionTargetPu = null
            }
        )
    }
}

@Composable
private fun VerifiedCoordinateMapPanel(pollingUnits: List<PollingUnit>) {
    val mappedPus = pollingUnits.filter { it.coordinatesVerified && it.latitude != null && it.longitude != null }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Verified Coordinate Tactical Plot",
                style = MaterialTheme.typography.titleMedium,
                color = EmeraldDeep
            )
            Text(
                text = "Displays ONLY polling units with officially verified coordinates. Zero fabricated coordinates are plotted.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondaryLight
            )
        }
        if (mappedPus.isEmpty()) {
            item {
                EmptyOperationalState(
                    title = "No verified polling unit coordinates available.",
                    description = "Master directory entries preserve official INEC names and codes without guessing GPS positions. A Full Control Admin can add verified coordinates through Controlled Edit.",
                    icon = Icons.Filled.Map
                )
            }
        } else {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp),
                    colors = CardDefaults.cardColors(containerColor = SoftGreySurface),
                    border = BorderStroke(1.dp, EmeraldPrimary)
                ) {
                    val minLat = mappedPus.minOf { it.latitude!! }
                    val maxLat = mappedPus.maxOf { it.latitude!! }.let { if (it == minLat) minLat + 0.05 else it }
                    val minLng = mappedPus.minOf { it.longitude!! }
                    val maxLng = mappedPus.maxOf { it.longitude!! }.let { if (it == minLng) minLng + 0.05 else it }

                    Canvas(modifier = Modifier.fillMaxSize().padding(20.dp)) {
                        val stepX = size.width / 4f
                        val stepY = size.height / 4f
                        for (i in 0..4) {
                            drawLine(BorderLight, Offset(stepX * i, 0f), Offset(stepX * i, size.height), 1.5f)
                            drawLine(BorderLight, Offset(0f, stepY * i), Offset(size.width, stepY * i), 1.5f)
                        }
                        mappedPus.forEach { pu ->
                            val nx = ((pu.longitude!! - minLng) / (maxLng - minLng)).toFloat()
                            val ny = 1f - ((pu.latitude!! - minLat) / (maxLat - minLat)).toFloat()
                            val cx = nx * size.width
                            val cy = ny * size.height
                            val color = when (pu.statusEnum) {
                                PuOperationalStatus.INCIDENT_REPORTED, PuOperationalStatus.COMMUNICATION_LOST -> AlertCritical
                                PuOperationalStatus.RESULT_VERIFIED -> StatusVerified
                                else -> CivicGold
                            }
                            drawCircle(color = color.copy(alpha = 0.24f), radius = 22f, center = Offset(cx, cy))
                            drawCircle(color = color, radius = 9f, center = Offset(cx, cy))
                        }
                    }
                }
            }
            items(mappedPus, key = { it.id }) { pu ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.LocationOn, contentDescription = null, tint = EmeraldPrimary)
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${pu.puCode} · ${pu.name}", style = MaterialTheme.typography.titleSmall, color = TextPrimaryLight)
                            Text("Lat ${pu.latitude}, Lng ${pu.longitude}", style = MonoCodeStyle, color = TextSecondaryLight)
                        }
                        PuStatusBadge(pu.statusEnum)
                    }
                }
            }
        }
    }
}

@Composable
private fun AssignAgentDialog(
    pu: PollingUnit,
    users: List<UserAccount>,
    onDismiss: () -> Unit,
    onAssign: (UserAccount) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filteredUsers = remember(users, query) {
        users.filter {
            query.isBlank() ||
                it.displayName.contains(query, ignoreCase = true) ||
                it.email.contains(query, ignoreCase = true) ||
                it.roleEnum.label.contains(query, ignoreCase = true)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = WhiteBackground,
        title = { Text("Assign Agent to ${pu.puCode}", color = EmeraldDeep) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(pu.name, style = MaterialTheme.typography.bodySmall, color = TextSecondaryLight)
                if (users.isEmpty()) {
                    Text(
                        text = "No authorized field users found for ${pu.lgaId.uppercase()}. Ask the field agent to sign in and request LGA approval first.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimaryLight
                    )
                } else {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        label = { Text("Search user name or email") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    LazyColumn(modifier = Modifier.height(240.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(filteredUsers, key = { it.uid }) { candidate ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onAssign(candidate) },
                                colors = CardDefaults.cardColors(containerColor = SoftGreySurface),
                                border = BorderStroke(1.dp, BorderLight)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(candidate.displayName, style = MaterialTheme.typography.titleSmall, color = TextPrimaryLight)
                                    Text("${candidate.email} · ${candidate.roleEnum.shortLabel}", style = MonoCodeStyle, color = TextSecondaryLight)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun ControlledMasterPuCorrectionDialog(
    pu: PollingUnit,
    onDismiss: () -> Unit,
    onConfirmCorrection: (String, String, Double?, Double?, Boolean, Long, String) -> Unit
) {
    var correctedName by remember { mutableStateOf(pu.name) }
    var correctedLocation by remember { mutableStateOf(pu.locationDescription) }
    var registeredText by remember { mutableStateOf(pu.registeredVoters.toString()) }
    var coordsVerified by remember { mutableStateOf(pu.coordinatesVerified) }
    var latText by remember { mutableStateOf(pu.latitude?.toString() ?: "") }
    var lngText by remember { mutableStateOf(pu.longitude?.toString() ?: "") }
    var reason by remember { mutableStateOf("") }
    var confirmed by remember { mutableStateOf(false) }

    val parsedLat = latText.toDoubleOrNull()
    val parsedLng = lngText.toDoubleOrNull()
    val coordsValid = !coordsVerified || (parsedLat != null && parsedLng != null)
    val canSubmit = correctedName.trim().length >= 2 &&
        reason.trim().length >= 5 &&
        confirmed &&
        coordsValid

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = WhiteBackground,
        title = { Text("Controlled Master Edit · ${pu.puCode}", color = EmeraldDeep) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = CivicGoldContainer,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Master Directory Protection: Saving writes an immutable snapshot to directory_backups and logs an audit entry. PU Code (${pu.puCode}) and Ward (${pu.wardName}) remain locked.",
                        style = MaterialTheme.typography.bodySmall,
                        color = OnCivicGoldContainer,
                        modifier = Modifier.padding(10.dp)
                    )
                }
                OutlinedTextField(
                    value = correctedName,
                    onValueChange = { correctedName = it },
                    label = { Text("Official Polling Unit Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("master_edit_name_input")
                )
                OutlinedTextField(
                    value = correctedLocation,
                    onValueChange = { correctedLocation = it },
                    label = { Text("Location Description") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = registeredText,
                    onValueChange = { registeredText = it.filter(Char::isDigit) },
                    label = { Text("Official Registered Voters") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Verified GPS Coordinates", style = MaterialTheme.typography.bodySmall)
                    Switch(checked = coordsVerified, onCheckedChange = { coordsVerified = it })
                }
                if (coordsVerified) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = latText,
                            onValueChange = { latText = it },
                            label = { Text("Latitude") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = lngText,
                            onValueChange = { lngText = it },
                            label = { Text("Longitude") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("Mandatory Correction Reason (min 5 chars)") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth().testTag("master_edit_reason_input")
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = confirmed,
                        onCheckedChange = { confirmed = it },
                        modifier = Modifier.testTag("master_edit_confirm_checkbox")
                    )
                    Text(
                        text = "I confirm backup snapshot creation and audit logging for this master directory correction.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimaryLight
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirmCorrection(
                        correctedName,
                        correctedLocation,
                        if (coordsVerified) parsedLat else null,
                        if (coordsVerified) parsedLng else null,
                        coordsVerified,
                        registeredText.toLongOrNull() ?: 0L,
                        reason
                    )
                },
                enabled = canSubmit,
                modifier = Modifier.testTag("master_edit_submit_btn")
            ) {
                Text("Backup & Save Correction")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
