package com.example.util

import com.example.data.model.PollingUnit
import com.example.data.model.ResultSubmission
import com.example.data.model.IncidentReport
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReportGenerator {
    private fun timestampNow(): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss z", Locale.getDefault()).format(Date())

    private fun csvEscape(value: String): String {
        val cleaned = value.replace("\"", "\"\"")
        return "\"$cleaned\""
    }

    fun buildPollingUnitStatusCsv(
        areaLabel: String,
        pollingUnits: List<PollingUnit>
    ): String {
        val sb = StringBuilder()
        sb.appendLine("# Report: Polling Unit Operational Status Summary")
        sb.appendLine("# Generated: ${timestampNow()}")
        sb.appendLine("# Geographical Area: $areaLabel")
        sb.appendLine("# Total Records: ${pollingUnits.size}")
        sb.appendLine("LGA,Ward,PU Code,PU Name,Location,Assigned Agent,Operational Status,Registered Voters,Test Data")
        pollingUnits.forEach { pu ->
            sb.appendLine(
                listOf(
                    csvEscape(pu.lgaId.uppercase()),
                    csvEscape(pu.wardName),
                    csvEscape(pu.puCode),
                    csvEscape(pu.name),
                    csvEscape(pu.locationDescription),
                    csvEscape(pu.assignedAgentName.ifBlank { "Unassigned" }),
                    csvEscape(pu.statusEnum.label),
                    pu.registeredVoters.toString(),
                    pu.isTestData.toString()
                ).joinToString(",")
            )
        }
        return sb.toString()
    }

    fun buildIncidentsCsv(
        areaLabel: String,
        incidents: List<IncidentReport>
    ): String {
        val sb = StringBuilder()
        sb.appendLine("# Report: Election-Day Incident Log")
        sb.appendLine("# Generated: ${timestampNow()}")
        sb.appendLine("# Geographical Area: $areaLabel")
        sb.appendLine("# Total Records: ${incidents.size}")
        sb.appendLine("LGA,PU Code,PU Name,Title,Category,Urgency,Status,Reporter,Escalated To,Test Data")
        incidents.forEach { inc ->
            sb.appendLine(
                listOf(
                    csvEscape(inc.lgaId.uppercase()),
                    csvEscape(inc.puCode),
                    csvEscape(inc.puName),
                    csvEscape(inc.title),
                    csvEscape(inc.category),
                    csvEscape(inc.urgencyEnum.label),
                    csvEscape(inc.statusEnum.label),
                    csvEscape(inc.reporterName),
                    csvEscape(inc.escalatedTo),
                    inc.isTestData.toString()
                ).joinToString(",")
            )
        }
        return sb.toString()
    }

    fun buildResultsCsv(
        areaLabel: String,
        results: List<ResultSubmission>
    ): String {
        val sb = StringBuilder()
        sb.appendLine("# Report: Polling Unit Results & Verification Summary")
        sb.appendLine("# Generated: ${timestampNow()}")
        sb.appendLine("# Geographical Area: $areaLabel")
        sb.appendLine("# Total Records: ${results.size}")
        sb.appendLine("LGA,Ward,PU Code,PU Name,Registered,Accredited,Valid Votes,Rejected Votes,Total Cast,BVAS Status,Verification Status,Publicly Approved,Version,Test Data")
        results.forEach { r ->
            sb.appendLine(
                listOf(
                    csvEscape(r.lgaId.uppercase()),
                    csvEscape(r.wardName),
                    csvEscape(r.puCode),
                    csvEscape(r.puName),
                    r.registeredVoters.toString(),
                    r.accreditedVoters.toString(),
                    r.validVotes.toString(),
                    r.rejectedVotes.toString(),
                    r.totalVotesCast.toString(),
                    csvEscape(r.bvasStatus),
                    csvEscape(r.verificationEnum.label),
                    r.publiclyApproved.toString(),
                    r.version.toString(),
                    r.isTestData.toString()
                ).joinToString(",")
            )
        }
        return sb.toString()
    }

    fun buildExecutiveTextReport(
        areaLabel: String,
        pollingUnits: List<PollingUnit>,
        incidents: List<IncidentReport>,
        results: List<ResultSubmission>
    ): String {
        val reportingCount = pollingUnits.count { it.statusEnum.isReporting() }
        val activeIncidents = incidents.count { it.statusEnum.isActive() }
        val criticalIncidents = incidents.count { it.statusEnum.isActive() && it.urgency == "CRITICAL" }
        val verifiedResults = results.filter { it.verificationStatus == "VERIFIED" }
        return buildString {
            appendLine("==================================================")
            appendLine("FUNTUA-DANDUME MANDATE INTELLIGENCE SYSTEM (FDMIS)")
            appendLine("SITUATION ROOM OPERATIONAL SUMMARY REPORT")
            appendLine("==================================================")
            appendLine("Generated: ${timestampNow()}")
            appendLine("Geographical Scope: $areaLabel")
            appendLine("Data Status: Live Operational Records")
            appendLine("--------------------------------------------------")
            appendLine("POLLING UNITS REGISTERED : ${pollingUnits.size}")
            appendLine("POLLING UNITS REPORTING  : $reportingCount")
            appendLine("AGENTS ASSIGNED          : ${pollingUnits.count { it.assignedAgentUid.isNotBlank() }}")
            appendLine("ACTIVE INCIDENTS         : $activeIncidents (Critical: $criticalIncidents)")
            appendLine("RESULTS SUBMITTED        : ${results.size}")
            appendLine("RESULTS VERIFIED         : ${verifiedResults.size}")
            if (verifiedResults.isNotEmpty()) {
                appendLine("--------------------------------------------------")
                appendLine("VERIFIED VOTE TALLIES (INTERNAL)")
                appendLine("Accredited Voters : ${verifiedResults.sumOf { it.accreditedVoters }}")
                appendLine("Valid Votes       : ${verifiedResults.sumOf { it.validVotes }}")
                appendLine("Rejected Votes    : ${verifiedResults.sumOf { it.rejectedVotes }}")
                appendLine("Total Votes Cast  : ${verifiedResults.sumOf { it.totalVotesCast }}")
            }
            appendLine("==================================================")
        }
    }
}
