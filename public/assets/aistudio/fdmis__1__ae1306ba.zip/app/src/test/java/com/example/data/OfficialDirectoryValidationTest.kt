package com.example.data

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.OfficialDirectoryCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE)
class OfficialDirectoryValidationTest {

    @Test
    fun preloadedOfficialDirectory_matchesPdfCountsAndHasZeroDuplicatesOrInvalidRecords() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dataset = OfficialDirectoryCatalog.loadFromContext(context)
        val report = OfficialDirectoryCatalog.validate(dataset)

        assertTrue("Expected dataset validation to pass, errors: ${report.invalidReasons}", report.isValid)
        assertEquals(11, report.funtuaWardCount)
        assertEquals(11, report.dandumeWardCount)
        assertEquals(298, report.funtuaPuCount)
        assertEquals(177, report.dandumePuCount)
        assertEquals(475, report.totalPuCount)
        assertEquals(0, report.duplicateCodeCount)
        assertEquals(0, report.invalidOrIncompleteCount)

        // Spot-check verbatim PDF spelling / hyphen corrections inspected from page images
        val puFuntua5 = dataset.pollingUnits.first { it.puCode == "20-14-05-003" }
        assertEquals("UNG.MUSA READING ROOM", puFuntua5.name)

        val puDandumeFili = dataset.pollingUnits.first { it.puCode == "20-07-09-004" }
        assertEquals("UNG. FILI/KOFAR GIDAN INUWA", puDandumeFili.name)

        val puDanGaga = dataset.pollingUnits.first { it.puCode == "20-07-03-001" }
        assertEquals("DOGON KAWU/K/G. DAN-GAGA", puDanGaga.name)

        val puDanSoda = dataset.pollingUnits.first { it.puCode == "20-07-11-002" }
        assertEquals("UNG. DAN SODA/DAN-SODA PRI.SCHOOL", puDanSoda.name)
    }
}
