package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.HowToVote
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SecondaryScrollableTabRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.firebase.OfflineAttachmentDraft
import com.example.data.local.OfflineItemType
import com.example.data.local.OfflineSyncStatus
import com.example.data.model.BvasStatus
import com.example.data.model.GlobalSettings
import com.example.data.model.PollingUnit
import com.example.data.model.PublicVerifiedResult
import com.example.data.model.ResultHistoryEntry
import com.example.data.model.ResultSubmission
import com.example.data.model.UserAccount
import com.example.data.model.VerificationStatus
import com.example.ui.components.Base64EvidencePreview
import com.example.ui.components.CameraAndPickerEvidenceSection
import com.example.ui.components.CompactSyncBanner
import com.example.ui.components.EmptyOperationalState
import com.example.ui.components.KpiTile
import com.example.ui.components.SearchablePollingUnitField
import com.example.ui.components.TestDataTag
import com.example.ui.components.VerificationBadge
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.AlertWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.SoftGreySurface
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.WhiteBackground
import com.example.ui.viewmodel.OfflineReportEditRequest
import com.example.ui.viewmodel.SyncDashboardMetrics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultsScreen(
    user: UserAccount,
    pollingUnits: List<PollingUnit>,
    results: List<ResultSubmission>,
    publicResults: List<PublicVerifiedResult>,
    globalSettings: GlobalSettings,
    syncMetrics: SyncDashboardMetrics,
    editRequest: OfflineReportEditRequest?,
    onConsumeEditRequest: () -> Unit,
    onSyncNow: () -> Unit,
    onAutoSaveResultDraft: (String, PollingUnit?, Long, Long, Long, Long, String, String, String, ResultSubmission?, OfflineAttachmentDraft?) -> Unit,
    onSubmitResult: (
        PollingUnit,
        Long,
        Long,
        Long,
        Long,
        String,
        String,
        String,
        String?,
        String?,
        ResultSubmission?,
        OfflineAttachmentDraft?,
        String?
    ) -> Unit,
    onReviewResult: (ResultSubmission, VerificationStatus, String, Boolean) -> Unit,
    onLoadHistory: suspend (String) -> List<ResultHistoryEntry>
) {
    val scope = rememberCoroutineScope()
    val canVerify = user.roleEnum.canVerifyResults()
    val tabs = remember(canVerify) {
        if (canVerify) listOf("Submissions", "Submit / Revise", "Verification", "Public Summary")
        else listOf("Submissions", "Submit / Revise", "Public Summary")
    }
    var subTab by remember { mutableIntStateOf(0) }
    var editingSubmission by remember { mutableStateOf<ResultSubmission?>(null) }
    var reviewTarget by remember { mutableStateOf<ResultSubmission?>(null) }
    var historyTarget by remember { mutableStateOf<Pair<ResultSubmission, List<ResultHistoryEntry>>?>(null) }

    LaunchedEffect(editRequest) {
        if (editRequest?.itemType == OfflineItemType.RESULT_SUBMISSION) {
            subTab = 1
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        SecondaryScrollableTabRow(
            selectedTabIndex = subTab.coerceIn(0, tabs.lastIndex),
            edgePadding = 12.dp,
            containerColor = WhiteBackground
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = subTab == index,
                    onClick = { subTab = index },
                    text = { Text(title, maxLines = 1) }
                )
            }
        }

        when {
            subTab == 0 -> {
                SubmissionsFeedPanel(
                    user = user,
                    results = results,
                    syncMetrics = syncMetrics,
                    onSyncNow = onSyncNow,
                    onViewHistory = { sub ->
                        scope.launch {
                            val entries = onLoadHistory(sub.id)
                            historyTarget = sub to entries
                        }
                    },
                    onRevise = { sub ->
                        editingSubmission = sub
                        subTab = 1
                    },
                    onGoToSubmit = {
                        editingSubmission = null
                        subTab = 1
                    }
                )
            }
            subTab == 1 -> {
                SubmitOrReviseResultPanel(
                    user = user,
                    pollingUnits = pollingUnits,
                    results = results,
                    syncMetrics = syncMetrics,
                    editRequest = editRequest,
                    onConsumeEditRequest = onConsumeEditRequest,
                    onSyncNow = onSyncNow,
                    editingSubmission = editingSubmission,
                    onClearEditing = { editingSubmission = null },
                    onAutoSaveResultDraft = onAutoSaveResultDraft,
                    onSubmitResult = { pu, reg, acc, valid, rej, bvasSt, bvasNote, subNote, b64, name, existing, draftAtt, reportId ->
                        onSubmitResult(pu, reg, acc, valid, rej, bvasSt, bvasNote, subNote, b64, name, existing, draftAtt, reportId)
                        editingSubmission = null
                        subTab = 0
                    }
                )
            }
            canVerify && subTab == 2 -> {
                VerificationCenterPanel(
                    results = results,
                    onReviewClick = { reviewTarget = it },
                    onViewHistory = { sub ->
                        scope.launch {
                            val entries = onLoadHistory(sub.id)
                            historyTarget = sub to entries
                        }
                    }
                )
            }
            else -> {
                PublicSummaryPanel(
                    publicResults = publicResults,
                    enabled = globalSettings.publicSummaryEnabled
                )
            }
        }
    }

    reviewTarget?.let { target ->
        ReviewResultDialog(
            submission = target,
            canPublishPublic = user.roleEnum.canApprovePublicResults(),
            onDismiss = { reviewTarget = null },
            onSave = { newStatus, note, publish ->
                onReviewResult(target, newStatus, note, publish)
                reviewTarget = null
            }
        )
    }

    historyTarget?.let { (sub, entries) ->
        ResultHistoryDialog(
            submission = sub,
            entries = entries,
            onDismiss = { historyTarget = null }
        )
    }
}

@Composable
private fun SubmissionsFeedPanel(
    user: UserAccount,
    results: List<ResultSubmission>,
    syncMetrics: SyncDashboardMetrics,
    onSyncNow: () -> Unit,
    onViewHistory: (ResultSubmission) -> Unit,
    onRevise: (ResultSubmission) -> Unit,
    onGoToSubmit: () -> Unit
) {
    val verifiedCount = remember(results) { results.count { it.verificationEnum == VerificationStatus.VERIFIED } }
    val pendingCount = remember(results) { results.size - verifiedCount }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            CompactSyncBanner(
                metrics = syncMetrics,
                onSyncNow = onSyncNow
            )
        }
        if (results.isNotEmpty()) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    KpiTile("Pending / Unverified", "$pendingCount", "Not yet verified", StatusInfo, Modifier.weight(1f))
                    KpiTile("Official Verified", "$verifiedCount", "Audit-signed EC8A", StatusVerified, Modifier.weight(1f))
                }
            }
        }
        if (results.isEmpty()) {
            item {
                EmptyOperationalState(
                    title = "No polling unit results submitted yet.",
                    description = "Accreditation, BVAS status, valid/rejected vote counts, and Form EC8A attachments appear here as field agents submit them.",
                    icon = Icons.Filled.HowToVote,
                    actionLabel = "Submit Polling Unit Result",
                    onAction = onGoToSubmit
                )
            }
        } else {
            items(results, key = { it.id }) { r ->
                val canRevise = (r.submittedByUid == user.uid || user.roleEnum.canVerifyResults()) &&
                    (r.verificationEnum == VerificationStatus.DRAFT || r.verificationEnum == VerificationStatus.REQUIRES_CORRECTION)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${r.puCode} · v${r.version}", style = MonoCodeStyle, color = EmeraldPrimary)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (r.isTestData) TestDataTag()
                                VerificationBadge(r.verificationEnum)
                            }
                        }
                        Text("${r.puName} (${r.wardName})", style = MaterialTheme.typography.titleMedium, color = TextPrimaryLight)
                        Text(
                            text = "Reg: ${r.registeredVoters} · Accr: ${r.accreditedVoters} · Valid: ${r.validVotes} · Rej: ${r.rejectedVotes} · Total: ${r.totalVotesCast}",
                            style = MonoCodeStyle,
                            color = TextPrimaryLight
                        )
                        Text(
                            text = "BVAS: ${r.bvasStatus}" + if (r.bvasNotes.isNotBlank()) " — ${r.bvasNotes}" else "",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryLight
                        )
                        if (r.reviewNote.isNotBlank()) {
                            Text(
                                text = "Verification Note: ${r.reviewNote} (${r.reviewedByName})",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusInfo
                            )
                        }
                        Base64EvidencePreview(r.ec8aImageBase64, r.ec8aFileName ?: "Form EC8A Attachment")
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${r.submittedByName} · ${formatTimestamp(r.updatedAt ?: r.createdAt)}",
                                style = MonoCodeStyle,
                                color = TextSecondaryLight,
                                modifier = Modifier.weight(1f)
                            )
                            Row {
                                if (canRevise) {
                                    TextButton(onClick = { onRevise(r) }) {
                                        Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.size(4.dp))
                                        Text("Revise")
                                    }
                                }
                                TextButton(onClick = { onViewHistory(r) }) {
                                    Icon(Icons.Filled.History, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.size(4.dp))
                                    Text("History")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SubmitOrReviseResultPanel(
    user: UserAccount,
    pollingUnits: List<PollingUnit>,
    results: List<ResultSubmission>,
    syncMetrics: SyncDashboardMetrics,
    editRequest: OfflineReportEditRequest?,
    onConsumeEditRequest: () -> Unit,
    onSyncNow: () -> Unit,
    editingSubmission: ResultSubmission?,
    onClearEditing: () -> Unit,
    onAutoSaveResultDraft: (String, PollingUnit?, Long, Long, Long, Long, String, String, String, ResultSubmission?, OfflineAttachmentDraft?) -> Unit,
    onSubmitResult: (
        PollingUnit,
        Long,
        Long,
        Long,
        Long,
        String,
        String,
        String,
        String?,
        String?,
        ResultSubmission?,
        OfflineAttachmentDraft?,
        String?
    ) -> Unit
) {
    var draftReportId by remember(editingSubmission) {
        mutableStateOf(
            editingSubmission?.id?.takeIf { it.isNotBlank() }
                ?: "res_${user.uid.take(6)}_${UUID.randomUUID().toString().take(8)}"
        )
    }
    var editingLocalId by remember { mutableStateOf<String?>(null) }
    var resolvedServerExisting by remember(editingSubmission) { mutableStateOf(editingSubmission) }

    var selectedPu by remember(pollingUnits, editingSubmission) {
        mutableStateOf(
            editingSubmission?.let { sub -> pollingUnits.firstOrNull { it.id == sub.puId } }
                ?: pollingUnits.firstOrNull { it.id == user.assignedPollingUnitId }
                ?: pollingUnits.firstOrNull()
        )
    }

    var registeredText by remember(editingSubmission) {
        mutableStateOf(editingSubmission?.registeredVoters?.toString() ?: (selectedPu?.registeredVoters?.takeIf { it > 0 }?.toString() ?: "0"))
    }
    var accreditedText by remember(editingSubmission) {
        mutableStateOf(editingSubmission?.accreditedVoters?.toString() ?: "")
    }
    var validText by remember(editingSubmission) {
        mutableStateOf(editingSubmission?.validVotes?.toString() ?: "")
    }
    var rejectedText by remember(editingSubmission) {
        mutableStateOf(editingSubmission?.rejectedVotes?.toString() ?: "0")
    }
    var bvasStatus by remember(editingSubmission) {
        mutableStateOf(editingSubmission?.let { BvasStatus.entries.find { b -> b.label == it.bvasStatus } } ?: BvasStatus.FUNCTIONAL)
    }
    var bvasExpanded by remember { mutableStateOf(false) }
    var bvasNotes by remember(editingSubmission) { mutableStateOf(editingSubmission?.bvasNotes ?: "") }
    var submissionNotes by remember(editingSubmission) { mutableStateOf(editingSubmission?.submissionNotes ?: "") }
    var attachmentDraft by remember { mutableStateOf<OfflineAttachmentDraft?>(null) }
    var ec8aBase64 by remember { mutableStateOf<String?>(null) }
    var ec8aAttStatus by remember { mutableStateOf<OfflineSyncStatus?>(null) }

    LaunchedEffect(editRequest) {
        val req = editRequest ?: return@LaunchedEffect
        if (req.itemType == OfflineItemType.RESULT_SUBMISSION) {
            runCatching {
                val obj = JSONObject(req.payloadJson)
                val puId = obj.optString("puId")
                pollingUnits.firstOrNull { it.id == puId }?.let { selectedPu = it }
                registeredText = obj.optLong("registeredVoters", 0L).toString()
                accreditedText = obj.optLong("accreditedVoters", 0L).toString()
                validText = obj.optLong("validVotes", 0L).toString()
                rejectedText = obj.optLong("rejectedVotes", 0L).toString()
                val bvasLabel = obj.optString("bvasStatus")
                bvasStatus = BvasStatus.entries.find { it.label == bvasLabel } ?: BvasStatus.FUNCTIONAL
                bvasNotes = obj.optString("bvasNotes", "")
                submissionNotes = obj.optString("submissionNotes", "")
                val existingId = obj.optString("existingSubmissionId")
                if (existingId.isNotBlank()) {
                    resolvedServerExisting = results.firstOrNull { it.id == existingId }
                }
                val att = req.attachments.firstOrNull()
                if (att != null) {
                    attachmentDraft = OfflineAttachmentDraft(
                        attachmentId = att.attachmentId,
                        fileName = att.fileName,
                        localFilePath = att.localFilePath,
                        sha256Hash = att.sha256Hash,
                        sizeBytes = att.sizeBytes
                    )
                    ec8aAttStatus = OfflineSyncStatus.fromString(att.uploadStatus)
                }
                draftReportId = req.reportId
                editingLocalId = req.reportId
            }
            onConsumeEditRequest()
        }
    }

    val reg = registeredText.toLongOrNull() ?: 0L
    val acc = accreditedText.toLongOrNull() ?: 0L
    val valid = validText.toLongOrNull() ?: 0L
    val rej = rejectedText.toLongOrNull() ?: 0L
    val totalCast = valid + rej

    // Debounced auto-save to local storage
    LaunchedEffect(selectedPu, reg, acc, valid, rej, bvasStatus, bvasNotes, submissionNotes, attachmentDraft) {
        delay(350L)
        if (selectedPu != null && (acc > 0L || valid > 0L || bvasNotes.isNotBlank() || submissionNotes.isNotBlank() || attachmentDraft != null)) {
            onAutoSaveResultDraft(
                draftReportId,
                selectedPu,
                reg,
                acc,
                valid,
                rej,
                bvasStatus.label,
                bvasNotes,
                submissionNotes,
                resolvedServerExisting,
                attachmentDraft
            )
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            CompactSyncBanner(
                metrics = syncMetrics,
                onSyncNow = onSyncNow
            )
        }
        if (pollingUnits.isEmpty()) {
            item {
                EmptyOperationalState(
                    title = "No Polling Unit Available for Submission",
                    description = "Your assigned Polling Unit directory loads from offline cache once active. Contact an admin if your assignment is pending."
                )
            }
        } else {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = when {
                            resolvedServerExisting != null -> "Revise Correction (${resolvedServerExisting?.puCode})"
                            editingLocalId != null -> "Edit Offline Result (${selectedPu?.puCode ?: ""})"
                            else -> "Form EC8A & BVAS Result Entry"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        color = EmeraldDeep
                    )
                    if (resolvedServerExisting != null || editingLocalId != null) {
                        TextButton(onClick = {
                            editingLocalId = null
                            resolvedServerExisting = null
                            draftReportId = "res_${user.uid.take(6)}_${UUID.randomUUID().toString().take(8)}"
                            onClearEditing()
                        }) { Text("New Entry") }
                    }
                }
            }
            item {
                SearchablePollingUnitField(
                    label = "Polling Unit (Searchable Directory)",
                    pollingUnits = pollingUnits,
                    selectedPu = selectedPu,
                    enabled = resolvedServerExisting == null,
                    onSelectPu = { pu ->
                        if (pu != null) {
                            selectedPu = pu
                            if (pu.registeredVoters > 0) registeredText = pu.registeredVoters.toString()
                        }
                    },
                    testTag = "result_pu_selector"
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = registeredText,
                        onValueChange = { registeredText = it.filter(Char::isDigit) },
                        label = { Text("Registered") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("result_registered_input")
                    )
                    OutlinedTextField(
                        value = accreditedText,
                        onValueChange = { accreditedText = it.filter(Char::isDigit) },
                        label = { Text("Accredited (BVAS)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("result_accredited_input")
                    )
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = validText,
                        onValueChange = { validText = it.filter(Char::isDigit) },
                        label = { Text("Valid Votes") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("result_valid_input")
                    )
                    OutlinedTextField(
                        value = rejectedText,
                        onValueChange = { rejectedText = it.filter(Char::isDigit) },
                        label = { Text("Rejected Votes") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("result_rejected_input")
                    )
                }
            }
            item {
                Text("Computed Total Votes Cast: $totalCast", style = MonoCodeStyle, color = EmeraldPrimary)
                if (acc > 0 && totalCast > acc) {
                    Text(
                        text = "Warning: Total votes cast ($totalCast) exceeds accredited voters ($acc).",
                        style = MaterialTheme.typography.bodySmall,
                        color = AlertWarning
                    )
                }
            }
            item {
                ExposedDropdownMenuBox(expanded = bvasExpanded, onExpandedChange = { bvasExpanded = it }) {
                    OutlinedTextField(
                        value = bvasStatus.label,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("BVAS Operational Status") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = bvasExpanded) },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable, true)
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = bvasExpanded, onDismissRequest = { bvasExpanded = false }) {
                        BvasStatus.entries.forEach { st ->
                            DropdownMenuItem(
                                text = { Text(st.label) },
                                onClick = {
                                    bvasStatus = st
                                    bvasExpanded = false
                                }
                            )
                        }
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = bvasNotes,
                    onValueChange = { bvasNotes = it },
                    label = { Text("BVAS Notes (Auto-Saved Locally)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                OutlinedTextField(
                    value = submissionNotes,
                    onValueChange = { submissionNotes = it },
                    label = { Text("Submission / Correction Notes (Auto-Saved)") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                CameraAndPickerEvidenceSection(
                    ownerUid = user.uid,
                    label = "Form EC8A Photo Evidence (Saved Locally Offline-First)",
                    attachedFileName = attachmentDraft?.fileName,
                    attachedLocalPath = attachmentDraft?.localFilePath,
                    attachedBase64 = ec8aBase64,
                    attachmentUploadStatus = ec8aAttStatus ?: attachmentDraft?.let { OfflineSyncStatus.SAVED_LOCALLY },
                    onAttachmentCaptured = { draft, b64 ->
                        attachmentDraft = draft
                        ec8aBase64 = b64
                        ec8aAttStatus = OfflineSyncStatus.SAVED_LOCALLY
                    },
                    onRemoveAttachment = {
                        attachmentDraft = null
                        ec8aBase64 = null
                        ec8aAttStatus = null
                    },
                    testTagPrefix = "ec8a"
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = {
                            onAutoSaveResultDraft(
                                draftReportId,
                                selectedPu,
                                reg,
                                acc,
                                valid,
                                rej,
                                bvasStatus.label,
                                bvasNotes,
                                submissionNotes,
                                resolvedServerExisting,
                                attachmentDraft
                            )
                        },
                        enabled = selectedPu != null,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_result_draft_button")
                    ) {
                        Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(4.dp))
                        Text("Save Draft")
                    }
                    Button(
                        onClick = {
                            val pu = selectedPu ?: return@Button
                            onSubmitResult(
                                pu, reg, acc, valid, rej, bvasStatus.label, bvasNotes, submissionNotes,
                                ec8aBase64, attachmentDraft?.fileName, resolvedServerExisting, attachmentDraft, draftReportId
                            )
                            editingLocalId = null
                            resolvedServerExisting = null
                            attachmentDraft = null
                            ec8aBase64 = null
                            ec8aAttStatus = null
                            draftReportId = "res_${user.uid.take(6)}_${UUID.randomUUID().toString().take(8)}"
                        },
                        enabled = selectedPu != null && accreditedText.isNotBlank() && validText.isNotBlank(),
                        modifier = Modifier.weight(1.5f).testTag("submit_result_button")
                    ) {
                        Text(
                            when {
                                resolvedServerExisting != null -> "Resubmit Correction"
                                syncMetrics.isOnline -> "Submit Result"
                                else -> "Queue Result Offline"
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun VerificationCenterPanel(
    results: List<ResultSubmission>,
    onReviewClick: (ResultSubmission) -> Unit,
    onViewHistory: (ResultSubmission) -> Unit
) {
    val submittedCount = results.count { it.verificationEnum == VerificationStatus.SUBMITTED }
    val reviewCount = results.count { it.verificationEnum == VerificationStatus.UNDER_REVIEW }
    val verifiedCount = results.count { it.verificationEnum == VerificationStatus.VERIFIED }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Result Verification Center", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                KpiTile("Field Submitted", "$submittedCount", null, EmeraldPrimary, Modifier.weight(1f))
                KpiTile("Under Review", "$reviewCount", null, StatusInfo, Modifier.weight(1f))
                KpiTile("Verified", "$verifiedCount", null, StatusVerified, Modifier.weight(1f))
            }
        }

        if (results.isEmpty()) {
            item {
                EmptyOperationalState(
                    title = "No submitted results awaiting verification.",
                    description = "Field submissions appear here for multi-stage review, correction requests, and verified internal sign-off.",
                    icon = Icons.Filled.FactCheck
                )
            }
        } else {
            items(results, key = { it.id }) { sub ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${sub.puCode} · ${sub.puName}", style = MaterialTheme.typography.titleSmall, color = TextPrimaryLight, modifier = Modifier.weight(1f))
                            VerificationBadge(sub.verificationEnum)
                        }
                        Text(
                            text = "Reg: ${sub.registeredVoters} | Accr: ${sub.accreditedVoters} | Valid: ${sub.validVotes} | Rej: ${sub.rejectedVotes}",
                            style = MonoCodeStyle,
                            color = TextPrimaryLight
                        )
                        Text(
                            text = "Publicly Published: ${if (sub.publiclyApproved) "YES" else "Internal Only"} · Submitted by ${sub.submittedByName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryLight
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onReviewClick(sub) },
                                modifier = Modifier.testTag("verify_result_${sub.puCode}")
                            ) {
                                Text("Verify / Review")
                            }
                            OutlinedButton(onClick = { onViewHistory(sub) }) {
                                Text("Audit History")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PublicSummaryPanel(
    publicResults: List<PublicVerifiedResult>,
    enabled: Boolean
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (!enabled) {
            item {
                EmptyOperationalState(
                    title = "Public Summary Temporarily Disabled",
                    description = "A Full Control Administrator has disabled public verified result summaries in Global Security Settings.",
                    icon = Icons.Filled.Public
                )
            }
        } else if (publicResults.isEmpty()) {
            item {
                EmptyOperationalState(
                    title = "No verified public results published yet.",
                    description = "Only Full Control Admin-approved, verified polling unit tallies appear here. Unverified submissions and agent personal details are excluded.",
                    icon = Icons.Filled.Public
                )
            }
        } else {
            val totalAccr = publicResults.sumOf { it.accreditedVoters }
            val totalValid = publicResults.sumOf { it.validVotes }
            val totalRej = publicResults.sumOf { it.rejectedVotes }
            item {
                Text("Public Verified Election Summary (Zero PII)", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    KpiTile("Verified PUs", "${publicResults.size}", null, StatusVerified, Modifier.weight(1f))
                    KpiTile("Accredited", "$totalAccr", null, StatusInfo, Modifier.weight(1f))
                    KpiTile("Valid Votes", "$totalValid", "Rej: $totalRej", EmeraldPrimary, Modifier.weight(1f))
                }
            }
            items(publicResults, key = { it.id }) { pub ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${pub.puCode} · ${pub.puName}", style = MaterialTheme.typography.titleSmall, color = TextPrimaryLight)
                            Icon(Icons.Filled.CheckCircle, contentDescription = "Verified", tint = StatusVerified)
                        }
                        Text("${pub.wardName} · ${pub.lgaId.uppercase()}", style = MaterialTheme.typography.bodySmall, color = TextSecondaryLight)
                        Text(
                            text = "Accr: ${pub.accreditedVoters} · Valid: ${pub.validVotes} · Rej: ${pub.rejectedVotes} · Total: ${pub.totalVotesCast}",
                            style = MonoCodeStyle,
                            color = TextPrimaryLight
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ReviewResultDialog(
    submission: ResultSubmission,
    canPublishPublic: Boolean,
    onDismiss: () -> Unit,
    onSave: (VerificationStatus, String, Boolean) -> Unit
) {
    var selectedStatus by remember { mutableStateOf(VerificationStatus.VERIFIED) }
    var note by remember { mutableStateOf(submission.reviewNote) }
    var publishPublic by remember { mutableStateOf(submission.publiclyApproved) }
    val options = listOf(
        VerificationStatus.UNDER_REVIEW,
        VerificationStatus.VERIFIED,
        VerificationStatus.REQUIRES_CORRECTION,
        VerificationStatus.REJECTED
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = WhiteBackground,
        title = { Text("Verify Result · ${submission.puCode}", color = EmeraldDeep) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Valid: ${submission.validVotes}, Rejected: ${submission.rejectedVotes}, Accredited: ${submission.accreditedVoters}",
                    style = MonoCodeStyle,
                    color = TextPrimaryLight
                )
                options.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        pair.forEach { st ->
                            FilterChip(
                                selected = selectedStatus == st,
                                onClick = { selectedStatus = st },
                                label = { Text(st.label) }
                            )
                        }
                    }
                }
                if (canPublishPublic && selectedStatus == VerificationStatus.VERIFIED) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Publish to Public Summary", style = MaterialTheme.typography.bodyMedium, color = TextPrimaryLight)
                        Switch(checked = publishPublic, onCheckedChange = { publishPublic = it })
                    }
                }
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Mandatory Verification Reason") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth().testTag("review_result_note_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(selectedStatus, note, publishPublic) },
                enabled = note.trim().length >= 3,
                modifier = Modifier.testTag("confirm_review_result_btn")
            ) { Text("Save Decision") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun ResultHistoryDialog(
    submission: ResultSubmission,
    entries: List<ResultHistoryEntry>,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = WhiteBackground,
        title = { Text("Immutable History · ${submission.puCode}", color = EmeraldDeep) },
        text = {
            if (entries.isEmpty()) {
                Text("No history entries recorded yet.")
            } else {
                LazyColumn(modifier = Modifier.height(280.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(entries, key = { it.id }) { entry ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = SoftGreySurface),
                            border = BorderStroke(1.dp, BorderLight)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text("${entry.action} (${entry.previousStatus} -> ${entry.newStatus})", style = MonoCodeStyle, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                                Text("Valid: ${entry.validVotes} · Accr: ${entry.accreditedVoters} · Total: ${entry.totalVotesCast}", style = MonoCodeStyle)
                                Text(entry.note, style = MaterialTheme.typography.bodySmall)
                                Text("${entry.actorName} · ${formatTimestamp(entry.createdAt)}", style = MonoCodeStyle, color = TextSecondaryLight)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
