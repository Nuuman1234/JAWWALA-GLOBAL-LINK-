package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.UUID
import kotlin.math.max

data class CompressedEvidence(
    val base64: String,
    val fileName: String,
    val sizeBytes: Int,
    val localFilePath: String = "",
    val sha256Hash: String = ""
)

object ImageCompression {
    private const val MAX_DIMENSION = 1024
    private const val MAX_BASE64_BYTES = 240_000

    fun createCameraCaptureUri(context: Context): Pair<Uri, File> {
        val cacheDir = File(context.cacheDir, "camera_captures").apply { mkdirs() }
        val captureFile = File(cacheDir, "capture_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.jpg")
        val authority = "${context.packageName}.fileprovider"
        val uri = FileProvider.getUriForFile(context, authority, captureFile)
        return uri to captureFile
    }

    fun compressAndPersistUri(
        context: Context,
        ownerUid: String,
        uri: Uri,
        suggestedPrefix: String = "evidence"
    ): Result<CompressedEvidence> {
        return runCatching {
            val resolver = context.contentResolver
            val rawName = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                } ?: "${suggestedPrefix}_${System.currentTimeMillis()}.jpg"

            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, boundsOptions)
            }

            val maxSide = max(boundsOptions.outWidth, boundsOptions.outHeight)
            var sampleSize = 1
            while (maxSide / sampleSize > MAX_DIMENSION * 2) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val rawBitmap = resolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOptions)
            } ?: error("Unable to decode selected image")

            val jpegBytes = encodeBoundedJpeg(rawBitmap)
            val encoded = Base64.encodeToString(jpegBytes, Base64.NO_WRAP)
            require(encoded.length <= MAX_BASE64_BYTES) {
                "Compressed image exceeds safe upload size (${encoded.length / 1024} KB). Please choose a clearer cropped photo."
            }

            val sha256 = sha256Hex(jpegBytes)
            val persistedFile = savePrivateAttachmentBytes(context, ownerUid, jpegBytes)

            CompressedEvidence(
                base64 = encoded,
                fileName = rawName.take(110),
                sizeBytes = jpegBytes.size,
                localFilePath = persistedFile.absolutePath,
                sha256Hash = sha256
            )
        }
    }

    fun persistRawBytesForTestOrAttachment(
        context: Context,
        ownerUid: String,
        jpegBytes: ByteArray,
        fileName: String
    ): CompressedEvidence {
        val sha256 = sha256Hex(jpegBytes)
        val persistedFile = savePrivateAttachmentBytes(context, ownerUid, jpegBytes)
        val encoded = Base64.encodeToString(jpegBytes, Base64.NO_WRAP)
        return CompressedEvidence(
            base64 = encoded,
            fileName = fileName.take(110),
            sizeBytes = jpegBytes.size,
            localFilePath = persistedFile.absolutePath,
            sha256Hash = sha256
        )
    }

    fun compressUriToBase64(context: Context, uri: Uri): Result<CompressedEvidence> {
        return compressAndPersistUri(context, "shared_draft", uri, "evidence")
    }

    fun readBase64FromLocalPath(localFilePath: String?): String? {
        if (localFilePath.isNullOrBlank()) return null
        val file = File(localFilePath)
        if (!file.exists() || !file.isFile) return null
        return runCatching {
            val bytes = file.readBytes()
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        }.getOrNull()
    }

    fun decodeLocalPathToBitmap(localFilePath: String?): Bitmap? {
        if (localFilePath.isNullOrBlank()) return null
        val file = File(localFilePath)
        if (!file.exists() || !file.isFile) return null
        return runCatching {
            BitmapFactory.decodeFile(file.absolutePath)
        }.getOrNull()
    }

    fun decodeBase64ToBitmap(base64: String?): Bitmap? {
        if (base64.isNullOrBlank()) return null
        return try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Exception) {
            null
        }
    }

    fun deleteLocalAttachmentFile(localFilePath: String?) {
        if (localFilePath.isNullOrBlank()) return
        runCatching { File(localFilePath).delete() }
    }

    private fun savePrivateAttachmentBytes(context: Context, ownerUid: String, bytes: ByteArray): File {
        val safeUid = ownerUid.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").ifBlank { "default" }
        val dir = File(context.filesDir, "offline_attachments/$safeUid").apply { mkdirs() }
        val file = File(dir, "att_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.jpg")
        file.writeBytes(bytes)
        return file
    }

    private fun encodeBoundedJpeg(rawBitmap: Bitmap): ByteArray {
        val scale = if (max(rawBitmap.width, rawBitmap.height) > MAX_DIMENSION) {
            MAX_DIMENSION.toFloat() / max(rawBitmap.width, rawBitmap.height).toFloat()
        } else {
            1f
        }
        val bitmap = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                rawBitmap,
                (rawBitmap.width * scale).toInt().coerceAtLeast(1),
                (rawBitmap.height * scale).toInt().coerceAtLeast(1),
                true
            ).also { if (it != rawBitmap) rawBitmap.recycle() }
        } else {
            rawBitmap
        }

        var quality = 78
        var jpegBytes: ByteArray
        do {
            val out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
            jpegBytes = out.toByteArray()
            quality -= 12
        } while (jpegBytes.size > 170_000 && quality >= 30)

        bitmap.recycle()
        return jpegBytes
    }

    fun sha256Hex(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString("") { "%02x".format(it) }
    }
}
