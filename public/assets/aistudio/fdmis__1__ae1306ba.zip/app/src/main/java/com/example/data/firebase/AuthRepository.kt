package com.example.data.firebase

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.data.model.AccountStatus
import com.example.data.model.BootstrapLock
import com.example.data.model.GlobalSettings
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.example.data.local.CachedUserProfileEntity
import com.example.data.local.OfflineQueueDao
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Source
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

fun attemptAutoSignIn(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onUnauthenticated: () -> Unit,
    scope: CoroutineScope
) {
    if (Firebase.auth.currentUser != null) {
        onAuthSuccess()
        return
    }
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (_: Exception) {
        onUnauthenticated()
        return
    }

    val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(true)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(true)
        .build()

    val request = GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()

    scope.launch {
        try {
            val result = credentialManager.getCredential(context, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                Firebase.auth.signInWithCredential(authCredential).await()
                onAuthSuccess()
            } else {
                onUnauthenticated()
            }
        } catch (_: Exception) {
            onUnauthenticated()
        }
    }
}

fun onGoogleSignInClicked(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope,
    onAuthCancelled: () -> Unit = {}
) {
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (_: Exception) {
        onAuthError("Google Sign-In configuration missing: default_web_client_id not found")
        return
    }

    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder()
        .addCredentialOption(signInOption)
        .build()

    scope.launch {
        try {
            val activity = context as? Activity
                ?: throw IllegalStateException("Google Sign-In requires an Activity context")
            val result = credentialManager.getCredential(activity, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                Firebase.auth.signInWithCredential(authCredential).await()
                onAuthSuccess()
            } else {
                onAuthError("Unexpected credential type returned by Google Sign-In")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w("Auth", "Google Sign-In flow cancelled or dismissed: ${e.message}", e)
            onAuthCancelled()
        } catch (e: Exception) {
            Log.e("Auth", "Google Sign-In failed", e)
            onAuthError(e.localizedMessage ?: "Sign in failed")
        }
    }
}

fun signOutUser(
    credentialManager: CredentialManager,
    scope: CoroutineScope,
    onSignOutComplete: () -> Unit = {}
) {
    scope.launch {
        withContext(NonCancellable) {
            try {
                credentialManager.clearCredentialState(ClearCredentialStateRequest())
            } catch (e: Exception) {
                Log.w("Auth", "Failed to clear credential state: ${e.message}")
            } finally {
                Firebase.auth.signOut()
                onSignOutComplete()
            }
        }
    }
}

class AuthRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
    private val offlineDao: OfflineQueueDao? = null
) {
    private fun requireUser(): FirebaseUser =
        auth.currentUser ?: throw IllegalStateException("User must be signed in with Google.")

    fun observeUserAccount(uid: String): Flow<UserAccount?> {
        val docRef = db.collection("users").document(uid)
        return docRef.snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(UserAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val ex = firestoreError ?: (error as? Exception)
                if (ex != null && auth.currentUser?.uid == uid) {
                    handleFirestoreError(ex, OperationType.GET, docRef.path, auth)
                }
                throw error
            }
    }

    fun observeGlobalSettings(): Flow<GlobalSettings> {
        val docRef = db.collection("system_settings").document("global")
        return docRef.snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(GlobalSettings::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        ?: GlobalSettings()
                } else {
                    GlobalSettings()
                }
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                emit(GlobalSettings())
            }
    }

    suspend fun getBootstrapLock(): Result<BootstrapLock?> = runCatching {
        requireUser()
        val ref = db.collection("system_settings").document("bootstrap")
        try {
            val snap = ref.get().await()
            if (snap.exists()) {
                snap.toObject(BootstrapLock::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            } else {
                null
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, ref.path, auth)
            throw e
        }
    }

    suspend fun ensureUserProfileOrCheckBootstrap(displayNameOverride: String? = null): Result<UserAccount?> = runCatching {
        val user = requireUser()
        val userRef = db.collection("users").document(user.uid)
        val existingSnap = try {
            withTimeout(4500L) { userRef.get().await() }
        } catch (e: TimeoutCancellationException) {
            fallbackCachedProfile(user.uid, userRef)?.let { return@runCatching it }
            handleFirestoreError(e, OperationType.GET, userRef.path, auth)
            throw e
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val ffe = generateSequence(e as Throwable) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (ffe?.code == FirebaseFirestoreException.Code.UNAVAILABLE) {
                fallbackCachedProfile(user.uid, userRef)?.let { return@runCatching it }
            }
            handleFirestoreError(e, OperationType.GET, userRef.path, auth)
            throw e
        }

        if (existingSnap.exists()) {
            val account = existingSnap.toObject(UserAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            if (account != null) {
                runCatching {
                    offlineDao?.upsertCachedUser(CachedUserProfileEntity.fromUserAccount(account))
                }
            }
            if (account != null && account.status == AccountStatus.ACTIVE.name && !account.sessionRevoked) {
                try {
                    userRef.update(
                        mapOf(
                            "lastLoginAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                } catch (_: Exception) {
                    // Best-effort login timestamp update
                }
            }
            return@runCatching account
        }

        val bootstrapExists = try {
            db.collection("system_settings").document("bootstrap").get().await().exists()
        } catch (_: Exception) {
            true
        }

        // If bootstrap does not exist yet, let UI offer initial Full Control Admin initialization
        if (!bootstrapExists) {
            return@runCatching null
        }

        // Otherwise register as PENDING_APPROVAL (zero operational privileges until admin activates)
        val safeName = (displayNameOverride?.takeIf { it.isNotBlank() }
            ?: user.displayName?.takeIf { it.isNotBlank() }
            ?: user.email?.substringBefore("@")
            ?: "FDMIS User").take(110)

        val payload = mapOf(
            "uid" to user.uid,
            "email" to (user.email ?: ""),
            "displayName" to safeName,
            "role" to UserRole.PENDING.name,
            "status" to AccountStatus.PENDING_APPROVAL.name,
            "assignedLgaId" to "",
            "assignedWardId" to "",
            "assignedPollingUnitId" to "",
            "sessionRevoked" to false,
            "lastLoginAt" to FieldValue.serverTimestamp(),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            userRef.set(payload).await()
            userRef.get().await().toObject(UserAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, userRef.path, auth)
            throw e
        }
    }

    suspend fun initializeFullControlAdmin(displayName: String, phone: String?): Result<UserAccount> = runCatching {
        val user = requireUser()
        val cleanName = displayName.trim().take(110)
        require(cleanName.length >= 2) { "Full name must be at least 2 characters." }

        val bootstrapRef = db.collection("system_settings").document("bootstrap")
        val adminRef = db.collection("admins").document(user.uid)
        val userRef = db.collection("users").document(user.uid)
        val settingsRef = db.collection("system_settings").document("global")
        val auditRef = db.collection("audit_logs").document()

        val batch = db.batch()
        batch.set(
            bootstrapRef,
            mapOf(
                "initializedByUid" to user.uid,
                "initializedByEmail" to (user.email ?: ""),
                "cycleYear" to 2027L,
                "constituencyName" to "Funtua-Dandume Federal Constituency",
                "createdAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(
            adminRef,
            mapOf(
                "uid" to user.uid,
                "email" to (user.email ?: ""),
                "grantedByUid" to user.uid,
                "createdAt" to FieldValue.serverTimestamp()
            )
        )
        val userPayload = mutableMapOf<String, Any>(
            "uid" to user.uid,
            "email" to (user.email ?: ""),
            "displayName" to cleanName,
            "role" to UserRole.FULL_CONTROL_ADMIN.name,
            "status" to AccountStatus.ACTIVE.name,
            "assignedLgaId" to "",
            "assignedWardId" to "",
            "assignedPollingUnitId" to "",
            "sessionRevoked" to false,
            "lastLoginAt" to FieldValue.serverTimestamp(),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (!phone.isNullOrBlank()) {
            userPayload["phone"] = phone.trim().take(25)
        }
        batch.set(userRef, userPayload)
        batch.set(
            settingsRef,
            mapOf(
                "inactivityTimeoutMinutes" to 30L,
                "mfaPrepared" to true,
                "publicSummaryEnabled" to true,
                "smsFallbackConfigured" to false,
                "whatsappConfigured" to false,
                "emailConfigured" to false,
                "updatedByUid" to user.uid,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(
            auditRef,
            mapOf(
                "actorUid" to user.uid,
                "actorName" to cleanName,
                "actorEmail" to (user.email ?: ""),
                "actorRole" to UserRole.FULL_CONTROL_ADMIN.name,
                "action" to "INITIAL_ADMIN_BOOTSTRAP",
                "affectedEntity" to "system_settings",
                "affectedId" to "bootstrap",
                "details" to "Initialized 2027 Situation Room Full Control Admin account",
                "createdAt" to FieldValue.serverTimestamp()
            )
        )
        try {
            batch.commit().await()
            val account = userRef.get().await().toObject(UserAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: error("Admin account initialized but could not be loaded.")
            runCatching {
                offlineDao?.upsertCachedUser(CachedUserProfileEntity.fromUserAccount(account))
            }
            account
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, userRef.path, auth)
            throw e
        }
    }

    suspend fun registerPendingAccount(displayName: String, phone: String?): Result<UserAccount> = runCatching {
        val user = requireUser()
        val cleanName = displayName.trim().take(110)
        require(cleanName.length >= 2) { "Full name must be at least 2 characters." }
        val userRef = db.collection("users").document(user.uid)
        val payload = mutableMapOf<String, Any>(
            "uid" to user.uid,
            "email" to (user.email ?: ""),
            "displayName" to cleanName,
            "role" to UserRole.PENDING.name,
            "status" to AccountStatus.PENDING_APPROVAL.name,
            "assignedLgaId" to "",
            "assignedWardId" to "",
            "assignedPollingUnitId" to "",
            "sessionRevoked" to false,
            "lastLoginAt" to FieldValue.serverTimestamp(),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (!phone.isNullOrBlank()) {
            payload["phone"] = phone.trim().take(25)
        }
        try {
            userRef.set(payload).await()
            userRef.get().await().toObject(UserAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: error("Profile created but failed to load.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, userRef.path, auth)
            throw e
        }
    }

    private suspend fun fallbackCachedProfile(
        uid: String,
        userRef: com.google.firebase.firestore.DocumentReference
    ): UserAccount? {
        val cacheSnap = runCatching { userRef.get(Source.CACHE).await() }.getOrNull()
        if (cacheSnap != null && cacheSnap.exists()) {
            val cachedFromFirestore = cacheSnap.toObject(UserAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            if (cachedFromFirestore != null) {
                runCatching {
                    offlineDao?.upsertCachedUser(CachedUserProfileEntity.fromUserAccount(cachedFromFirestore))
                }
                return cachedFromFirestore
            }
        }
        return runCatching { offlineDao?.getCachedUser(uid)?.toUserAccount() }.getOrNull()
    }
}
