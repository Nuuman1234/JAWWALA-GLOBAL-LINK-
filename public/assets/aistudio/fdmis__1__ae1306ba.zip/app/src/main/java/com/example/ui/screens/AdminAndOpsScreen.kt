package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SecondaryScrollableTabRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.AccountStatus
import com.example.data.model.AuditLog
import com.example.data.model.GlobalSettings
import com.example.data.model.IncidentReport
import com.example.data.model.LgaDefinition
import com.example.data.model.NotificationItem
import com.example.data.model.PollingUnit
import com.example.data.model.ResultSubmission
import com.example.data.model.TimelineEvent
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.model.Ward
import com.example.ui.components.EmptyOperationalState
import com.example.ui.components.SearchablePollingUnitField
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.AlertCritical
import com.example.ui.theme.AlertCriticalContainer
import com.example.ui.theme.AlertWarning
import com.example.ui.theme.AlertWarningContainer
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.SoftGreySurface
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.StatusVerifiedContainer
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.WhiteBackground
import com.example.util.ReportGenerator

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAndOpsScreen(
    user: UserAccount,
    timeline: List<TimelineEvent>,
    notifications: List<NotificationItem>,
    pollingUnits: List<PollingUnit>,
    wards: List<Ward>,
    incidents: List<IncidentReport>,
    results: List<ResultSubmission>,
    managedUsers: List<UserAccount>,
    auditLogs: List<AuditLog>,
    globalSettings: GlobalSettings,
    showTestData: Boolean,
    onPostAnnouncement: (String, String, String, Boolean) -> Unit,
    onUpdateUserRole: (UserAccount, UserRole, AccountStatus, String, String, String) -> Unit,
    onRevokeEmergency: (UserAccount, String) -> Unit,
    onUpdateGlobalSettings: (GlobalSettings) -> Unit,
    onToggleTestData: (Boolean) -> Unit,
    onShowMessage: (String) -> Unit
) {
    val canUsers = user.roleEnum.canManageUsers()
    val canAuditAndSettings = user.roleEnum.canViewAuditLogs() || user.roleEnum.canManageSettings()

    val tabs = remember(canUsers, canAuditAndSettings) {
        buildList {
            add("Timeline")
            add("Alerts")
            add("Reports")
            if (canUsers) add("Users")
            if (canAuditAndSettings) add("Audit & Security")
        }
    }
    var subTab by remember { mutableIntStateOf(0) }

    Column(modifier = Modifier.fillMaxSize()) {
        SecondaryScrollableTabRow(
            selectedTabIndex = subTab.coerceIn(0, tabs.lastIndex),
            edgePadding = 12.dp,
            containerColor = WhiteBackground
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = subTab == index,
                    onClick = { subTab = index },
                    text = { Text(title, maxLines = 1) }
                )
            }
        }

        when (tabs.getOrNull(subTab)) {
            "Timeline" -> TimelinePanel(timeline = timeline)
            "Alerts" -> AlertsPanel(
                user = user,
                notifications = notifications,
                globalSettings = globalSettings,
                onPostAnnouncement = onPostAnnouncement
            )
            "Reports" -> ReportsPanel(
                user = user,
                pollingUnits = pollingUnits,
                incidents = incidents,
                results = results,
                onShowMessage = onShowMessage
            )
            "Users" -> UserManagementPanel(
                actor = user,
                users = managedUsers,
                wards = wards,
                pollingUnits = pollingUnits,
                onUpdateUserRole = onUpdateUserRole,
                onRevokeEmergency = onRevokeEmergency
            )
            "Audit & Security" -> AuditAndSecurityPanel(
                auditLogs = auditLogs,
                globalSettings = globalSettings,
                showTestData = showTestData,
                onUpdateGlobalSettings = onUpdateGlobalSettings,
                onToggleTestData = onToggleTestData
            )
        }
    }
}

@Composable
private fun TimelinePanel(timeline: List<TimelineEvent>) {
    var lgaFilter by remember { mutableStateOf<String?>(null) }
    val filtered = timeline.filter { lgaFilter == null || it.lgaId == lgaFilter }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = lgaFilter == null, onClick = { lgaFilter = null }, label = { Text("All") })
                LgaDefinition.entries.forEach { lga ->
                    FilterChip(selected = lgaFilter == lga.id, onClick = { lgaFilter = lga.id }, label = { Text(lga.displayName) })
                }
            }
        }
        if (filtered.isEmpty()) {
            item {
                EmptyOperationalState(
                    title = "No election-day timeline events yet.",
                    description = "All check-ins, polling unit transitions, incidents, and result verifications appear chronologically here.",
                    icon = Icons.Filled.Timeline
                )
            }
        } else {
            items(filtered, key = { it.id }) { ev ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(ev.eventType, style = MonoCodeStyle, color = EmeraldPrimary)
                            Text(formatTimestamp(ev.createdAt), style = MonoCodeStyle, color = TextSecondaryLight)
                        }
                        Text(ev.title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryLight)
                        Text(ev.description, style = MaterialTheme.typography.bodySmall, color = TextSecondaryLight)
                        Text("Actor: ${ev.actorName}", style = MonoCodeStyle, color = TextSecondaryLight)
                    }
                }
            }
        }
    }
}

@Composable
private fun AlertsPanel(
    user: UserAccount,
    notifications: List<NotificationItem>,
    globalSettings: GlobalSettings,
    onPostAnnouncement: (String, String, String, Boolean) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var targetLga by remember { mutableStateOf(if (user.roleEnum.canManageAllLgas()) "all" else user.assignedLgaId.ifBlank { "funtua" }) }
    var isCritical by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SoftGreySurface),
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("External Channel Delivery Readiness", style = MaterialTheme.typography.titleSmall, color = EmeraldDeep)
                    Text(
                        text = "In-App Real-Time Alerts: Active\n" +
                            "SMS / USSD Fallback: ${if (globalSettings.smsFallbackConfigured) "Configured" else "Not Configured (Requires Provider Credentials)"}\n" +
                            "WhatsApp Alert Channel: ${if (globalSettings.whatsappConfigured) "Configured" else "Not Configured (Requires Provider Credentials)"}\n" +
                            "Email Relay: ${if (globalSettings.emailConfigured) "Configured" else "Not Configured (Requires Provider Credentials)"}",
                        style = MonoCodeStyle,
                        color = TextSecondaryLight
                    )
                }
            }
        }

        if (user.roleEnum.canManageUsers()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Broadcast Situation Room Announcement", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
                        if (user.roleEnum.canManageAllLgas()) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = targetLga == "all", onClick = { targetLga = "all" }, label = { Text("All LGAs") })
                                FilterChip(selected = targetLga == "funtua", onClick = { targetLga = "funtua" }, label = { Text("Funtua") })
                                FilterChip(selected = targetLga == "dandume", onClick = { targetLga = "dandume" }, label = { Text("Dandume") })
                            }
                        }
                        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Alert Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Operational Directive") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("Mark as Critical Operational Alert", color = TextPrimaryLight)
                            Switch(checked = isCritical, onCheckedChange = { isCritical = it })
                        }
                        Button(
                            onClick = {
                                onPostAnnouncement(title, body, targetLga, isCritical)
                                title = ""
                                body = ""
                                isCritical = false
                            },
                            enabled = title.trim().length >= 2 && body.trim().length >= 2,
                            modifier = Modifier.fillMaxWidth().testTag("send_announcement_btn")
                        ) { Text("Dispatch In-App Notification") }
                    }
                }
            }
        }

        if (notifications.isEmpty()) {
            item {
                EmptyOperationalState(
                    title = "No operational alerts dispatched yet.",
                    description = "Critical incidents and Situation Room announcements will appear here.",
                    icon = Icons.Filled.Notifications
                )
            }
        } else {
            items(notifications, key = { it.id }) { n ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                    border = BorderStroke(1.dp, if (n.isCritical) AlertCritical else BorderLight)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(n.title, style = MaterialTheme.typography.titleSmall, color = if (n.isCritical) AlertCritical else TextPrimaryLight)
                            Text(n.targetLgaId.uppercase(), style = MonoCodeStyle, color = EmeraldPrimary)
                        }
                        Text(n.body, style = MaterialTheme.typography.bodySmall, color = TextPrimaryLight)
                        Text(formatTimestamp(n.createdAt), style = MonoCodeStyle, color = TextSecondaryLight)
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportsPanel(
    user: UserAccount,
    pollingUnits: List<PollingUnit>,
    incidents: List<IncidentReport>,
    results: List<ResultSubmission>,
    onShowMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var pendingExportContent by remember { mutableStateOf("") }

    val saveCsvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(pendingExportContent.toByteArray())
                }
                onShowMessage("Report saved successfully")
            } catch (e: Exception) {
                onShowMessage(e.localizedMessage ?: "Failed to save report")
            }
        }
    }

    val scopeLabel = if (user.roleEnum.canManageAllLgas()) "Funtua & Dandume Federal Constituency" else user.assignedLgaId.uppercase()

    fun shareText(subject: String, content: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, content)
        }
        context.startActivity(Intent.createChooser(intent, subject))
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Operational Reports & CSV Export", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
            Text(
                text = "Exports strictly reflect live Firestore records for your authorized geographical scope ($scopeLabel).",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondaryLight
            )
        }
        item {
            ReportActionCard(
                title = "Executive Situation Room Summary",
                subtitle = "${pollingUnits.size} PUs · ${incidents.size} Incidents · ${results.size} Results",
                onShare = {
                    val text = ReportGenerator.buildExecutiveTextReport(scopeLabel, pollingUnits, incidents, results)
                    shareText("FDMIS Situation Room Executive Summary", text)
                },
                onSaveCsv = null
            )
        }
        item {
            ReportActionCard(
                title = "Polling Unit Operational Status CSV",
                subtitle = "Includes PU code, assigned agent, status, registered voters",
                onShare = {
                    shareText("FDMIS Polling Unit Status CSV", ReportGenerator.buildPollingUnitStatusCsv(scopeLabel, pollingUnits))
                },
                onSaveCsv = {
                    pendingExportContent = ReportGenerator.buildPollingUnitStatusCsv(scopeLabel, pollingUnits)
                    saveCsvLauncher.launch("fdmis_polling_units.csv")
                }
            )
        }
        item {
            ReportActionCard(
                title = "Incident Log & Escalation CSV",
                subtitle = "Includes category, urgency, workflow status, reporter",
                onShare = {
                    shareText("FDMIS Incident Log CSV", ReportGenerator.buildIncidentsCsv(scopeLabel, incidents))
                },
                onSaveCsv = {
                    pendingExportContent = ReportGenerator.buildIncidentsCsv(scopeLabel, incidents)
                    saveCsvLauncher.launch("fdmis_incidents.csv")
                }
            )
        }
        item {
            ReportActionCard(
                title = "Results & Verification Summary CSV",
                subtitle = "Includes accredited, valid, rejected, BVAS & verification status",
                onShare = {
                    shareText("FDMIS Results CSV", ReportGenerator.buildResultsCsv(scopeLabel, results))
                },
                onSaveCsv = {
                    pendingExportContent = ReportGenerator.buildResultsCsv(scopeLabel, results)
                    saveCsvLauncher.launch("fdmis_results.csv")
                }
            )
        }
    }
}

@Composable
private fun ReportActionCard(
    title: String,
    subtitle: String,
    onShare: () -> Unit,
    onSaveCsv: (() -> Unit)?
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = WhiteBackground),
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryLight)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondaryLight)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onShare) {
                    Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Share")
                }
                if (onSaveCsv != null) {
                    OutlinedButton(onClick = onSaveCsv) {
                        Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Save CSV")
                    }
                }
            }
        }
    }
}

@Composable
private fun UserManagementPanel(
    actor: UserAccount,
    users: List<UserAccount>,
    wards: List<Ward>,
    pollingUnits: List<PollingUnit>,
    onUpdateUserRole: (UserAccount, UserRole, AccountStatus, String, String, String) -> Unit,
    onRevokeEmergency: (UserAccount, String) -> Unit
) {
    var editTarget by remember { mutableStateOf<UserAccount?>(null) }
    var revokeTarget by remember { mutableStateOf<UserAccount?>(null) }

    val scopedUsers = remember(users, actor) {
        if (actor.roleEnum.canManageAllLgas()) users
        else users.filter { it.assignedLgaId.isBlank() || it.assignedLgaId == actor.assignedLgaId }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (scopedUsers.isEmpty()) {
            item {
                EmptyOperationalState(
                    title = "No users registered in your scope.",
                    description = "New Google Sign-In users appear here for role assignment and activation.",
                    icon = Icons.Filled.ManageAccounts
                )
            }
        } else {
            items(scopedUsers, key = { it.uid }) { target ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                    border = BorderStroke(
                        1.dp,
                        if (target.sessionRevoked || target.statusEnum == AccountStatus.SUSPENDED) AlertCritical else BorderLight
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(target.displayName, style = MaterialTheme.typography.titleSmall, color = TextPrimaryLight)
                                Text(target.email, style = MonoCodeStyle, color = TextSecondaryLight)
                            }
                            StatusBadge(
                                label = target.statusEnum.label,
                                icon = if (target.isAuthorizedActive) Icons.Filled.AdminPanelSettings else Icons.Filled.Block,
                                containerColor = when (target.statusEnum) {
                                    AccountStatus.ACTIVE -> StatusVerifiedContainer
                                    AccountStatus.PENDING_APPROVAL -> AlertWarningContainer
                                    AccountStatus.SUSPENDED -> AlertCriticalContainer
                                },
                                contentColor = when (target.statusEnum) {
                                    AccountStatus.ACTIVE -> StatusVerified
                                    AccountStatus.PENDING_APPROVAL -> AlertWarning
                                    AccountStatus.SUSPENDED -> AlertCritical
                                }
                            )
                        }
                        Text(
                            text = "Role: ${target.roleEnum.label} · LGA: ${target.assignedLgaId.ifBlank { "All/None" }.uppercase()}",
                            style = MonoCodeStyle,
                            color = EmeraldPrimary
                        )
                        if (target.uid != actor.uid) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { editTarget = target },
                                    modifier = Modifier.testTag("edit_user_${target.uid}")
                                ) { Text("Assign Role & Scope") }
                                if (target.statusEnum != AccountStatus.SUSPENDED) {
                                    Button(
                                        onClick = { revokeTarget = target },
                                        colors = ButtonDefaults.buttonColors(containerColor = AlertCritical),
                                        modifier = Modifier.testTag("revoke_user_${target.uid}")
                                    ) { Text("Emergency Revoke") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    editTarget?.let { target ->
        EditUserDialog(
            actor = actor,
            target = target,
            wards = wards,
            pollingUnits = pollingUnits,
            onDismiss = { editTarget = null },
            onSave = { role, status, lga, ward, pu ->
                onUpdateUserRole(target, role, status, lga, ward, pu)
                editTarget = null
            }
        )
    }

    revokeTarget?.let { target ->
        var reason by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { revokeTarget = null },
            containerColor = WhiteBackground,
            title = { Text("Emergency Access Revocation", color = AlertCritical) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Immediately suspend ${target.displayName} and revoke all active sessions?")
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("Revocation Reason (Audit Log)") },
                        minLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRevokeEmergency(target, reason)
                        revokeTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AlertCritical)
                ) { Text("Revoke Access Now") }
            },
            dismissButton = { TextButton(onClick = { revokeTarget = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun EditUserDialog(
    actor: UserAccount,
    target: UserAccount,
    wards: List<Ward>,
    pollingUnits: List<PollingUnit>,
    onDismiss: () -> Unit,
    onSave: (UserRole, AccountStatus, String, String, String) -> Unit
) {
    val allowedRoles = remember(actor) {
        if (actor.roleEnum == UserRole.FULL_CONTROL_ADMIN) {
            UserRole.entries.filter { it != UserRole.PENDING }
        } else {
            listOf(UserRole.WARD_COORDINATOR, UserRole.POLLING_UNIT_AGENT)
        }
    }
    var selectedRole by remember { mutableStateOf(if (target.roleEnum in allowedRoles) target.roleEnum else UserRole.POLLING_UNIT_AGENT) }
    var selectedStatus by remember { mutableStateOf(AccountStatus.ACTIVE) }
    var selectedLga by remember {
        mutableStateOf(
            when (actor.roleEnum) {
                UserRole.FUNTUA_SUPER_ADMIN -> LgaDefinition.FUNTUA.id
                UserRole.DANDUME_SUPER_ADMIN -> LgaDefinition.DANDUME.id
                else -> target.assignedLgaId.ifBlank { LgaDefinition.FUNTUA.id }
            }
        )
    }
    var selectedWardId by remember { mutableStateOf(target.assignedWardId) }
    var showWardPicker by remember { mutableStateOf(false) }
    var selectedPuId by remember { mutableStateOf(target.assignedPollingUnitId) }

    val scopedWards = remember(wards, selectedLga) {
        wards.filter { it.lgaId == selectedLga }.sortedBy { it.wardCode }
    }
    val scopedPus = remember(pollingUnits, selectedLga, selectedWardId) {
        pollingUnits.filter { it.lgaId == selectedLga && (selectedWardId.isBlank() || it.wardId == selectedWardId) }
            .sortedBy { it.puCode }
    }
    val selectedPu = remember(scopedPus, selectedPuId) {
        scopedPus.find { it.id == selectedPuId }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = WhiteBackground,
        title = { Text("Manage ${target.displayName}", color = EmeraldDeep) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Role", style = MaterialTheme.typography.labelLarge, color = TextPrimaryLight)
                allowedRoles.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        pair.forEach { role ->
                            FilterChip(
                                selected = selectedRole == role,
                                onClick = {
                                    selectedRole = role
                                    if (role == UserRole.FUNTUA_SUPER_ADMIN) selectedLga = LgaDefinition.FUNTUA.id
                                    if (role == UserRole.DANDUME_SUPER_ADMIN) selectedLga = LgaDefinition.DANDUME.id
                                },
                                label = { Text(role.shortLabel) }
                            )
                        }
                    }
                }
                Text("Account Status", style = MaterialTheme.typography.labelLarge, color = TextPrimaryLight)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(AccountStatus.ACTIVE, AccountStatus.PENDING_APPROVAL, AccountStatus.SUSPENDED).forEach { st ->
                        FilterChip(
                            selected = selectedStatus == st,
                            onClick = { selectedStatus = st },
                            label = { Text(st.label.substringBefore(" ")) }
                        )
                    }
                }
                if (actor.roleEnum.canManageAllLgas() && selectedRole != UserRole.FULL_CONTROL_ADMIN) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LgaDefinition.entries.forEach { lga ->
                            FilterChip(
                                selected = selectedLga == lga.id,
                                onClick = {
                                    selectedLga = lga.id
                                    selectedWardId = ""
                                    selectedPuId = ""
                                },
                                label = { Text(lga.displayName) }
                            )
                        }
                    }
                }
                if (scopedWards.isNotEmpty() && selectedRole in listOf(UserRole.WARD_COORDINATOR, UserRole.POLLING_UNIT_AGENT)) {
                    OutlinedCard(
                        onClick = { showWardPicker = true },
                        colors = CardDefaults.outlinedCardColors(containerColor = WhiteBackground),
                        border = BorderStroke(1.dp, BorderLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Assigned Ward", style = MaterialTheme.typography.labelSmall, color = TextSecondaryLight)
                                Text(
                                    text = scopedWards.find { it.id == selectedWardId }?.let { "${it.name} (${it.wardCode})" }
                                        ?: "All Wards / Select Ward",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimaryLight
                                )
                            }
                            Icon(Icons.Filled.ArrowDropDown, contentDescription = "Select Ward", tint = EmeraldPrimary)
                        }
                    }
                }
                if (scopedPus.isNotEmpty() && selectedRole == UserRole.POLLING_UNIT_AGENT) {
                    SearchablePollingUnitField(
                        label = "Assigned Polling Unit",
                        pollingUnits = scopedPus,
                        selectedPu = selectedPu,
                        onSelectPu = { pu ->
                            selectedPuId = pu?.id ?: ""
                            if (pu != null) selectedWardId = pu.wardId
                        },
                        allowNullWardLevelOption = true,
                        nullOptionLabel = "Unassigned (No specific PU)"
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val finalLga = if (selectedRole == UserRole.FULL_CONTROL_ADMIN) "" else selectedLga
                onSave(selectedRole, selectedStatus, finalLga, selectedWardId, selectedPuId)
            }) { Text("Save Assignment") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )

    if (showWardPicker) {
        var wardSearch by remember { mutableStateOf("") }
        val filteredWards = scopedWards.filter {
            wardSearch.isBlank() || it.name.contains(wardSearch, ignoreCase = true) || it.wardCode.contains(wardSearch, ignoreCase = true)
        }
        AlertDialog(
            onDismissRequest = { showWardPicker = false },
            containerColor = WhiteBackground,
            title = { Text("Select Ward", color = EmeraldDeep) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = wardSearch,
                        onValueChange = { wardSearch = it },
                        label = { Text("Search ward name or code") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    LazyColumn(modifier = Modifier.height(240.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(filteredWards, key = { it.id }) { ward ->
                            val isSel = ward.id == selectedWardId
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable {
                                    selectedWardId = ward.id
                                    selectedPuId = ""
                                    showWardPicker = false
                                },
                                colors = CardDefaults.cardColors(containerColor = if (isSel) EmeraldContainer else SoftGreySurface),
                                border = BorderStroke(1.dp, if (isSel) EmeraldPrimary else BorderLight)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(ward.name, style = MaterialTheme.typography.titleSmall, color = TextPrimaryLight)
                                    Text("${ward.wardCode} · ${ward.expectedPollingUnits} PUs", style = MonoCodeStyle, color = TextSecondaryLight)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showWardPicker = false }) { Text("Close") } }
        )
    }
}

@Composable
private fun AuditAndSecurityPanel(
    auditLogs: List<AuditLog>,
    globalSettings: GlobalSettings,
    showTestData: Boolean,
    onUpdateGlobalSettings: (GlobalSettings) -> Unit,
    onToggleTestData: (Boolean) -> Unit
) {
    var timeoutText by remember(globalSettings) { mutableStateOf(globalSettings.inactivityTimeoutMinutes.toString()) }
    var publicEnabled by remember(globalSettings) { mutableStateOf(globalSettings.publicSummaryEnabled) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.Security, contentDescription = null, tint = EmeraldPrimary)
                        Text("Global Security & Governance Settings", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
                    }
                    OutlinedTextField(
                        value = timeoutText,
                        onValueChange = { timeoutText = it.filter(Char::isDigit) },
                        label = { Text("Inactivity Auto-Logout (Minutes, min 5)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Enable Public Verified Summary", color = TextPrimaryLight)
                        Switch(checked = publicEnabled, onCheckedChange = { publicEnabled = it })
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Show TEST DATA Records in Dashboards", color = TextPrimaryLight)
                        Switch(checked = showTestData, onCheckedChange = onToggleTestData)
                    }
                    Text("MFA Support: Ready via Google Account 2-Step Verification", style = MonoCodeStyle, color = StatusInfo)
                    Button(
                        onClick = {
                            val mins = (timeoutText.toLongOrNull() ?: 30L).coerceIn(5L, 480L)
                            onUpdateGlobalSettings(
                                globalSettings.copy(
                                    inactivityTimeoutMinutes = mins,
                                    publicSummaryEnabled = publicEnabled
                                )
                            )
                        },
                        modifier = Modifier.fillMaxWidth().testTag("save_global_settings_btn")
                    ) { Text("Save Security Policy") }
                }
            }
        }

        item {
            Text("Protected Immutable Audit Trail (${auditLogs.size})", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
        }
        if (auditLogs.isEmpty()) {
            item {
                EmptyOperationalState(
                    title = "No audit entries recorded yet.",
                    description = "Every privileged action, verification, role update, and login audit event is recorded immutably here."
                )
            }
        } else {
            items(auditLogs, key = { it.id }) { log ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(log.action, style = MonoCodeStyle, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                            Text(formatTimestamp(log.createdAt), style = MonoCodeStyle, color = TextSecondaryLight)
                        }
                        Text(log.details, style = MaterialTheme.typography.bodySmall, color = TextPrimaryLight)
                        Text("${log.actorName} (${log.actorRole}) · ${log.affectedEntity}", style = MonoCodeStyle, color = TextSecondaryLight)
                    }
                }
            }
        }
    }
}
