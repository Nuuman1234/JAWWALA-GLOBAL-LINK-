package com.example.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import androidx.core.content.ContextCompat

data class DeviceTelemetrySnapshot(
    val batteryPercent: Int,
    val isOnline: Boolean,
    val networkLabel: String,
    val latitude: Double? = null,
    val longitude: Double? = null
)

object DeviceTelemetry {
    fun readSnapshot(context: Context, includeCoarseLocationIfPermitted: Boolean = false): DeviceTelemetrySnapshot {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val battery = batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            ?.takeIf { it in 0..100 } ?: -1

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val network = cm?.activeNetwork
        val caps = if (network != null) cm.getNetworkCapabilities(network) else null
        val isOnline = caps != null && (
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        ) || (caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET))

        val networkLabel = when {
            caps == null -> "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile Data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> if (isOnline) "Connected" else "Offline"
        }

        var lat: Double? = null
        var lng: Double? = null
        if (includeCoarseLocationIfPermitted &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        ) {
            try {
                val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
                val loc = lm?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                    ?: lm?.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER)
                if (loc != null) {
                    lat = loc.latitude
                    lng = loc.longitude
                }
            } catch (_: SecurityException) {
                // Optional telemetry; never block check-in
            }
        }

        return DeviceTelemetrySnapshot(
            batteryPercent = battery,
            isOnline = isOnline,
            networkLabel = networkLabel,
            latitude = lat,
            longitude = lng
        )
    }
}
