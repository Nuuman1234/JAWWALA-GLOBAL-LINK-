package com.example.data.firebase

import com.example.data.local.OfficialDirectoryCatalog
import com.example.data.local.OfficialDirectoryDataset
import com.example.data.model.AccountStatus
import com.example.data.model.AuditLog
import com.example.data.model.DirectoryImportSummary
import com.example.data.model.PollingUnit
import com.example.data.model.PuOperationalStatus
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.model.Ward
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class DirectoryRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    private fun requireUid(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("Authenticated user required.")

    private fun <T> Flow<List<T>>.withFirestoreLogging(path: String): Flow<List<T>> =
        catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val ex = firestoreError ?: (error as? Exception)
            if (ex != null && auth.currentUser != null) {
                handleFirestoreError(ex, OperationType.LIST, path, auth)
            }
            throw error
        }

    fun observeWards(user: UserAccount): Flow<List<Ward>> {
        val base = db.collection("wards")
        val query: Query = when (user.roleEnum) {
            UserRole.FULL_CONTROL_ADMIN -> base
            UserRole.FUNTUA_SUPER_ADMIN -> base.whereEqualTo("lgaId", "funtua")
            UserRole.DANDUME_SUPER_ADMIN -> base.whereEqualTo("lgaId", "dandume")
            UserRole.WARD_COORDINATOR, UserRole.POLLING_UNIT_AGENT -> {
                if (user.assignedLgaId.isBlank()) return flowOf(emptyList())
                base.whereEqualTo("lgaId", user.assignedLgaId)
            }
            UserRole.PENDING -> return flowOf(emptyList())
        }
        return query.snapshots()
            .map { snap ->
                snap.toObjects(Ward::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedWith(compareBy({ it.lgaId }, { it.wardCode }, { it.name }))
            }
            .withFirestoreLogging("wards")
    }

    fun observePollingUnits(user: UserAccount): Flow<List<PollingUnit>> {
        val base = db.collection("polling_units")
        val query: Query = when (user.roleEnum) {
            UserRole.FULL_CONTROL_ADMIN -> base
            UserRole.FUNTUA_SUPER_ADMIN -> base.whereEqualTo("lgaId", "funtua")
            UserRole.DANDUME_SUPER_ADMIN -> base.whereEqualTo("lgaId", "dandume")
            UserRole.WARD_COORDINATOR -> {
                if (user.assignedWardId.isBlank()) return flowOf(emptyList())
                base.whereEqualTo("wardId", user.assignedWardId)
            }
            UserRole.POLLING_UNIT_AGENT -> {
                base.whereEqualTo("assignedAgentUid", user.uid)
            }
            UserRole.PENDING -> return flowOf(emptyList())
        }
        return query.snapshots()
            .map { snap ->
                snap.toObjects(PollingUnit::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedWith(compareBy({ it.lgaId }, { it.wardName }, { it.puCode }))
            }
            .withFirestoreLogging("polling_units")
    }

    fun observeUsers(user: UserAccount): Flow<List<UserAccount>> {
        val base = db.collection("users")
        val query: Query = when (user.roleEnum) {
            UserRole.FULL_CONTROL_ADMIN -> base
            UserRole.FUNTUA_SUPER_ADMIN -> base.whereEqualTo("assignedLgaId", "funtua")
            UserRole.DANDUME_SUPER_ADMIN -> base.whereEqualTo("assignedLgaId", "dandume")
            UserRole.WARD_COORDINATOR -> {
                if (user.assignedWardId.isBlank()) return flowOf(emptyList())
                base.whereEqualTo("assignedWardId", user.assignedWardId)
            }
            UserRole.POLLING_UNIT_AGENT, UserRole.PENDING -> return flowOf(emptyList())
        }
        return query.snapshots()
            .map { snap ->
                snap.toObjects(UserAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.displayName }
            }
            .withFirestoreLogging("users")
    }

    fun observeAuditLogs(user: UserAccount): Flow<List<AuditLog>> {
        if (!user.roleEnum.canViewAuditLogs()) return flowOf(emptyList())
        return db.collection("audit_logs")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(150)
            .snapshots()
            .map { snap -> snap.toObjects(AuditLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .withFirestoreLogging("audit_logs")
    }

    /**
     * Idempotent controlled migration/import of the authoritative preloaded PDF directory
     * (22 wards and 475 polling units: 298 Funtua + 177 Dandume).
     * Never overwrites existing ward coordinators, assigned field agents, statuses, or vote records.
     */
    suspend fun importPreloadedOfficialDirectory(
        actor: UserAccount,
        dataset: OfficialDirectoryDataset
    ): Result<DirectoryImportSummary> = runCatching {
        val uid = requireUid()
        require(actor.roleEnum == UserRole.FULL_CONTROL_ADMIN) {
            "Only Full Control Admin can execute master directory import."
        }
        val report = OfficialDirectoryCatalog.validate(dataset)
        require(report.isValid) {
            "Master directory validation failed: ${report.invalidReasons.joinToString("; ")}"
        }

        val existingWardIds = try {
            db.collection("wards").get().await().documents.map { it.id }.toSet()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, "wards", auth)
            throw e
        }

        val missingWards = dataset.wards.filter { it.docId !in existingWardIds }
        if (missingWards.isNotEmpty()) {
            val wardBatch = db.batch()
            missingWards.forEach { w ->
                val ref = db.collection("wards").document(w.docId)
                wardBatch.set(
                    ref,
                    mapOf(
                        "lgaId" to w.lgaId,
                        "wardCode" to w.wardCode,
                        "name" to w.name,
                        "coordinatorUid" to "",
                        "coordinatorName" to "",
                        "expectedPollingUnits" to w.expectedPollingUnits.toLong(),
                        "isTestData" to false,
                        "createdByUid" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            try {
                wardBatch.commit().await()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.CREATE, "wards", auth)
                throw e
            }
        }

        val existingPuIds = try {
            db.collection("polling_units").get().await().documents.map { it.id }.toSet()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, "polling_units", auth)
            throw e
        }

        val missingPus = dataset.pollingUnits.filter { it.docId !in existingPuIds }
        var funtuaImported = 0
        var dandumeImported = 0

        missingPus.chunked(180).forEach { chunk ->
            val puBatch = db.batch()
            chunk.forEach { pu ->
                val ref = db.collection("polling_units").document(pu.docId)
                puBatch.set(
                    ref,
                    mapOf(
                        "lgaId" to pu.lgaId,
                        "wardId" to pu.wardDocId,
                        "wardName" to pu.wardName,
                        "puCode" to pu.puCode,
                        "name" to pu.name,
                        "locationDescription" to "${pu.wardName} Ward · ${pu.status}",
                        "coordinatesVerified" to false,
                        "assignedAgentUid" to "",
                        "assignedAgentName" to "",
                        "operationalStatus" to PuOperationalStatus.NOT_STARTED.name,
                        "registeredVoters" to 0L,
                        "puStatusLabel" to pu.status,
                        "isMasterRecord" to true,
                        "isTestData" to false,
                        "createdByUid" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                if (pu.lgaId == "funtua") funtuaImported++ else if (pu.lgaId == "dandume") dandumeImported++
            }
            try {
                puBatch.commit().await()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.CREATE, "polling_units", auth)
                throw e
            }
        }

        val funtuaDbCount = db.collection("polling_units").whereEqualTo("lgaId", "funtua").get().await()
            .documents.count { it.getBoolean("isTestData") != true }
        val dandumeDbCount = db.collection("polling_units").whereEqualTo("lgaId", "dandume").get().await()
            .documents.count { it.getBoolean("isTestData") != true }
        val totalDbCount = funtuaDbCount + dandumeDbCount
        val countsVerified = funtuaDbCount >= 298 && dandumeDbCount >= 177 && totalDbCount >= 475

        val totalNew = funtuaImported + dandumeImported
        db.collection("audit_logs").document().set(
            auditPayload(
                actor,
                "MASTER_DIRECTORY_PRELOADED",
                "polling_units",
                "official_2027_master",
                "Idempotent PDF directory sync: +$totalNew new ($funtuaImported Funtua, $dandumeImported Dandume). Verified DB totals: Funtua=$funtuaDbCount, Dandume=$dandumeDbCount, Combined=$totalDbCount."
            )
        ).await()

        DirectoryImportSummary(
            datasetVersion = dataset.datasetVersion,
            funtuaNewlyImported = funtuaImported,
            dandumeNewlyImported = dandumeImported,
            totalNewlyImported = totalNew,
            funtuaVerifiedInDatabase = funtuaDbCount,
            dandumeVerifiedInDatabase = dandumeDbCount,
            totalVerifiedInDatabase = totalDbCount,
            duplicateRecordsDetected = report.duplicateCodeCount,
            invalidOrIncompleteRecords = report.invalidOrIncompleteCount,
            recordsRequiringManualVerification = report.advisoryRecordCount,
            advisories = report.advisories,
            countsVerified = countsVerified
        )
    }

    /**
     * Controlled master-directory correction restricted exclusively to Full Control Admin.
     * Atomically captures a pre-edit backup snapshot in `directory_backups`, updates the master PU,
     * and writes an immutable security audit log entry.
     */
    suspend fun correctMasterPollingUnit(
        actor: UserAccount,
        pu: PollingUnit,
        correctedName: String,
        correctedLocation: String,
        latitude: Double?,
        longitude: Double?,
        coordinatesVerified: Boolean,
        registeredVoters: Long,
        reason: String
    ): Result<Unit> = runCatching {
        val uid = requireUid()
        require(actor.roleEnum.canCorrectMasterDirectory()) {
            "Only Full Control Admin may modify master directory records."
        }
        val cleanName = correctedName.trim()
        val cleanLocation = correctedLocation.trim()
        val cleanReason = reason.trim()
        require(cleanName.length >= 2) { "Polling unit name must be at least 2 characters." }
        require(cleanReason.length >= 5) { "A documented correction reason (min 5 chars) is required." }

        val puRef = db.collection("polling_units").document(pu.id)
        val backupRef = db.collection("directory_backups").document()
        val finalCoordsVerified = coordinatesVerified && latitude != null && longitude != null

        val backupPayload = mutableMapOf<String, Any>(
            "entityType" to "polling_units",
            "targetDocId" to pu.id,
            "lgaId" to pu.lgaId,
            "puCode" to pu.puCode,
            "previousName" to pu.name,
            "previousLocationDescription" to pu.locationDescription,
            "previousRegisteredVoters" to pu.registeredVoters,
            "previousCoordinatesVerified" to pu.coordinatesVerified,
            "correctionReason" to cleanReason.take(500),
            "backedUpByUid" to uid,
            "backedUpByEmail" to actor.email,
            "createdAt" to FieldValue.serverTimestamp()
        )
        if (pu.latitude != null) backupPayload["previousLatitude"] = pu.latitude
        if (pu.longitude != null) backupPayload["previousLongitude"] = pu.longitude

        val puUpdates = mutableMapOf<String, Any>(
            "name" to cleanName.take(155),
            "locationDescription" to cleanLocation.take(290),
            "coordinatesVerified" to finalCoordsVerified,
            "registeredVoters" to registeredVoters.coerceIn(0L, 50000L),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (finalCoordsVerified && latitude != null && longitude != null) {
            puUpdates["latitude"] = latitude
            puUpdates["longitude"] = longitude
        } else {
            puUpdates["latitude"] = FieldValue.delete()
            puUpdates["longitude"] = FieldValue.delete()
        }

        val batch = db.batch()
        batch.set(backupRef, backupPayload)
        batch.update(puRef, puUpdates)
        batch.set(
            db.collection("audit_logs").document(),
            auditPayload(
                actor,
                "MASTER_PU_CORRECTED",
                "polling_units",
                pu.id,
                "Corrected master PU ${pu.puCode} (${pu.name} -> $cleanName). Backup=${backupRef.id}. Reason: $cleanReason"
            )
        )
        try {
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, puRef.path, auth)
            throw e
        }
    }

    suspend fun assignAgentToPollingUnit(
        actor: UserAccount,
        pu: PollingUnit,
        agent: UserAccount
    ): Result<Unit> = runCatching {
        requireUid()
        val puRef = db.collection("polling_units").document(pu.id)
        val userRef = db.collection("users").document(agent.uid)
        val nextStatus = if (pu.statusEnum == PuOperationalStatus.NOT_STARTED) {
            PuOperationalStatus.AGENT_ASSIGNED.name
        } else {
            pu.operationalStatus
        }

        val batch = db.batch()
        batch.update(
            puRef,
            mapOf(
                "assignedAgentUid" to agent.uid,
                "assignedAgentName" to agent.displayName,
                "operationalStatus" to nextStatus,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.update(
            userRef,
            mapOf(
                "role" to UserRole.POLLING_UNIT_AGENT.name,
                "status" to AccountStatus.ACTIVE.name,
                "assignedLgaId" to pu.lgaId,
                "assignedWardId" to pu.wardId,
                "assignedPollingUnitId" to pu.id,
                "sessionRevoked" to false,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(
            db.collection("audit_logs").document(),
            auditPayload(actor, "AGENT_ASSIGNED", "polling_units", pu.id, "Assigned ${agent.displayName} (${agent.email}) to ${pu.puCode}")
        )
        try {
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, puRef.path, auth)
            throw e
        }
    }

    suspend fun updateUserRoleAndScope(
        actor: UserAccount,
        targetUser: UserAccount,
        newRole: UserRole,
        newStatus: AccountStatus,
        lgaId: String,
        wardId: String,
        puId: String
    ): Result<Unit> = runCatching {
        requireUid()
        val targetRef = db.collection("users").document(targetUser.uid)
        val batch = db.batch()
        batch.update(
            targetRef,
            mapOf(
                "role" to newRole.name,
                "status" to newStatus.name,
                "assignedLgaId" to lgaId,
                "assignedWardId" to wardId,
                "assignedPollingUnitId" to puId,
                "sessionRevoked" to (newStatus == AccountStatus.SUSPENDED),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        if (newRole == UserRole.FULL_CONTROL_ADMIN && newStatus == AccountStatus.ACTIVE) {
            batch.set(
                db.collection("admins").document(targetUser.uid),
                mapOf(
                    "uid" to targetUser.uid,
                    "email" to targetUser.email,
                    "grantedByUid" to actor.uid,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
        }
        batch.set(
            db.collection("audit_logs").document(),
            auditPayload(
                actor,
                "USER_ROLE_UPDATED",
                "users",
                targetUser.uid,
                "Updated ${targetUser.email}: role=${newRole.name}, status=${newStatus.name}, lga=$lgaId, ward=$wardId"
            )
        )
        try {
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, targetRef.path, auth)
            throw e
        }
    }

    suspend fun revokeUserAccessEmergency(
        actor: UserAccount,
        targetUser: UserAccount,
        reason: String
    ): Result<Unit> = runCatching {
        requireUid()
        val cleanReason = reason.trim().ifBlank { "Emergency access revocation by administrator" }.take(280)
        val targetRef = db.collection("users").document(targetUser.uid)
        val batch = db.batch()
        batch.update(
            targetRef,
            mapOf(
                "status" to AccountStatus.SUSPENDED.name,
                "sessionRevoked" to true,
                "revokedReason" to cleanReason,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(
            db.collection("audit_logs").document(),
            auditPayload(
                actor,
                "EMERGENCY_ACCESS_REVOCATION",
                "users",
                targetUser.uid,
                "Revoked sessions & suspended ${targetUser.displayName} (${targetUser.email}). Reason: $cleanReason"
            )
        )
        try {
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, targetRef.path, auth)
            throw e
        }
    }

    internal fun auditPayload(
        actor: UserAccount,
        action: String,
        entity: String,
        affectedId: String,
        details: String
    ): Map<String, Any> = mapOf(
        "actorUid" to actor.uid,
        "actorName" to actor.displayName.ifBlank { actor.email },
        "actorEmail" to actor.email,
        "actorRole" to actor.role,
        "action" to action,
        "affectedEntity" to entity,
        "affectedId" to affectedId,
        "details" to details.take(980),
        "createdAt" to FieldValue.serverTimestamp()
    )
}
