package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.local.OfflineAttachmentEntity
import com.example.data.local.OfflineItemType
import com.example.data.local.OfflineQueueEntity
import com.example.data.local.OfflineSyncStatus
import com.example.data.local.SyncHistoryEntity
import com.example.data.model.AgentCheckIn
import com.example.data.model.PollingUnit
import com.example.data.model.PuOperationalStatus
import com.example.data.model.UserAccount
import com.example.ui.components.CompactSyncBanner
import com.example.ui.components.EmptyOperationalState
import com.example.ui.components.LocalReportDetailDialog
import com.example.ui.components.PuStatusBadge
import com.example.ui.components.ReportSyncStatusBadge
import com.example.ui.components.SearchablePollingUnitField
import com.example.ui.components.StatusBadge
import com.example.ui.components.SyncDashboardSummaryCard
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.AlertCritical
import com.example.ui.theme.AlertWarning
import com.example.ui.theme.AlertWarningContainer
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.SoftGreySurface
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.StatusVerifiedContainer
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.WhiteBackground
import com.example.ui.viewmodel.OfflineReportEditRequest
import com.example.ui.viewmodel.SyncDashboardMetrics
import com.example.util.DeviceTelemetry
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private enum class QueueFilterTab(val label: String) {
    ALL("All Reports"),
    ACTIVE_QUEUE("Active Queue"),
    DRAFTS("Drafts"),
    CONFIRMED_HISTORY("Submission History")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FieldOpsScreen(
    user: UserAccount,
    pollingUnits: List<PollingUnit>,
    checkIns: List<AgentCheckIn>,
    offlineQueue: List<OfflineQueueEntity>,
    offlineAttachments: List<OfflineAttachmentEntity>,
    syncHistory: List<SyncHistoryEntity>,
    syncMetrics: SyncDashboardMetrics,
    editRequest: OfflineReportEditRequest?,
    onConsumeEditRequest: () -> Unit,
    onAutoSaveCheckInDraft: (String, PollingUnit?, String, String, Double?, Double?) -> Unit,
    onSubmitCheckIn: (PollingUnit, String, String, Int, String, Boolean, Double?, Double?, String?) -> Unit,
    onUpdatePuStatus: (PollingUnit, PuOperationalStatus) -> Unit,
    onSyncQueue: () -> Unit,
    onArchiveConfirmedQueue: () -> Unit,
    onEditOfflineReport: (OfflineQueueEntity) -> Unit
) {
    val context = LocalContext.current
    var subTab by remember { mutableIntStateOf(0) }
    var includeCoarseLocation by remember { mutableStateOf(false) }
    var inspectedReport by remember { mutableStateOf<OfflineQueueEntity?>(null) }

    val locationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        includeCoarseLocation = granted
    }

    val telemetry = remember(includeCoarseLocation, subTab, syncMetrics.isOnline) {
        DeviceTelemetry.readSnapshot(context, includeCoarseLocationIfPermitted = includeCoarseLocation)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        SecondaryTabRow(
            selectedTabIndex = subTab,
            containerColor = WhiteBackground
        ) {
            Tab(selected = subTab == 0, onClick = { subTab = 0 }, text = { Text("Check-In & Status") })
            Tab(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                text = { Text("Sync & History (${syncMetrics.outstandingSyncCount}/${offlineQueue.size})") }
            )
        }

        if (subTab == 0) {
            var draftReportId by remember {
                mutableStateOf("ci_${user.uid.take(6)}_${UUID.randomUUID().toString().take(8)}")
            }
            var editingExistingId by remember { mutableStateOf<String?>(null) }
            var selectedPu by remember(pollingUnits) {
                mutableStateOf(
                    pollingUnits.firstOrNull { it.id == user.assignedPollingUnitId } ?: pollingUnits.firstOrNull()
                )
            }
            var arrivalTime by remember {
                mutableStateOf(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()))
            }
            var comments by remember { mutableStateOf("") }
            var selectedStatus by remember(selectedPu) {
                mutableStateOf(selectedPu?.statusEnum ?: PuOperationalStatus.AGENT_CHECKED_IN)
            }
            var statusExpanded by remember { mutableStateOf(false) }

            LaunchedEffect(editRequest) {
                val req = editRequest ?: return@LaunchedEffect
                if (req.itemType == OfflineItemType.CHECK_IN) {
                    runCatching {
                        val obj = JSONObject(req.payloadJson)
                        val puId = obj.optString("puId")
                        if (puId.isNotBlank()) {
                            pollingUnits.firstOrNull { it.id == puId }?.let { selectedPu = it }
                        }
                        arrivalTime = obj.optString("arrivalTimeText", arrivalTime)
                        comments = obj.optString("comments", "")
                        draftReportId = req.reportId
                        editingExistingId = req.reportId
                        subTab = 0
                    }
                    onConsumeEditRequest()
                }
            }

            // Automatic local draft saving whenever form fields change
            LaunchedEffect(selectedPu, arrivalTime, comments, includeCoarseLocation) {
                delay(350L)
                if (selectedPu != null || comments.isNotBlank()) {
                    val snap = DeviceTelemetry.readSnapshot(context, includeCoarseLocation)
                    onAutoSaveCheckInDraft(
                        draftReportId,
                        selectedPu,
                        arrivalTime,
                        comments,
                        snap.latitude,
                        snap.longitude
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    CompactSyncBanner(
                        metrics = syncMetrics,
                        onSyncNow = onSyncQueue,
                        onOpenSyncDashboard = { subTab = 1 }
                    )
                }

                // Real Device Telemetry Strip
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                        border = BorderStroke(1.dp, BorderLight)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Filled.Wifi, contentDescription = "Connectivity", tint = if (telemetry.isOnline) StatusVerified else AlertWarning)
                                Text(telemetry.networkLabel, style = MonoCodeStyle, color = TextPrimaryLight)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Filled.BatteryChargingFull, contentDescription = "Battery", tint = EmeraldPrimary)
                                Text(
                                    if (telemetry.batteryPercent >= 0) "${telemetry.batteryPercent}%" else "N/A",
                                    style = MonoCodeStyle,
                                    color = TextPrimaryLight
                                )
                            }
                            StatusBadge(
                                label = if (telemetry.isOnline) "Online" else "Offline Mode",
                                icon = if (telemetry.isOnline) Icons.Filled.CloudDone else Icons.Filled.CloudOff,
                                containerColor = if (telemetry.isOnline) StatusVerifiedContainer else AlertWarningContainer,
                                contentColor = if (telemetry.isOnline) StatusVerified else AlertWarning
                            )
                        }
                    }
                }

                if (pollingUnits.isEmpty()) {
                    item {
                        EmptyOperationalState(
                            title = "No Polling Unit Available Yet",
                            description = "Your scoped polling units appear here from local cache even when offline. Ask an admin to assign your official PU if empty.",
                            icon = Icons.Filled.HowToReg
                        )
                    }
                } else {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                            border = BorderStroke(1.dp, BorderLight)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (editingExistingId != null) "Edit Offline Check-In" else "Election-Day Agent Check-In",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = EmeraldDeep
                                    )
                                    Text(draftReportId.take(14), style = MonoCodeStyle, color = TextSecondaryLight)
                                }

                                SearchablePollingUnitField(
                                    label = "Polling Unit (Preloaded Offline Directory)",
                                    pollingUnits = pollingUnits,
                                    selectedPu = selectedPu,
                                    onSelectPu = { pu ->
                                        if (pu != null) {
                                            selectedPu = pu
                                            selectedStatus = pu.statusEnum
                                        }
                                    },
                                    testTag = "checkin_pu_selector"
                                )

                                OutlinedTextField(
                                    value = arrivalTime,
                                    onValueChange = { arrivalTime = it },
                                    label = { Text("Confirmed Arrival Time") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("checkin_arrival_input")
                                )

                                OutlinedTextField(
                                    value = comments,
                                    onValueChange = { comments = it },
                                    label = { Text("Operational Comments (Auto-Saved Locally)") },
                                    minLines = 2,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("checkin_comments_input")
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Icon(Icons.Filled.LocationOn, contentDescription = null, modifier = Modifier.size(18.dp), tint = EmeraldPrimary)
                                        Text("Attach Optional Coarse Location", style = MaterialTheme.typography.bodySmall, color = TextPrimaryLight)
                                    }
                                    Switch(
                                        checked = includeCoarseLocation,
                                        onCheckedChange = { checked ->
                                            if (checked) {
                                                val hasPerm = ContextCompat.checkSelfPermission(
                                                    context, Manifest.permission.ACCESS_COARSE_LOCATION
                                                ) == PackageManager.PERMISSION_GRANTED
                                                if (hasPerm) {
                                                    includeCoarseLocation = true
                                                } else {
                                                    locationLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                                                }
                                            } else {
                                                includeCoarseLocation = false
                                            }
                                        }
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    OutlinedButton(
                                        onClick = {
                                            val snap = DeviceTelemetry.readSnapshot(context, includeCoarseLocation)
                                            onAutoSaveCheckInDraft(
                                                draftReportId,
                                                selectedPu,
                                                arrivalTime,
                                                comments,
                                                snap.latitude,
                                                snap.longitude
                                            )
                                        },
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("save_checkin_draft_button")
                                    ) {
                                        Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.size(4.dp))
                                        Text("Save Draft")
                                    }

                                    Button(
                                        onClick = {
                                            val pu = selectedPu ?: return@Button
                                            val snap = DeviceTelemetry.readSnapshot(context, includeCoarseLocation)
                                            onSubmitCheckIn(
                                                pu,
                                                arrivalTime,
                                                comments,
                                                snap.batteryPercent,
                                                snap.networkLabel,
                                                snap.isOnline,
                                                snap.latitude,
                                                snap.longitude,
                                                draftReportId
                                            )
                                            comments = ""
                                            editingExistingId = null
                                            draftReportId = "ci_${user.uid.take(6)}_${UUID.randomUUID().toString().take(8)}"
                                        },
                                        enabled = selectedPu != null && arrivalTime.isNotBlank(),
                                        modifier = Modifier
                                            .weight(1.4f)
                                            .testTag("submit_checkin_button")
                                    ) {
                                        Text(if (telemetry.isOnline) "Submit Check-In" else "Queue Check-In")
                                    }
                                }
                            }
                        }
                    }

                    // Polling Unit Operational Status Updater
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                            border = BorderStroke(1.dp, BorderLight)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Update Polling Unit Status (Offline-First)", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
                                selectedPu?.let { PuStatusBadge(it.statusEnum) }

                                ExposedDropdownMenuBox(expanded = statusExpanded, onExpandedChange = { statusExpanded = it }) {
                                    OutlinedTextField(
                                        value = selectedStatus.label,
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("Operational Milestone") },
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusExpanded) },
                                        modifier = Modifier
                                            .menuAnchor(MenuAnchorType.PrimaryNotEditable, true)
                                            .fillMaxWidth()
                                    )
                                    ExposedDropdownMenu(expanded = statusExpanded, onDismissRequest = { statusExpanded = false }) {
                                        PuOperationalStatus.entries.forEach { st ->
                                            DropdownMenuItem(
                                                text = { Text(st.label) },
                                                onClick = {
                                                    selectedStatus = st
                                                    statusExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                OutlinedButton(
                                    onClick = { selectedPu?.let { onUpdatePuStatus(it, selectedStatus) } },
                                    enabled = selectedPu != null,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("update_pu_status_button")
                                ) {
                                    Text(if (telemetry.isOnline) "Publish Status Update" else "Queue Status Update Offline")
                                }
                            }
                        }
                    }
                }

                // Recent Verified Check-Ins Log
                item {
                    Text("Synced Server Check-Ins (${checkIns.size})", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
                }
                if (checkIns.isEmpty()) {
                    item {
                        EmptyOperationalState(
                            title = "No server check-ins received yet.",
                            description = "Check-ins saved offline remain protected in Sync & History and sync automatically when internet returns."
                        )
                    }
                } else {
                    items(checkIns, key = { it.id }) { ci ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                            border = BorderStroke(1.dp, BorderLight)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(ci.agentName, style = MaterialTheme.typography.titleSmall, color = TextPrimaryLight)
                                    Text("Arrived ${ci.arrivalTimeText}", style = MonoCodeStyle, color = StatusVerified)
                                }
                                Text("${ci.puCode} · ${ci.puName}", style = MaterialTheme.typography.bodySmall, color = TextPrimaryLight)
                                if (ci.comments.isNotBlank()) {
                                    Text(ci.comments, style = MaterialTheme.typography.bodySmall, color = TextSecondaryLight)
                                }
                                Text(
                                    text = "Battery: ${if (ci.batteryPercent >= 0) "${ci.batteryPercent}%" else "N/A"} · ${ci.networkStatus} · ${formatTimestamp(ci.createdAt)}",
                                    style = MonoCodeStyle,
                                    color = TextSecondaryLight
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // Section 8.D & 8.E: Full Sync Dashboard + Permanent Local Submission History
            val dateFmt = remember { SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault()) }
            var selectedFilter by remember { mutableStateOf(QueueFilterTab.ALL) }

            val filteredQueue = remember(offlineQueue, selectedFilter) {
                offlineQueue.filter { item ->
                    val status = OfflineSyncStatus.fromString(item.syncStatus)
                    when (selectedFilter) {
                        QueueFilterTab.ALL -> true
                        QueueFilterTab.ACTIVE_QUEUE -> !item.isDraftEditable && !item.archivedFromQueue
                        QueueFilterTab.DRAFTS -> item.isDraftEditable || status == OfflineSyncStatus.SAVED_LOCALLY
                        QueueFilterTab.CONFIRMED_HISTORY -> status.isSyncedWithServer()
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    SyncDashboardSummaryCard(
                        metrics = syncMetrics,
                        onSyncNow = onSyncQueue,
                        onArchiveConfirmed = onArchiveConfirmedQueue
                    )
                }

                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        QueueFilterTab.entries.forEach { tab ->
                            FilterChip(
                                selected = selectedFilter == tab,
                                onClick = { selectedFilter = tab },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag("queue_filter_${tab.name.lowercase()}")
                            )
                        }
                    }
                }

                if (filteredQueue.isEmpty()) {
                    item {
                        EmptyOperationalState(
                            title = "No local records in this filter.",
                            description = "Every report draft and submitted report is retained locally so you never lose field evidence or submission history.",
                            icon = Icons.Filled.CloudDone
                        )
                    }
                } else {
                    items(filteredQueue, key = { it.clientSubmissionId }) { item ->
                        val syncStatus = OfflineSyncStatus.fromString(item.syncStatus)
                        val reportAttachments = remember(offlineAttachments, item.clientSubmissionId) {
                            offlineAttachments.filter { it.reportId == item.clientSubmissionId }
                        }
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { inspectedReport = item }
                                .testTag("offline_report_card_${item.clientSubmissionId}"),
                            colors = CardDefaults.cardColors(
                                containerColor = if (syncStatus == OfflineSyncStatus.SAVED_LOCALLY) SoftGreySurface else WhiteBackground
                            ),
                            border = BorderStroke(
                                1.dp,
                                when {
                                    item.hasConflict || syncStatus == OfflineSyncStatus.SYNC_FAILED -> AlertCritical
                                    syncStatus.isSyncedWithServer() -> StatusVerified.copy(alpha = 0.45f)
                                    else -> BorderLight
                                }
                            )
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = item.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = TextPrimaryLight,
                                        modifier = Modifier.weight(1f)
                                    )
                                    ReportSyncStatusBadge(status = syncStatus, hasConflict = item.hasConflict)
                                }
                                Text(item.subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondaryLight)
                                if (reportAttachments.isNotEmpty()) {
                                    Text(
                                        text = "Attachments: ${reportAttachments.size} file(s) · " +
                                            reportAttachments.joinToString { "${it.fileName} [${OfflineSyncStatus.fromString(it.uploadStatus).label}]" },
                                        style = MonoCodeStyle,
                                        color = EmeraldPrimary
                                    )
                                }
                                Text(
                                    text = buildString {
                                        append("ID: ${item.clientSubmissionId.take(18)} · Created: ${dateFmt.format(Date(item.createdAtMillis))}")
                                        item.syncedAtMillis?.let { append(" · Synced: ${dateFmt.format(Date(it))}") }
                                    },
                                    style = MonoCodeStyle,
                                    color = TextSecondaryLight
                                )
                                item.conflictMessage?.let {
                                    Text(it, style = MaterialTheme.typography.bodySmall, color = AlertCritical)
                                } ?: item.lastError?.let {
                                    Text("Error: $it", style = MaterialTheme.typography.bodySmall, color = AlertCritical)
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = { inspectedReport = item }) {
                                        Text("View Details")
                                    }
                                    if (syncStatus.isUnsentOrEditable() && !item.hasConflict) {
                                        TextButton(
                                            onClick = { onEditOfflineReport(item) },
                                            modifier = Modifier.testTag("edit_offline_${item.clientSubmissionId}")
                                        ) {
                                            Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.size(4.dp))
                                            Text("Edit")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (syncHistory.isNotEmpty()) {
                    item {
                        Text("Recent Synchronization Audit Trail", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
                    }
                    items(syncHistory.take(15), key = { it.id }) { event ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = SoftGreySurface),
                            border = BorderStroke(1.dp, BorderLight)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text("${event.eventType} · ${event.status}", style = MonoCodeStyle, color = EmeraldPrimary)
                                Text(event.message, style = MaterialTheme.typography.bodySmall, color = TextPrimaryLight)
                                Text("${event.reportId.take(20)} · ${dateFmt.format(Date(event.timestampMillis))}", style = MonoCodeStyle, color = TextSecondaryLight)
                            }
                        }
                    }
                }
            }
        }
    }

    inspectedReport?.let { report ->
        val atts = offlineAttachments.filter { it.reportId == report.clientSubmissionId }
        val hist = syncHistory.filter { it.reportId == report.clientSubmissionId }
        LocalReportDetailDialog(
            report = report,
            attachments = atts,
            history = hist,
            onDismiss = { inspectedReport = null },
            onEditReport = if (OfflineSyncStatus.fromString(report.syncStatus).isUnsentOrEditable() && !report.hasConflict) {
                {
                    inspectedReport = null
                    onEditOfflineReport(report)
                }
            } else {
                null
            }
        )
    }
}
