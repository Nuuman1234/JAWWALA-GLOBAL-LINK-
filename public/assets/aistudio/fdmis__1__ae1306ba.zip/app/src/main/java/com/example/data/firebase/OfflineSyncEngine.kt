package com.example.data.firebase

import android.util.Log
import com.example.data.local.OfflineAttachmentEntity
import com.example.data.local.OfflineItemType
import com.example.data.local.OfflineQueueDao
import com.example.data.local.OfflineQueueEntity
import com.example.data.local.OfflineSyncStatus
import com.example.data.local.SyncHistoryEntity
import com.example.data.model.IncidentUrgency
import com.example.data.model.PollingUnit
import com.example.data.model.PuOperationalStatus
import com.example.data.model.ResultSubmission
import com.example.data.model.UserAccount
import com.example.data.model.VerificationStatus
import com.example.util.ImageCompression
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Source
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class SyncBatchSummary(
    val backendReachable: Boolean,
    val syncedCount: Int = 0,
    val failedCount: Int = 0,
    val conflictCount: Int = 0,
    val attachmentRetryPendingCount: Int = 0
)

data class OfflineAttachmentDraft(
    val attachmentId: String = "att_${UUID.randomUUID().toString().replace("-", "").take(16)}",
    val fileName: String,
    val localFilePath: String,
    val sha256Hash: String,
    val sizeBytes: Int
)

class OfflineSyncEngine(
    private val db: FirebaseFirestore,
    private val dao: OfflineQueueDao,
    private val auth: FirebaseAuth,
    private val opsRepo: OperationsRepository
) {
    /**
     * Verifies true backend reachability by querying the server directly (not local cache or ConnectivityManager).
     */
    suspend fun verifyBackendReachable(): Boolean {
        if (auth.currentUser == null) return false
        return try {
            withTimeout(4500L) {
                db.collection("system_settings").document("global").get(Source.SERVER).await()
            }
            true
        } catch (_: TimeoutCancellationException) {
            false
        } catch (e: CancellationException) {
            throw e
        } catch (e: FirebaseFirestoreException) {
            // PERMISSION_DENIED or NOT_FOUND means the backend actively responded.
            e.code != FirebaseFirestoreException.Code.UNAVAILABLE &&
                e.code != FirebaseFirestoreException.Code.DEADLINE_EXCEEDED
        } catch (_: Exception) {
            false
        }
    }

    suspend fun saveDraft(
        actor: UserAccount,
        reportId: String,
        itemType: OfflineItemType,
        lgaId: String,
        wardId: String,
        pu: PollingUnit?,
        title: String,
        subtitle: String,
        payloadJson: JSONObject,
        attachmentDraft: OfflineAttachmentDraft? = null
    ): String {
        val now = System.currentTimeMillis()
        val existing = dao.getByIdForUser(reportId, actor.uid)
        val createdAt = existing?.createdAtMillis ?: now
        val entity = OfflineQueueEntity(
            clientSubmissionId = reportId,
            ownerUid = actor.uid,
            ownerEmail = actor.email,
            itemType = itemType.name,
            lgaId = pu?.lgaId ?: lgaId,
            wardId = pu?.wardId ?: wardId,
            puId = pu?.id ?: "",
            puCode = pu?.puCode ?: (if (lgaId.isNotBlank()) "WARD-LEVEL" else ""),
            puName = pu?.name ?: (if (lgaId.isNotBlank()) "Ward / LGA Level" else ""),
            title = title.take(160),
            subtitle = subtitle.take(200),
            payloadJson = payloadJson.toString(),
            syncStatus = OfflineSyncStatus.SAVED_LOCALLY.name,
            isDraftEditable = true,
            serverDocId = existing?.serverDocId,
            serverVerifiedAck = false,
            serverVersion = existing?.serverVersion ?: 1L,
            hasConflict = false,
            conflictMessage = null,
            lastError = null,
            retryCount = existing?.retryCount ?: 0,
            nextRetryAtMillis = 0L,
            createdAtMillis = createdAt,
            updatedAtMillis = now,
            syncedAtMillis = existing?.syncedAtMillis,
            archivedFromQueue = false
        )
        dao.upsert(entity)
        if (attachmentDraft != null && attachmentDraft.localFilePath.isNotBlank()) {
            persistAttachmentLink(
                actor = actor,
                reportId = reportId,
                reportType = itemType,
                lgaId = pu?.lgaId ?: lgaId,
                wardId = pu?.wardId ?: wardId,
                puId = pu?.id ?: "",
                attachment = attachmentDraft,
                status = OfflineSyncStatus.SAVED_LOCALLY
            )
        }
        if (existing == null) {
            dao.insertSyncHistory(
                SyncHistoryEntity(
                    ownerUid = actor.uid,
                    reportId = reportId,
                    eventType = "DRAFT_SAVED",
                    status = OfflineSyncStatus.SAVED_LOCALLY.name,
                    message = "Draft auto-saved locally (${itemType.name})"
                )
            )
        }
        return reportId
    }

    suspend fun enqueueForSync(
        actor: UserAccount,
        reportId: String,
        itemType: OfflineItemType,
        lgaId: String,
        wardId: String,
        pu: PollingUnit?,
        title: String,
        subtitle: String,
        payloadJson: JSONObject,
        attachmentDraft: OfflineAttachmentDraft? = null
    ): String {
        val now = System.currentTimeMillis()
        val existing = dao.getByIdForUser(reportId, actor.uid)
        val createdAt = existing?.createdAtMillis ?: now
        val entity = OfflineQueueEntity(
            clientSubmissionId = reportId,
            ownerUid = actor.uid,
            ownerEmail = actor.email,
            itemType = itemType.name,
            lgaId = pu?.lgaId ?: lgaId,
            wardId = pu?.wardId ?: wardId,
            puId = pu?.id ?: "",
            puCode = pu?.puCode ?: "WARD-LEVEL",
            puName = pu?.name ?: "Ward / LGA Level",
            title = title.take(160),
            subtitle = subtitle.take(200),
            payloadJson = payloadJson.toString(),
            syncStatus = OfflineSyncStatus.PENDING_SYNC.name,
            isDraftEditable = false,
            serverDocId = existing?.serverDocId,
            serverVerifiedAck = false,
            serverVersion = existing?.serverVersion ?: 1L,
            hasConflict = false,
            conflictMessage = null,
            lastError = null,
            retryCount = existing?.retryCount ?: 0,
            nextRetryAtMillis = 0L,
            createdAtMillis = createdAt,
            updatedAtMillis = now,
            syncedAtMillis = null,
            archivedFromQueue = false
        )
        dao.upsert(entity)
        if (attachmentDraft != null && attachmentDraft.localFilePath.isNotBlank()) {
            persistAttachmentLink(
                actor = actor,
                reportId = reportId,
                reportType = itemType,
                lgaId = pu?.lgaId ?: lgaId,
                wardId = pu?.wardId ?: wardId,
                puId = pu?.id ?: "",
                attachment = attachmentDraft,
                status = OfflineSyncStatus.PENDING_SYNC
            )
        }
        dao.queueReportAttachments(reportId, actor.uid)
        dao.insertSyncHistory(
            SyncHistoryEntity(
                ownerUid = actor.uid,
                reportId = reportId,
                eventType = "QUEUED_LOCAL_SUBMISSION",
                status = OfflineSyncStatus.PENDING_SYNC.name,
                message = "Saved locally and queued for sync ($title)"
            )
        )
        return reportId
    }

    private suspend fun persistAttachmentLink(
        actor: UserAccount,
        reportId: String,
        reportType: OfflineItemType,
        lgaId: String,
        wardId: String,
        puId: String,
        attachment: OfflineAttachmentDraft,
        status: OfflineSyncStatus
    ) {
        val existingAtt = dao.getAttachmentsForReport(reportId, actor.uid)
            .firstOrNull { it.sha256Hash == attachment.sha256Hash && it.localFilePath == attachment.localFilePath }
        if (existingAtt != null) {
            if (existingAtt.uploadStatus != OfflineSyncStatus.SYNCED.name) {
                dao.upsertAttachment(existingAtt.copy(uploadStatus = status.name))
            }
            return
        }
        dao.upsertAttachment(
            OfflineAttachmentEntity(
                attachmentId = attachment.attachmentId,
                reportId = reportId,
                ownerUid = actor.uid,
                reportType = reportType.name,
                lgaId = lgaId,
                wardId = wardId,
                puId = puId,
                fileName = attachment.fileName.take(110),
                localFilePath = attachment.localFilePath,
                sha256Hash = attachment.sha256Hash,
                sizeBytes = attachment.sizeBytes,
                uploadStatus = status.name,
                serverVerified = false
            )
        )
    }

    suspend fun syncPendingForUser(
        actor: UserAccount,
        pollingUnitsById: Map<String, PollingUnit>,
        resultsById: Map<String, ResultSubmission> = emptyMap(),
        forceRetryIgnoredBackoff: Boolean = false
    ): SyncBatchSummary {
        val queuedReports = dao.getAllQueuedForSync(actor.uid)
        val pendingAttachments = dao.getPendingAttachmentsForUser(actor.uid)
        if (queuedReports.isEmpty() && pendingAttachments.isEmpty()) {
            return SyncBatchSummary(backendReachable = true)
        }

        if (!verifyBackendReachable()) {
            return SyncBatchSummary(
                backendReachable = false,
                attachmentRetryPendingCount = pendingAttachments.size
            )
        }

        val now = System.currentTimeMillis()
        var syncedCount = 0
        var failedCount = 0
        var conflictCount = 0

        for (item in queuedReports) {
            val currentStatus = OfflineSyncStatus.fromString(item.syncStatus)
            if (!forceRetryIgnoredBackoff &&
                currentStatus == OfflineSyncStatus.SYNC_FAILED &&
                item.nextRetryAtMillis > now &&
                !item.hasConflict
            ) {
                continue
            }
            // Do not auto-retry flagged conflict items unless explicitly forced by user/admin after inspection
            if (item.hasConflict && !forceRetryIgnoredBackoff) {
                continue
            }

            dao.updateSyncAttemptState(
                id = item.clientSubmissionId,
                status = OfflineSyncStatus.SYNCING.name,
                error = null,
                retryCount = item.retryCount,
                nextRetryAtMillis = item.nextRetryAtMillis
            )
            dao.insertSyncHistory(
                SyncHistoryEntity(
                    ownerUid = actor.uid,
                    reportId = item.clientSubmissionId,
                    eventType = "SYNC_STARTED",
                    status = OfflineSyncStatus.SYNCING.name,
                    message = "Sync started for ${item.title}"
                )
            )

            val outcome = syncSingleQueueItem(actor, item, pollingUnitsById, resultsById)
            when (outcome) {
                is ItemSyncOutcome.Synced -> {
                    dao.markSyncedVerified(
                        id = item.clientSubmissionId,
                        serverDocId = outcome.serverDocId,
                        status = OfflineSyncStatus.SYNCED.name,
                        syncedAtMillis = System.currentTimeMillis()
                    )
                    dao.insertSyncHistory(
                        SyncHistoryEntity(
                            ownerUid = actor.uid,
                            reportId = item.clientSubmissionId,
                            eventType = "SERVER_ACK_VERIFIED",
                            status = OfflineSyncStatus.SYNCED.name,
                            message = "Verified by server (${outcome.serverDocId}); local history retained."
                        )
                    )
                    syncedCount++
                }
                is ItemSyncOutcome.Conflict -> {
                    dao.markConflict(
                        id = item.clientSubmissionId,
                        conflictMessage = outcome.reason,
                        status = OfflineSyncStatus.SYNC_FAILED.name
                    )
                    dao.insertSyncHistory(
                        SyncHistoryEntity(
                            ownerUid = actor.uid,
                            reportId = item.clientSubmissionId,
                            eventType = "CONFLICT_PROTECTED",
                            status = OfflineSyncStatus.SYNC_FAILED.name,
                            message = outcome.reason
                        )
                    )
                    conflictCount++
                    failedCount++
                }
                is ItemSyncOutcome.Failed -> {
                    val nextAttempt = item.retryCount + 1
                    val delayMs = exponentialBackoffMs(nextAttempt)
                    dao.updateSyncAttemptState(
                        id = item.clientSubmissionId,
                        status = OfflineSyncStatus.SYNC_FAILED.name,
                        error = outcome.error,
                        retryCount = nextAttempt,
                        nextRetryAtMillis = System.currentTimeMillis() + delayMs
                    )
                    dao.insertSyncHistory(
                        SyncHistoryEntity(
                            ownerUid = actor.uid,
                            reportId = item.clientSubmissionId,
                            eventType = "SYNC_FAILED",
                            status = OfflineSyncStatus.SYNC_FAILED.name,
                            message = "${outcome.error} (next retry in ${delayMs / 1000}s)"
                        )
                    )
                    failedCount++
                }
            }
        }

        // Upload any pending attachments belonging to synced reports independently
        val remainingPendingAtts = dao.getPendingAttachmentsForUser(actor.uid)
        var attachmentFailures = 0
        for (att in remainingPendingAtts) {
            val parent = dao.getByIdForUser(att.reportId, actor.uid)
            val parentStatus = parent?.let { OfflineSyncStatus.fromString(it.syncStatus) }
            if (parentStatus == null || !parentStatus.isSyncedWithServer()) {
                attachmentFailures++
                continue
            }
            dao.markAttachmentSyncing(att.attachmentId)
            val attRes = uploadAndVerifyAttachment(actor, att)
            if (attRes.isSuccess) {
                dao.markAttachmentVerified(att.attachmentId)
                dao.insertSyncHistory(
                    SyncHistoryEntity(
                        ownerUid = actor.uid,
                        reportId = att.reportId,
                        eventType = "ATTACHMENT_VERIFIED",
                        status = OfflineSyncStatus.SYNCED.name,
                        message = "Attachment ${att.fileName} verified by server"
                    )
                )
            } else {
                val msg = attRes.exceptionOrNull()?.localizedMessage ?: "Attachment upload failed"
                dao.markAttachmentFailed(att.attachmentId, OfflineSyncStatus.SYNC_FAILED.name, msg)
                dao.insertSyncHistory(
                    SyncHistoryEntity(
                        ownerUid = actor.uid,
                        reportId = att.reportId,
                        eventType = "ATTACHMENT_FAILED",
                        status = OfflineSyncStatus.SYNC_FAILED.name,
                        message = "Attachment failed (report kept safe): $msg"
                    )
                )
                attachmentFailures++
            }
        }

        return SyncBatchSummary(
            backendReachable = true,
            syncedCount = syncedCount,
            failedCount = failedCount,
            conflictCount = conflictCount,
            attachmentRetryPendingCount = attachmentFailures
        )
    }

    private suspend fun syncSingleQueueItem(
        actor: UserAccount,
        item: OfflineQueueEntity,
        pollingUnitsById: Map<String, PollingUnit>,
        resultsById: Map<String, ResultSubmission>
    ): ItemSyncOutcome {
        return try {
            val json = JSONObject(item.payloadJson)
            when (OfflineItemType.valueOf(item.itemType)) {
                OfflineItemType.CHECK_IN -> syncCheckInItem(actor, item, json, pollingUnitsById)
                OfflineItemType.STATUS_UPDATE -> syncStatusUpdateItem(actor, item, json, pollingUnitsById)
                OfflineItemType.INCIDENT_REPORT -> syncIncidentItem(actor, item, json, pollingUnitsById)
                OfflineItemType.RESULT_SUBMISSION -> syncResultItem(actor, item, json, pollingUnitsById, resultsById)
            }
        } catch (e: CancellationException) {
            if (e is TimeoutCancellationException) {
                ItemSyncOutcome.Failed("Server acknowledgement timed out")
            } else {
                throw e
            }
        } catch (e: Exception) {
            ItemSyncOutcome.Failed(e.localizedMessage ?: "Synchronization failed")
        }
    }

    private suspend fun syncCheckInItem(
        actor: UserAccount,
        item: OfflineQueueEntity,
        json: JSONObject,
        pollingUnitsById: Map<String, PollingUnit>
    ): ItemSyncOutcome {
        val docRef = db.collection("check_ins").document(item.clientSubmissionId)
        val existingServer = runCatching {
            withTimeout(6000L) { docRef.get(Source.SERVER).await() }
        }.getOrElse { err ->
            if (err is CancellationException && err !is TimeoutCancellationException) throw err
            null
        }
        if (existingServer != null && existingServer.exists() && existingServer.getString("clientSubmissionId") == item.clientSubmissionId) {
            return ItemSyncOutcome.Synced(docRef.id)
        }

        val puId = json.getString("puId")
        val serverPuSnap = runCatching {
            withTimeout(5000L) { db.collection("polling_units").document(puId).get(Source.SERVER).await() }
        }.getOrNull()
        val serverPu = serverPuSnap?.toObject(PollingUnit::class.java)
            ?: pollingUnitsById[puId]
            ?: PollingUnit(
                id = puId,
                lgaId = json.getString("lgaId"),
                wardId = json.getString("wardId"),
                puCode = json.getString("puCode"),
                name = json.getString("puName"),
                isTestData = json.optBoolean("isTestData", false)
            )
        val serverUpdatedMs = serverPu.updatedAt?.toDate()?.time ?: 0L
        val skipStatusRegression = serverUpdatedMs > item.createdAtMillis ||
            serverPu.statusEnum.stepOrder > PuOperationalStatus.AGENT_CHECKED_IN.stepOrder

        val res = opsRepo.submitCheckIn(
            actor = actor,
            pu = serverPu,
            arrivalTimeText = json.getString("arrivalTimeText"),
            comments = json.optString("comments", ""),
            batteryPercent = json.optInt("batteryPercent", -1),
            networkStatus = json.optString("networkStatus", "Offline Queue"),
            latitude = if (json.has("latitude")) json.getDouble("latitude") else null,
            longitude = if (json.has("longitude")) json.getDouble("longitude") else null,
            clientSubmissionId = item.clientSubmissionId,
            skipPuStatusRegression = skipStatusRegression
        )
        res.exceptionOrNull()?.let { return ItemSyncOutcome.Failed(it.localizedMessage ?: "Check-in sync failed") }

        val ackSnap = withTimeout(6000L) { docRef.get(Source.SERVER).await() }
        return if (ackSnap.exists() && ackSnap.getString("clientSubmissionId") == item.clientSubmissionId) {
            ItemSyncOutcome.Synced(docRef.id)
        } else {
            ItemSyncOutcome.Failed("Server receipt verification could not confirm check-in ${docRef.id}")
        }
    }

    private suspend fun syncStatusUpdateItem(
        actor: UserAccount,
        item: OfflineQueueEntity,
        json: JSONObject,
        pollingUnitsById: Map<String, PollingUnit>
    ): ItemSyncOutcome {
        val puId = json.getString("puId")
        val newStatus = PuOperationalStatus.fromString(json.getString("newStatus"))
        val puRef = db.collection("polling_units").document(puId)
        val serverSnap = withTimeout(6000L) { puRef.get(Source.SERVER).await() }
        val serverPu = serverSnap.toObject(PollingUnit::class.java)
            ?: pollingUnitsById[puId]
            ?: return ItemSyncOutcome.Failed("Polling unit $puId not found on server")

        if (serverPu.statusEnum == newStatus) {
            return ItemSyncOutcome.Synced(puId)
        }

        val serverUpdatedMs = serverPu.updatedAt?.toDate()?.time ?: 0L
        val isEmergencyOverride = newStatus == PuOperationalStatus.INCIDENT_REPORTED ||
            newStatus == PuOperationalStatus.COMMUNICATION_LOST
        if (serverPu.statusEnum == PuOperationalStatus.RESULT_VERIFIED && !isEmergencyOverride) {
            return ItemSyncOutcome.Conflict(
                "Conflict: Server Polling Unit ${serverPu.puCode} is already RESULT_VERIFIED; local status ${newStatus.label} was held for review."
            )
        }
        if (serverUpdatedMs > item.updatedAtMillis && serverPu.statusEnum.stepOrder > newStatus.stepOrder && !isEmergencyOverride) {
            return ItemSyncOutcome.Conflict(
                "Conflict: Server holds newer status (${serverPu.statusEnum.label}) for ${serverPu.puCode}; local update (${newStatus.label}) not overwritten."
            )
        }

        val res = opsRepo.updatePollingUnitStatus(actor, serverPu, newStatus)
        res.exceptionOrNull()?.let { return ItemSyncOutcome.Failed(it.localizedMessage ?: "Status sync failed") }

        val ackSnap = withTimeout(6000L) { puRef.get(Source.SERVER).await() }
        val ackStatus = ackSnap.getString("operationalStatus")
        return if (ackStatus == newStatus.name) {
            ItemSyncOutcome.Synced(puId)
        } else {
            ItemSyncOutcome.Failed("Server verification saw status $ackStatus instead of ${newStatus.name}")
        }
    }

    private suspend fun syncIncidentItem(
        actor: UserAccount,
        item: OfflineQueueEntity,
        json: JSONObject,
        pollingUnitsById: Map<String, PollingUnit>
    ): ItemSyncOutcome {
        val incRef = db.collection("incidents").document(item.clientSubmissionId)
        val existingServer = runCatching {
            withTimeout(6000L) { incRef.get(Source.SERVER).await() }
        }.getOrElse { err ->
            if (err is CancellationException && err !is TimeoutCancellationException) throw err
            null
        }
        if (existingServer != null && existingServer.exists() && existingServer.getString("clientSubmissionId") == item.clientSubmissionId) {
            return ItemSyncOutcome.Synced(incRef.id)
        }

        val puId = json.optString("puId", "")
        val pu = if (puId.isNotBlank()) pollingUnitsById[puId] else null

        val attachments = dao.getAttachmentsForReport(item.clientSubmissionId, actor.uid)
        val primaryAtt = attachments.firstOrNull()
        val inlineBase64 = json.optString("evidenceBase64").takeIf { it.isNotBlank() }
            ?: primaryAtt?.let { ImageCompression.readBase64FromLocalPath(it.localFilePath) }
        val inlineName = json.optString("evidenceFileName").takeIf { it.isNotBlank() }
            ?: primaryAtt?.fileName

        val res = opsRepo.submitIncident(
            actor = actor,
            pu = pu,
            lgaId = json.getString("lgaId"),
            wardId = json.optString("wardId", ""),
            title = json.getString("title"),
            category = json.getString("category"),
            description = json.getString("description"),
            urgency = IncidentUrgency.fromString(json.getString("urgency")),
            evidenceBase64 = inlineBase64,
            evidenceFileName = inlineName,
            clientSubmissionId = item.clientSubmissionId
        )
        res.exceptionOrNull()?.let { return ItemSyncOutcome.Failed(it.localizedMessage ?: "Incident sync failed") }

        val ackSnap = withTimeout(6000L) { incRef.get(Source.SERVER).await() }
        return if (ackSnap.exists() && ackSnap.getString("clientSubmissionId") == item.clientSubmissionId) {
            ItemSyncOutcome.Synced(incRef.id)
        } else {
            ItemSyncOutcome.Failed("Server acknowledgement not confirmed for incident ${incRef.id}")
        }
    }

    private suspend fun syncResultItem(
        actor: UserAccount,
        item: OfflineQueueEntity,
        json: JSONObject,
        pollingUnitsById: Map<String, PollingUnit>,
        resultsById: Map<String, ResultSubmission>
    ): ItemSyncOutcome {
        val puId = json.getString("puId")
        val existingDocId = json.optString("existingSubmissionId", "").takeIf { it.isNotBlank() }
        val targetDocId = existingDocId ?: item.clientSubmissionId
        val docRef = db.collection("result_submissions").document(targetDocId)

        val serverPuSnap = runCatching {
            withTimeout(5000L) { db.collection("polling_units").document(puId).get(Source.SERVER).await() }
        }.getOrNull()
        val pu = serverPuSnap?.toObject(PollingUnit::class.java)
            ?: pollingUnitsById[puId]
            ?: PollingUnit(
                id = puId,
                lgaId = json.getString("lgaId"),
                wardId = json.optString("wardId", ""),
                wardName = json.optString("wardName", ""),
                puCode = json.optString("puCode", item.puCode),
                name = json.optString("puName", item.puName),
                isTestData = json.optBoolean("isTestData", false)
            )

        val serverResultSnap = runCatching {
            withTimeout(6000L) { docRef.get(Source.SERVER).await() }
        }.getOrElse { err ->
            if (err is CancellationException && err !is TimeoutCancellationException) throw err
            null
        }
        val serverExisting = if (serverResultSnap != null && serverResultSnap.exists()) {
            serverResultSnap.toObject(ResultSubmission::class.java)?.copy(id = serverResultSnap.id)
        } else {
            null
        }

        if (serverExisting != null) {
            val statusEnum = serverExisting.verificationEnum
            val sameClientSubmission = serverExisting.clientSubmissionId == item.clientSubmissionId
            val expectedMinVersion = json.optLong("expectedVersion", 1L)

            if (existingDocId == null && sameClientSubmission) {
                // Idempotent repeat of exact offline submission
                return ItemSyncOutcome.Synced(docRef.id)
            }
            if (statusEnum == VerificationStatus.VERIFIED) {
                return ItemSyncOutcome.Conflict(
                    "Conflict: Result for ${pu.puCode} is already VERIFIED on server; offline copy held without overwriting."
                )
            }
            if (statusEnum == VerificationStatus.UNDER_REVIEW && existingDocId == null) {
                return ItemSyncOutcome.Conflict(
                    "Conflict: Result for ${pu.puCode} is UNDER_REVIEW on server; offline submission held for authorized review."
                )
            }
            if (existingDocId != null &&
                statusEnum != VerificationStatus.DRAFT &&
                statusEnum != VerificationStatus.REQUIRES_CORRECTION
            ) {
                return ItemSyncOutcome.Conflict(
                    "Conflict: Server status changed to ${statusEnum.label}; revision cannot overwrite locked result."
                )
            }
            val serverUpdatedMs = serverExisting.updatedAt?.toDate()?.time ?: 0L
            if (serverUpdatedMs > item.updatedAtMillis && serverExisting.version >= expectedMinVersion) {
                return ItemSyncOutcome.Conflict(
                    "Conflict: Newer server version (v${serverExisting.version}) exists for ${pu.puCode}."
                )
            }
        } else {
            // Check cached/observed PU results or PU operational status for newer verified server record
            val conflictingVerified = resultsById.values.firstOrNull {
                it.puId == puId && it.verificationEnum == VerificationStatus.VERIFIED
            }
            if (conflictingVerified != null || pu.statusEnum == PuOperationalStatus.RESULT_VERIFIED) {
                return ItemSyncOutcome.Conflict(
                    "Conflict: Polling Unit ${pu.puCode} already has a VERIFIED result on the server."
                )
            }
        }

        val attachments = dao.getAttachmentsForReport(item.clientSubmissionId, actor.uid)
        val primaryAtt = attachments.firstOrNull()
        val inlineBase64 = json.optString("ec8aImageBase64").takeIf { it.isNotBlank() }
            ?: primaryAtt?.let { ImageCompression.readBase64FromLocalPath(it.localFilePath) }
        val inlineName = json.optString("ec8aFileName").takeIf { it.isNotBlank() }
            ?: primaryAtt?.fileName

        val res = opsRepo.submitPollingUnitResult(
            actor = actor,
            pu = pu,
            registeredVoters = json.getLong("registeredVoters"),
            accreditedVoters = json.getLong("accreditedVoters"),
            validVotes = json.getLong("validVotes"),
            rejectedVotes = json.getLong("rejectedVotes"),
            bvasStatus = json.getString("bvasStatus"),
            bvasNotes = json.optString("bvasNotes", ""),
            submissionNotes = json.optString("submissionNotes", ""),
            ec8aImageBase64 = inlineBase64,
            ec8aFileName = inlineName,
            existingSubmission = serverExisting,
            clientSubmissionId = targetDocId
        )
        res.exceptionOrNull()?.let { return ItemSyncOutcome.Failed(it.localizedMessage ?: "Result sync failed") }

        val ackSnap = withTimeout(6000L) { docRef.get(Source.SERVER).await() }
        return if (ackSnap.exists()) {
            ItemSyncOutcome.Synced(docRef.id)
        } else {
            ItemSyncOutcome.Failed("Server receipt verification failed for result ${docRef.id}")
        }
    }

    internal suspend fun uploadAndVerifyAttachment(
        actor: UserAccount,
        att: OfflineAttachmentEntity
    ): Result<Unit> = runCatching {
        val attRef = db.collection("report_attachments").document(att.attachmentId)
        val existingServer = runCatching {
            withTimeout(5000L) { attRef.get(Source.SERVER).await() }
        }.getOrElse { err ->
            if (err is CancellationException && err !is TimeoutCancellationException) throw err
            null
        }
        if (existingServer != null && existingServer.exists() && existingServer.getString("sha256Hash") == att.sha256Hash) {
            return@runCatching
        }

        val file = File(att.localFilePath)
        require(file.exists() && file.isFile) { "Local attachment file missing on device (${att.fileName})" }
        val base64 = ImageCompression.readBase64FromLocalPath(att.localFilePath)
            ?: error("Unable to encode attachment ${att.fileName}")

        val payload = mapOf(
            "attachmentId" to att.attachmentId,
            "reportId" to att.reportId,
            "reportType" to att.reportType,
            "ownerUid" to actor.uid,
            "lgaId" to att.lgaId,
            "wardId" to att.wardId,
            "puId" to att.puId,
            "fileName" to att.fileName.take(110),
            "sha256Hash" to att.sha256Hash,
            "sizeBytes" to att.sizeBytes.coerceAtLeast(1).toLong(),
            "base64Data" to base64,
            "createdAt" to FieldValue.serverTimestamp()
        )
        withTimeout(10_000L) { attRef.set(payload).await() }

        val ackSnap = withTimeout(6000L) { attRef.get(Source.SERVER).await() }
        check(ackSnap.exists() && ackSnap.getString("sha256Hash") == att.sha256Hash) {
            "Server attachment checksum verification failed"
        }
    }

    companion object {
        fun exponentialBackoffMs(retryCount: Int): Long {
            val shift = retryCount.coerceIn(0, 6)
            return minOf(15_000L * (1L shl shift), 900_000L)
        }
    }

    private sealed class ItemSyncOutcome {
        data class Synced(val serverDocId: String) : ItemSyncOutcome()
        data class Conflict(val reason: String) : ItemSyncOutcome()
        data class Failed(val error: String) : ItemSyncOutcome()
    }
}
