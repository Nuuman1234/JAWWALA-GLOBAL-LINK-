package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.firebase.OfflineAttachmentDraft
import com.example.data.local.OfflineItemType
import com.example.data.local.OfflineSyncStatus
import com.example.data.model.IncidentCategory
import com.example.data.model.IncidentReport
import com.example.data.model.IncidentStatus
import com.example.data.model.IncidentUrgency
import com.example.data.model.LgaDefinition
import com.example.data.model.PollingUnit
import com.example.data.model.UserAccount
import com.example.ui.components.Base64EvidencePreview
import com.example.ui.components.CameraAndPickerEvidenceSection
import com.example.ui.components.CompactSyncBanner
import com.example.ui.components.EmptyOperationalState
import com.example.ui.components.SearchablePollingUnitField
import com.example.ui.components.TestDataTag
import com.example.ui.components.UrgencyBadge
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.AlertCritical
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.WhiteBackground
import com.example.ui.viewmodel.OfflineReportEditRequest
import com.example.ui.viewmodel.SyncDashboardMetrics
import com.example.util.DeviceTelemetry
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IncidentsScreen(
    user: UserAccount,
    pollingUnits: List<PollingUnit>,
    incidents: List<IncidentReport>,
    syncMetrics: SyncDashboardMetrics,
    editRequest: OfflineReportEditRequest?,
    onConsumeEditRequest: () -> Unit,
    onSyncNow: () -> Unit,
    onAutoSaveIncidentDraft: (String, PollingUnit?, String, String, String, String, String, IncidentUrgency, OfflineAttachmentDraft?) -> Unit,
    onSubmitIncident: (PollingUnit?, String, String, String, String, String, IncidentUrgency, String?, String?, Boolean, OfflineAttachmentDraft?, String?) -> Unit,
    onUpdateIncident: (IncidentReport, IncidentStatus, String, String) -> Unit
) {
    val context = LocalContext.current
    var subTab by remember { mutableIntStateOf(0) }
    var reviewTarget by remember { mutableStateOf<IncidentReport?>(null) }

    LaunchedEffect(editRequest) {
        if (editRequest?.itemType == OfflineItemType.INCIDENT_REPORT) {
            subTab = 1
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        SecondaryTabRow(
            selectedTabIndex = subTab,
            containerColor = WhiteBackground
        ) {
            Tab(selected = subTab == 0, onClick = { subTab = 0 }, text = { Text("Alerts Feed (${incidents.size})") })
            Tab(selected = subTab == 1, onClick = { subTab = 1 }, text = { Text("Report Incident") })
        }

        if (subTab == 0) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    CompactSyncBanner(
                        metrics = syncMetrics,
                        onSyncNow = onSyncNow
                    )
                }
                if (incidents.isEmpty()) {
                    item {
                        EmptyOperationalState(
                            title = "No incident reports submitted yet.",
                            description = "All reported incidents across authorized polling units and wards appear here. Offline drafts & queued reports remain preserved locally until server verified.",
                            icon = Icons.Filled.ReportProblem,
                            actionLabel = "Report Incident",
                            onAction = { subTab = 1 }
                        )
                    }
                } else {
                    items(incidents, key = { it.id }) { inc ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = user.roleEnum.canReviewIncidents()) { reviewTarget = inc },
                            colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                            border = BorderStroke(
                                1.dp,
                                if (inc.urgency == IncidentUrgency.CRITICAL.name) AlertCritical else BorderLight
                            )
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("${inc.puCode} · ${inc.lgaId.uppercase()}", style = MonoCodeStyle, color = EmeraldPrimary)
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        if (inc.isTestData) TestDataTag()
                                        UrgencyBadge(inc.urgencyEnum)
                                    }
                                }
                                Text(inc.title, style = MaterialTheme.typography.titleMedium, color = TextPrimaryLight)
                                Text(inc.category, style = MaterialTheme.typography.labelMedium, color = TextSecondaryLight)
                                Text(inc.description, style = MaterialTheme.typography.bodyMedium, color = TextPrimaryLight)
                                Base64EvidencePreview(inc.evidenceBase64, inc.evidenceFileName ?: "Incident Evidence")
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Status: ${inc.statusEnum.label}", style = MonoCodeStyle, color = EmeraldPrimary)
                                    Text("${inc.reporterName} · ${formatTimestamp(inc.createdAt)}", style = MonoCodeStyle, color = TextSecondaryLight)
                                }
                                if (inc.internalNotes.isNotBlank()) {
                                    Text("Review Note: ${inc.internalNotes}", style = MaterialTheme.typography.bodySmall, color = TextSecondaryLight)
                                }
                                if (user.roleEnum.canReviewIncidents()) {
                                    TextButton(onClick = { reviewTarget = inc }) {
                                        Text("Review / Escalate / Resolve")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            var draftReportId by remember {
                mutableStateOf("inc_${user.uid.take(6)}_${UUID.randomUUID().toString().take(8)}")
            }
            var editingExistingId by remember { mutableStateOf<String?>(null) }
            var selectedPu by remember(pollingUnits) {
                mutableStateOf(pollingUnits.firstOrNull { it.id == user.assignedPollingUnitId } ?: pollingUnits.firstOrNull())
            }
            var selectedCategory by remember { mutableStateOf(IncidentCategory.LATE_MATERIALS) }
            var catExpanded by remember { mutableStateOf(false) }
            var urgency by remember { mutableStateOf(IncidentUrgency.MEDIUM) }
            var title by remember { mutableStateOf("") }
            var description by remember { mutableStateOf("") }
            var attachmentDraft by remember { mutableStateOf<OfflineAttachmentDraft?>(null) }
            var attachmentBase64 by remember { mutableStateOf<String?>(null) }
            var attachmentStatus by remember { mutableStateOf<OfflineSyncStatus?>(null) }

            LaunchedEffect(editRequest) {
                val req = editRequest ?: return@LaunchedEffect
                if (req.itemType == OfflineItemType.INCIDENT_REPORT) {
                    runCatching {
                        val obj = JSONObject(req.payloadJson)
                        val puId = obj.optString("puId")
                        selectedPu = if (puId.isNotBlank()) pollingUnits.firstOrNull { it.id == puId } else null
                        val catLabel = obj.optString("category")
                        selectedCategory = IncidentCategory.entries.find { it.label == catLabel } ?: IncidentCategory.LATE_MATERIALS
                        urgency = IncidentUrgency.fromString(obj.optString("urgency", IncidentUrgency.MEDIUM.name))
                        title = obj.optString("title", "")
                        description = obj.optString("description", "")
                        val att = req.attachments.firstOrNull()
                        if (att != null) {
                            attachmentDraft = OfflineAttachmentDraft(
                                attachmentId = att.attachmentId,
                                fileName = att.fileName,
                                localFilePath = att.localFilePath,
                                sha256Hash = att.sha256Hash,
                                sizeBytes = att.sizeBytes
                            )
                            attachmentStatus = OfflineSyncStatus.fromString(att.uploadStatus)
                        }
                        draftReportId = req.reportId
                        editingExistingId = req.reportId
                    }
                    onConsumeEditRequest()
                }
            }

            // Auto-save incident draft locally as fields change
            LaunchedEffect(selectedPu, selectedCategory, urgency, title, description, attachmentDraft) {
                delay(350L)
                if (title.isNotBlank() || description.isNotBlank() || attachmentDraft != null) {
                    val fallbackLga = user.assignedLgaId.ifBlank { LgaDefinition.FUNTUA.id }
                    onAutoSaveIncidentDraft(
                        draftReportId,
                        selectedPu,
                        selectedPu?.lgaId ?: fallbackLga,
                        selectedPu?.wardId ?: user.assignedWardId,
                        title,
                        selectedCategory.label,
                        description,
                        urgency,
                        attachmentDraft
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    CompactSyncBanner(
                        metrics = syncMetrics,
                        onSyncNow = onSyncNow
                    )
                }
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (editingExistingId != null) "Edit Offline Incident Report" else "Submit Structured Incident Report",
                            style = MaterialTheme.typography.titleMedium,
                            color = EmeraldDeep
                        )
                        Text(draftReportId.take(14), style = MonoCodeStyle, color = TextSecondaryLight)
                    }
                }
                if (pollingUnits.isNotEmpty()) {
                    item {
                        SearchablePollingUnitField(
                            label = "Affected Polling Unit (Searchable Directory)",
                            pollingUnits = pollingUnits,
                            selectedPu = selectedPu,
                            onSelectPu = { selectedPu = it },
                            allowNullWardLevelOption = true,
                            testTag = "incident_pu_selector"
                        )
                    }
                }
                item {
                    ExposedDropdownMenuBox(expanded = catExpanded, onExpandedChange = { catExpanded = it }) {
                        OutlinedTextField(
                            value = selectedCategory.label,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Incident Category") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = catExpanded) },
                            modifier = Modifier
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable, true)
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = catExpanded, onDismissRequest = { catExpanded = false }) {
                            IncidentCategory.entries.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat.label) },
                                    onClick = {
                                        selectedCategory = cat
                                        catExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
                item {
                    Text("Urgency Level", style = MaterialTheme.typography.labelLarge, color = TextPrimaryLight)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IncidentUrgency.entries.forEach { lvl ->
                            FilterChip(
                                selected = urgency == lvl,
                                onClick = { urgency = lvl },
                                label = { Text(lvl.label) }
                            )
                        }
                    }
                }
                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Incident Title (Auto-Saved)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("incident_title_input")
                    )
                }
                item {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Detailed Field Observation (Auto-Saved)") },
                        minLines = 3,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("incident_desc_input")
                    )
                }
                item {
                    CameraAndPickerEvidenceSection(
                        ownerUid = user.uid,
                        label = "Authorized Incident Photo (Saved Locally Offline-First)",
                        attachedFileName = attachmentDraft?.fileName,
                        attachedLocalPath = attachmentDraft?.localFilePath,
                        attachedBase64 = attachmentBase64,
                        attachmentUploadStatus = attachmentStatus ?: attachmentDraft?.let { OfflineSyncStatus.SAVED_LOCALLY },
                        onAttachmentCaptured = { draft, b64 ->
                            attachmentDraft = draft
                            attachmentBase64 = b64
                            attachmentStatus = OfflineSyncStatus.SAVED_LOCALLY
                        },
                        onRemoveAttachment = {
                            attachmentDraft = null
                            attachmentBase64 = null
                            attachmentStatus = null
                        },
                        testTagPrefix = "incident_evidence"
                    )
                }
                item {
                    val fallbackLga = user.assignedLgaId.ifBlank { LgaDefinition.FUNTUA.id }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = {
                                onAutoSaveIncidentDraft(
                                    draftReportId,
                                    selectedPu,
                                    selectedPu?.lgaId ?: fallbackLga,
                                    selectedPu?.wardId ?: user.assignedWardId,
                                    title,
                                    selectedCategory.label,
                                    description,
                                    urgency,
                                    attachmentDraft
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("save_incident_draft_btn")
                        ) {
                            Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.size(4.dp))
                            Text("Save Draft")
                        }
                        Button(
                            onClick = {
                                val snap = DeviceTelemetry.readSnapshot(context, false)
                                onSubmitIncident(
                                    selectedPu,
                                    selectedPu?.lgaId ?: fallbackLga,
                                    selectedPu?.wardId ?: user.assignedWardId,
                                    title,
                                    selectedCategory.label,
                                    description,
                                    urgency,
                                    attachmentBase64,
                                    attachmentDraft?.fileName,
                                    snap.isOnline,
                                    attachmentDraft,
                                    draftReportId
                                )
                                title = ""
                                description = ""
                                attachmentDraft = null
                                attachmentBase64 = null
                                attachmentStatus = null
                                editingExistingId = null
                                draftReportId = "inc_${user.uid.take(6)}_${UUID.randomUUID().toString().take(8)}"
                                subTab = 0
                            },
                            enabled = title.trim().length >= 3 && description.trim().length >= 5,
                            modifier = Modifier
                                .weight(1.5f)
                                .testTag("submit_incident_button")
                        ) {
                            Text(if (syncMetrics.isOnline) "Submit Incident" else "Queue Incident Offline")
                        }
                    }
                }
            }
        }
    }

    reviewTarget?.let { target ->
        ReviewIncidentDialog(
            incident = target,
            onDismiss = { reviewTarget = null },
            onSave = { status, notes, escalated ->
                onUpdateIncident(target, status, notes, escalated)
                reviewTarget = null
            }
        )
    }
}

@Composable
private fun ReviewIncidentDialog(
    incident: IncidentReport,
    onDismiss: () -> Unit,
    onSave: (IncidentStatus, String, String) -> Unit
) {
    var status by remember { mutableStateOf(incident.statusEnum) }
    var notes by remember { mutableStateOf(incident.internalNotes) }
    var escalatedTo by remember { mutableStateOf(incident.escalatedTo) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = WhiteBackground,
        title = { Text("Manage Incident Workflow", color = EmeraldDeep) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(incident.title, style = MaterialTheme.typography.titleSmall, color = TextPrimaryLight)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    IncidentStatus.entries.chunked(3).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            row.forEach { st ->
                                FilterChip(
                                    selected = status == st,
                                    onClick = { status = st },
                                    label = { Text(st.label, maxLines = 1) }
                                )
                            }
                        }
                    }
                }
                OutlinedTextField(
                    value = escalatedTo,
                    onValueChange = { escalatedTo = it },
                    label = { Text("Escalated To (e.g. Security / INEC EO)") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Internal Situation Room Notes") },
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(onClick = { onSave(status, notes, escalatedTo) }) {
                Text("Update Incident")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
