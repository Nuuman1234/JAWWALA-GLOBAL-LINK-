package com.example.data.repository

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.base.FirestoreEmulatorTestBase
import com.example.data.firebase.AuthRepository
import com.example.data.firebase.DirectoryRepository
import com.example.data.firebase.OfflineAttachmentDraft
import com.example.data.firebase.OfflineSyncEngine
import com.example.data.firebase.OperationsRepository
import com.example.data.local.CachedUserProfileEntity
import com.example.data.local.FdmisDatabase
import com.example.data.local.OfficialDirectoryCatalog
import com.example.data.local.OfflineItemType
import com.example.data.local.OfflineSyncStatus
import com.example.data.model.BvasStatus
import com.example.data.model.IncidentUrgency
import com.example.data.model.PollingUnit
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.model.VerificationStatus
import com.example.util.ImageCompression
import com.google.firebase.firestore.Source
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.util.UUID

class OfflineFirstSyncRuleTest : FirestoreEmulatorTestBase() {

    private suspend fun ensureAdminAndMasterPu(targetPuDocId: String = "pu_20-14-01-001"): Pair<UserAccount, PollingUnit> {
        val adminUid = signInTestUser("chief_admin@fdmis.test")
        val authRepo = AuthRepository(firestore, auth)
        val snap = withTimeout(TIMEOUT_MS) {
            firestore.collection("users").document(adminUid).get().await()
        }
        val admin = if (snap.exists()) {
            checkNotNull(snap.toObject(UserAccount::class.java))
        } else {
            val lock = withTimeout(TIMEOUT_MS) { authRepo.getBootstrapLock().getOrThrow() }
            if (lock == null) {
                withTimeout(TIMEOUT_MS) {
                    authRepo.initializeFullControlAdmin("Chief Situation Admin", "08000000000").getOrThrow()
                }
            } else {
                checkNotNull(
                    withTimeout(TIMEOUT_MS) { authRepo.ensureUserProfileOrCheckBootstrap("Staff Admin").getOrThrow() }
                )
            }
        }

        val dirRepo = DirectoryRepository(firestore, auth)
        val existingPuSnap = withTimeout(TIMEOUT_MS) {
            firestore.collection("polling_units").document(targetPuDocId).get().await()
        }
        if (!existingPuSnap.exists()) {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val dataset = OfficialDirectoryCatalog.loadFromContext(context)
            withTimeout(IMPORT_TIMEOUT_MS) {
                dirRepo.importPreloadedOfficialDirectory(admin, dataset).getOrThrow()
            }
        }
        val pu = withTimeout(TIMEOUT_MS) {
            firestore.collection("polling_units").document(targetPuDocId).get().await()
                .toObject(PollingUnit::class.java)!!
        }
        return admin to pu
    }

    @Test
    fun offlineFirst_fullLifecycle_persistenceSyncVerificationConflictAndIsolation() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dbName = "test_offline_${UUID.randomUUID().toString().take(8)}.db"
        var roomDb = Room.databaseBuilder(context, FdmisDatabase::class.java, dbName)
            .allowMainThreadQueries()
            .build()

        try {
            val (admin, pu) = ensureAdminAndMasterPu("pu_20-14-01-001")
            val suffix = UUID.randomUUID().toString().take(6)

            // Provision an active agent scoped to Funtua PU
            val agentEmail = "offline_agent_$suffix@fdmis.test"
            signInTestUser(agentEmail)
            val pendingAgent = withTimeout(TIMEOUT_MS) {
                AuthRepository(firestore, auth).ensureUserProfileOrCheckBootstrap("Offline Field Agent").getOrThrow()!!
            }
            ensureAdminAndMasterPu("pu_20-14-01-001")
            DirectoryRepository(firestore, auth).assignAgentToPollingUnit(admin, pu, pendingAgent).getOrThrow()

            // Sign in as active agent and verify online profile gets cached in Room
            signInTestUser(agentEmail)
            val agentAuthRepo = AuthRepository(firestore, auth, roomDb.offlineQueueDao())
            val activeAgent = withTimeout(TIMEOUT_MS) {
                agentAuthRepo.ensureUserProfileOrCheckBootstrap().getOrThrow()!!
            }
            assertEquals(UserRole.POLLING_UNIT_AGENT.name, activeAgent.role)
            assertNotNull(roomDb.offlineQueueDao().getCachedUser(activeAgent.uid))

            val opsRepo = OperationsRepository(firestore, roomDb.offlineQueueDao(), auth)

            // --- SCENARIO A: Simulate Complete Network Outage ---
            withTimeout(TIMEOUT_MS) { firestore.disableNetwork().await() }

            // Cold-start/offline check-profile MUST still succeed using Room cached profile without forcing logout
            val offlineAccountCheck = agentAuthRepo.ensureUserProfileOrCheckBootstrap().getOrThrow()
            assertNotNull(offlineAccountCheck)
            assertEquals(activeAgent.uid, offlineAccountCheck!!.uid)
            assertFalse(opsRepo.verifyBackendReachable())

            // Create and edit an offline draft + attach photo saved privately to app storage
            val dummyJpegBytes = ByteArray(1024) { (it % 251).toByte() }
            val persistedEvidence = ImageCompression.persistRawBytesForTestOrAttachment(
                context = context,
                ownerUid = activeAgent.uid,
                jpegBytes = dummyJpegBytes,
                fileName = "ec8a_evidence.jpg"
            )
            val draftAtt = OfflineAttachmentDraft(
                fileName = persistedEvidence.fileName,
                localFilePath = persistedEvidence.localFilePath,
                sha256Hash = persistedEvidence.sha256Hash,
                sizeBytes = persistedEvidence.sizeBytes
            )
            assertTrue(File(persistedEvidence.localFilePath).exists())

            val draftId = "inc_off_$suffix"
            opsRepo.saveOfflineDraft(
                actor = activeAgent,
                reportId = draftId,
                itemType = OfflineItemType.INCIDENT_REPORT,
                lgaId = pu.lgaId,
                wardId = pu.wardId,
                pu = pu,
                title = "Initial Draft Title",
                subtitle = pu.puCode,
                payloadJson = JSONObject().apply {
                    put("title", "Initial Draft Title")
                    put("description", "Initial observation")
                    put("category", "Late arrival of election materials")
                    put("urgency", IncidentUrgency.HIGH.name)
                    put("lgaId", pu.lgaId)
                    put("wardId", pu.wardId)
                    put("puId", pu.id)
                },
                attachmentDraft = draftAtt
            )
            val savedDraft = roomDb.offlineQueueDao().getByIdForUser(draftId, activeAgent.uid)
            assertEquals(OfflineSyncStatus.SAVED_LOCALLY.name, savedDraft?.syncStatus)

            // Submit Check-In, Incident (same draftId upgraded -> PENDING_SYNC), and Result while OFFLINE
            // Requirement B/E: Pressing Submit MUST NOT delete report from local storage!
            val checkInId = opsRepo.enqueueCheckInOfflineFirst(
                actor = activeAgent,
                pu = pu,
                arrivalTimeText = "08:05 AM",
                comments = "Polling unit open offline test",
                batteryPercent = 91,
                networkStatus = "Offline Mode",
                latitude = 11.52,
                longitude = 7.31,
                reportId = "ci_off_$suffix"
            )
            opsRepo.enqueueIncidentOfflineFirst(
                actor = activeAgent,
                pu = pu,
                lgaId = pu.lgaId,
                wardId = pu.wardId,
                title = "Delayed BVAS charger",
                category = "BVAS malfunction or technical problem",
                description = "Power bank deployed cleanly during outage",
                urgency = IncidentUrgency.HIGH,
                attachmentDraft = draftAtt,
                reportId = draftId
            )
            val resultReportId = opsRepo.enqueueResultOfflineFirst(
                actor = activeAgent,
                pu = pu,
                registeredVoters = 500L,
                accreditedVoters = 320L,
                validVotes = 310L,
                rejectedVotes = 10L,
                bvasStatus = BvasStatus.FUNCTIONAL.label,
                bvasNotes = "Offline BVAS note",
                submissionNotes = "Signed Form EC8A offline",
                attachmentDraft = draftAtt,
                reportId = "res_off_$suffix"
            )

            // Attempting sync while backend unreachable MUST leave reports intact as PENDING_SYNC
            val offlineSyncSummary = opsRepo.syncPendingOfflineQueueDetailed(
                actor = activeAgent,
                pollingUnitsById = mapOf(pu.id to pu)
            )
            assertFalse(offlineSyncSummary.backendReachable)
            assertEquals(0, offlineSyncSummary.syncedCount)

            // --- SCENARIO B: App Close & Reopen Simulation (Database Restart Persistence) ---
            roomDb.close()
            roomDb = Room.databaseBuilder(context, FdmisDatabase::class.java, dbName)
                .allowMainThreadQueries()
                .build()

            val reopenedDao = roomDb.offlineQueueDao()
            val persistedList = reopenedDao.observeForUser(activeAgent.uid).first()
            assertEquals(3, persistedList.size)
            assertTrue(persistedList.all { it.syncStatus == OfflineSyncStatus.PENDING_SYNC.name })
            assertTrue(reopenedDao.getPendingAttachmentsForUser(activeAgent.uid).isNotEmpty())

            // User isolation check: Another user must NOT see activeAgent's private offline reports/attachments
            assertTrue(reopenedDao.observeForUser("other_user_uid").first().isEmpty())
            assertTrue(reopenedDao.getPendingAttachmentsForUser("other_user_uid").isEmpty())

            // --- SCENARIO C: Network Returns -> Automatic Sync + Server Verification + Retention ---
            withTimeout(TIMEOUT_MS) { firestore.enableNetwork().await() }
            val opsAfterRestart = OperationsRepository(firestore, reopenedDao, auth)
            assertTrue(opsAfterRestart.verifyBackendReachable())

            val onlineSyncSummary = opsAfterRestart.syncPendingOfflineQueueDetailed(
                actor = activeAgent,
                pollingUnitsById = mapOf(pu.id to pu),
                forceRetryIgnoredBackoff = true
            )
            assertTrue(onlineSyncSummary.backendReachable)
            assertEquals(3, onlineSyncSummary.syncedCount)
            assertEquals(0, onlineSyncSummary.failedCount)
            assertEquals(0, onlineSyncSummary.attachmentRetryPendingCount)

            // Verify Firestore Source.SERVER documents actually landed with matching IDs and SHA-256 attachment
            val ciSnap = withTimeout(TIMEOUT_MS) {
                firestore.collection("check_ins").document(checkInId).get(Source.SERVER).await()
            }
            assertTrue(ciSnap.exists())
            assertEquals(checkInId, ciSnap.getString("clientSubmissionId"))

            val incSnap = withTimeout(TIMEOUT_MS) {
                firestore.collection("incidents").document(draftId).get(Source.SERVER).await()
            }
            assertTrue(incSnap.exists())

            val resSnap = withTimeout(TIMEOUT_MS) {
                firestore.collection("result_submissions").document(resultReportId).get(Source.SERVER).await()
            }
            assertTrue(resSnap.exists())
            assertEquals(310L, resSnap.getLong("validVotes"))

            val attSnap = withTimeout(TIMEOUT_MS) {
                firestore.collection("report_attachments").document(draftAtt.attachmentId).get(Source.SERVER).await()
            }
            assertTrue(attSnap.exists())
            assertEquals(draftAtt.sha256Hash, attSnap.getString("sha256Hash"))

            // Verify Room RETAINED all synced items in local history with serverVerifiedAck = true
            val postSyncLocal = reopenedDao.observeForUser(activeAgent.uid).first()
            assertEquals(3, postSyncLocal.size)
            assertTrue(postSyncLocal.all {
                it.syncStatus == OfflineSyncStatus.SYNCED.name && it.serverVerifiedAck
            })

            // Archiving confirmed queue entries preserves submission history permanently
            opsAfterRestart.archiveConfirmedQueueEntries(activeAgent.uid)
            val afterArchive = reopenedDao.observeForUser(activeAgent.uid).first()
            assertEquals(3, afterArchive.size)
            assertTrue(afterArchive.all { it.archivedFromQueue })

            // --- SCENARIO D: Exponential Backoff Formula + Attachment Failure Doesn't Discard Report ---
            assertEquals(30_000L, OfflineSyncEngine.exponentialBackoffMs(1))
            assertEquals(60_000L, OfflineSyncEngine.exponentialBackoffMs(2))
            assertEquals(900_000L, OfflineSyncEngine.exponentialBackoffMs(10))

            // Simulate attachment pointing to temporarily missing file; parent report still syncs safely!
            val brokenAttId = "att_broken_$suffix"
            val reportWithBrokenAtt = opsAfterRestart.enqueueIncidentOfflineFirst(
                actor = activeAgent,
                pu = pu,
                lgaId = pu.lgaId,
                wardId = pu.wardId,
                title = "Report whose photo fails upload",
                category = "BVAS malfunction or technical problem",
                description = "Ensure report itself is preserved and never discarded",
                urgency = IncidentUrgency.LOW,
                attachmentDraft = OfflineAttachmentDraft(
                    attachmentId = brokenAttId,
                    fileName = "missing_tmp.jpg",
                    localFilePath = File(context.filesDir, "non_existent_$suffix.jpg").absolutePath,
                    sha256Hash = persistedEvidence.sha256Hash,
                    sizeBytes = persistedEvidence.sizeBytes
                ),
                reportId = "inc_partial_$suffix"
            )
            val partialSync = opsAfterRestart.syncPendingOfflineQueueDetailed(
                actor = activeAgent,
                pollingUnitsById = mapOf(pu.id to pu),
                forceRetryIgnoredBackoff = true
            )
            assertEquals(1, partialSync.syncedCount)
            assertEquals(1, partialSync.attachmentRetryPendingCount)
            val savedPartialReport = reopenedDao.getByIdForUser(reportWithBrokenAtt, activeAgent.uid)
            assertEquals(OfflineSyncStatus.SYNCED.name, savedPartialReport?.syncStatus)
            val failedAttRow = reopenedDao.getAttachmentsForReport(reportWithBrokenAtt, activeAgent.uid).first()
            assertEquals(OfflineSyncStatus.SYNC_FAILED.name, failedAttRow.uploadStatus)

            // Restore the attachment file & retry -> recovers attachment to SYNCED cleanly
            val restoredFile = File(failedAttRow.localFilePath)
            restoredFile.parentFile?.mkdirs()
            restoredFile.writeBytes(dummyJpegBytes)
            val recoveredSummary = opsAfterRestart.syncPendingOfflineQueueDetailed(
                actor = activeAgent,
                pollingUnitsById = mapOf(pu.id to pu),
                forceRetryIgnoredBackoff = true
            )
            assertEquals(0, recoveredSummary.attachmentRetryPendingCount)
            val verifiedAttRow = reopenedDao.getAttachmentsForReport(reportWithBrokenAtt, activeAgent.uid).first()
            assertEquals(OfflineSyncStatus.SYNCED.name, verifiedAttRow.uploadStatus)
            assertTrue(verifiedAttRow.serverVerified)

            // --- SCENARIO E: Conflict Protection Never Silently Overwrites Verified Server Result ---
            ensureAdminAndMasterPu("pu_20-14-01-001")
            val adminSub = withTimeout(TIMEOUT_MS) {
                firestore.collection("result_submissions").document(resultReportId).get(Source.SERVER).await()
                    .toObject(com.example.data.model.ResultSubmission::class.java)!!.copy(id = resultReportId)
            }
            withTimeout(TIMEOUT_MS) {
                OperationsRepository(firestore, null, auth).reviewResultSubmission(
                    actor = admin,
                    submission = adminSub,
                    newStatus = VerificationStatus.VERIFIED,
                    reviewNote = "Verified by Admin before conflicting offline sync",
                    publishToPublic = true
                ).getOrThrow()
            }

            // Agent tries to sync an older/conflicting offline result targeting same verified PU
            signInTestUser(agentEmail)
            val conflictReportId = opsAfterRestart.enqueueResultOfflineFirst(
                actor = activeAgent,
                pu = pu.copy(operationalStatus = "RESULT_VERIFIED"),
                registeredVoters = 500L,
                accreditedVoters = 200L,
                validVotes = 190L,
                rejectedVotes = 10L,
                bvasStatus = BvasStatus.FUNCTIONAL.label,
                bvasNotes = "Conflicting offline numbers",
                submissionNotes = "Should be flagged as conflict without overwriting verified tally",
                existingSubmission = adminSub,
                reportId = "res_conflict_$suffix"
            )
            val conflictSummary = opsAfterRestart.syncPendingOfflineQueueDetailed(
                actor = activeAgent,
                pollingUnitsById = mapOf(pu.id to pu),
                resultsById = mapOf(adminSub.id to adminSub.copy(verificationStatus = VerificationStatus.VERIFIED.name)),
                forceRetryIgnoredBackoff = true
            )
            assertEquals(1, conflictSummary.conflictCount)
            val flaggedEntity = reopenedDao.getByIdForUser(conflictReportId, activeAgent.uid)
            assertTrue(flaggedEntity?.hasConflict == true)
            assertEquals(OfflineSyncStatus.SYNC_FAILED.name, flaggedEntity?.syncStatus)

            // Confirm verified server tallies were NOT overwritten (still 310 valid votes!)
            val postConflictServerSnap = withTimeout(TIMEOUT_MS) {
                firestore.collection("result_submissions").document(resultReportId).get(Source.SERVER).await()
            }
            assertEquals(310L, postConflictServerSnap.getLong("validVotes"))
            assertEquals(VerificationStatus.VERIFIED.name, postConflictServerSnap.getString("verificationStatus"))

            // Also verify CachedUserProfileEntity keeps revoked state blocked
            reopenedDao.upsertCachedUser(CachedUserProfileEntity.fromUserAccount(activeAgent))
        } finally {
            withTimeout(TIMEOUT_MS) { runCatching { firestore.enableNetwork().await() } }
            roomDb.close()
            context.deleteDatabase(dbName)
        }
    }

    private companion object {
        const val TIMEOUT_MS = 8000L
        const val IMPORT_TIMEOUT_MS = 25000L
    }
}
