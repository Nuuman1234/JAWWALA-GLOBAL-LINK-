package com.example.data.firebase

import com.example.data.local.OfflineItemType
import com.example.data.local.OfflineQueueDao
import com.example.data.local.OfflineSyncStatus
import com.example.data.model.AgentCheckIn
import com.example.data.model.GlobalSettings
import com.example.data.model.IncidentReport
import com.example.data.model.IncidentStatus
import com.example.data.model.IncidentUrgency
import com.example.data.model.NotificationItem
import com.example.data.model.PollingUnit
import com.example.data.model.PublicVerifiedResult
import com.example.data.model.PuOperationalStatus
import com.example.data.model.ResultHistoryEntry
import com.example.data.model.ResultSubmission
import com.example.data.model.TimelineEvent
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.model.VerificationStatus
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import java.util.UUID

class OperationsRepository(
    private val db: FirebaseFirestore,
    private val offlineDao: OfflineQueueDao? = null,
    private val auth: FirebaseAuth = Firebase.auth
) {
    private val syncMutex = Mutex()
    private val offlineSyncEngine: OfflineSyncEngine? by lazy {
        offlineDao?.let { OfflineSyncEngine(db, it, auth, this) }
    }
    private fun requireUid(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("Authenticated user required.")

    private fun <T> Flow<List<T>>.withErrorHandling(path: String): Flow<List<T>> =
        catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val ex = firestoreError ?: (error as? Exception)
            if (ex != null && auth.currentUser != null) {
                handleFirestoreError(ex, OperationType.LIST, path, auth)
            }
            throw error
        }

    fun observeCheckIns(user: UserAccount): Flow<List<AgentCheckIn>> {
        val base = db.collection("check_ins")
        val query: Query = when (user.roleEnum) {
            UserRole.FULL_CONTROL_ADMIN -> base
            UserRole.FUNTUA_SUPER_ADMIN -> base.whereEqualTo("lgaId", "funtua")
            UserRole.DANDUME_SUPER_ADMIN -> base.whereEqualTo("lgaId", "dandume")
            UserRole.WARD_COORDINATOR -> {
                if (user.assignedWardId.isBlank()) return flowOf(emptyList())
                base.whereEqualTo("wardId", user.assignedWardId)
            }
            UserRole.POLLING_UNIT_AGENT -> base.whereEqualTo("agentUid", user.uid)
            UserRole.PENDING -> return flowOf(emptyList())
        }
        return query.snapshots()
            .map { snap ->
                snap.toObjects(AgentCheckIn::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .withErrorHandling("check_ins")
    }

    fun observeIncidents(user: UserAccount): Flow<List<IncidentReport>> {
        val base = db.collection("incidents")
        val query: Query = when (user.roleEnum) {
            UserRole.FULL_CONTROL_ADMIN -> base
            UserRole.FUNTUA_SUPER_ADMIN -> base.whereEqualTo("lgaId", "funtua")
            UserRole.DANDUME_SUPER_ADMIN -> base.whereEqualTo("lgaId", "dandume")
            UserRole.WARD_COORDINATOR -> {
                if (user.assignedWardId.isBlank()) return flowOf(emptyList())
                base.whereEqualTo("wardId", user.assignedWardId)
            }
            UserRole.POLLING_UNIT_AGENT -> base.whereEqualTo("reporterUid", user.uid)
            UserRole.PENDING -> return flowOf(emptyList())
        }
        return query.snapshots()
            .map { snap ->
                snap.toObjects(IncidentReport::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .withErrorHandling("incidents")
    }

    fun observeResults(user: UserAccount): Flow<List<ResultSubmission>> {
        val base = db.collection("result_submissions")
        val query: Query = when (user.roleEnum) {
            UserRole.FULL_CONTROL_ADMIN -> base
            UserRole.FUNTUA_SUPER_ADMIN -> base.whereEqualTo("lgaId", "funtua")
            UserRole.DANDUME_SUPER_ADMIN -> base.whereEqualTo("lgaId", "dandume")
            UserRole.WARD_COORDINATOR -> {
                if (user.assignedWardId.isBlank()) return flowOf(emptyList())
                base.whereEqualTo("wardId", user.assignedWardId)
            }
            UserRole.POLLING_UNIT_AGENT -> base.whereEqualTo("submittedByUid", user.uid)
            UserRole.PENDING -> return flowOf(emptyList())
        }
        return query.snapshots()
            .map { snap ->
                snap.toObjects(ResultSubmission::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt?.seconds ?: it.createdAt?.seconds ?: 0L }
            }
            .withErrorHandling("result_submissions")
    }

    fun observePublicResults(): Flow<List<PublicVerifiedResult>> {
        return db.collection("public_results")
            .snapshots()
            .map { snap ->
                snap.toObjects(PublicVerifiedResult::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.puCode }
            }
            .withErrorHandling("public_results")
    }

    fun observeTimeline(user: UserAccount): Flow<List<TimelineEvent>> {
        val base = db.collection("timeline_events")
        val query: Query = when (user.roleEnum) {
            UserRole.FULL_CONTROL_ADMIN -> base
            UserRole.FUNTUA_SUPER_ADMIN -> base.whereEqualTo("lgaId", "funtua")
            UserRole.DANDUME_SUPER_ADMIN -> base.whereEqualTo("lgaId", "dandume")
            UserRole.WARD_COORDINATOR -> {
                if (user.assignedWardId.isBlank()) return flowOf(emptyList())
                base.whereEqualTo("wardId", user.assignedWardId)
            }
            UserRole.POLLING_UNIT_AGENT -> base.whereEqualTo("actorUid", user.uid)
            UserRole.PENDING -> return flowOf(emptyList())
        }
        return query.snapshots()
            .map { snap ->
                snap.toObjects(TimelineEvent::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .withErrorHandling("timeline_events")
    }

    fun observeNotifications(user: UserAccount): Flow<List<NotificationItem>> {
        val base = db.collection("notifications")
        val query: Query = when (user.roleEnum) {
            UserRole.FULL_CONTROL_ADMIN -> base
            UserRole.FUNTUA_SUPER_ADMIN, UserRole.DANDUME_SUPER_ADMIN -> {
                base.whereIn("targetLgaId", listOf("all", user.assignedLgaId))
            }
            UserRole.WARD_COORDINATOR -> {
                if (user.assignedLgaId.isBlank()) return flowOf(emptyList())
                base.whereIn("targetLgaId", listOf("all", user.assignedLgaId))
            }
            UserRole.POLLING_UNIT_AGENT -> {
                if (user.assignedLgaId.isBlank()) return flowOf(emptyList())
                base.whereIn("targetLgaId", listOf("all", user.assignedLgaId))
            }
            UserRole.PENDING -> return flowOf(emptyList())
        }
        return query.snapshots()
            .map { snap ->
                snap.toObjects(NotificationItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .withErrorHandling("notifications")
    }

    suspend fun getResultHistory(resultId: String): Result<List<ResultHistoryEntry>> = runCatching {
        requireUid()
        val path = "result_submissions/$resultId/history"
        try {
            db.collection("result_submissions").document(resultId)
                .collection("history")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get()
                .await()
                .toObjects(ResultHistoryEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path, auth)
            throw e
        }
    }

    suspend fun submitCheckIn(
        actor: UserAccount,
        pu: PollingUnit,
        arrivalTimeText: String,
        comments: String,
        batteryPercent: Int,
        networkStatus: String,
        latitude: Double? = null,
        longitude: Double? = null,
        clientSubmissionId: String = "ci_${UUID.randomUUID()}",
        skipPuStatusRegression: Boolean = false
    ): Result<String> = runCatching {
        val uid = requireUid()
        val checkInRef = db.collection("check_ins").document(clientSubmissionId)
        val payload = mutableMapOf<String, Any>(
            "puId" to pu.id,
            "puCode" to pu.puCode,
            "puName" to pu.name,
            "lgaId" to pu.lgaId,
            "wardId" to pu.wardId,
            "agentUid" to uid,
            "agentName" to actor.displayName.ifBlank { actor.email },
            "arrivalTimeText" to arrivalTimeText.trim().take(60),
            "comments" to comments.trim().take(480),
            "batteryPercent" to batteryPercent.coerceIn(-1, 100).toLong(),
            "networkStatus" to networkStatus.take(60),
            "clientSubmissionId" to clientSubmissionId,
            "isTestData" to pu.isTestData,
            "createdAt" to FieldValue.serverTimestamp()
        )
        if (latitude != null && longitude != null) {
            payload["latitude"] = latitude
            payload["longitude"] = longitude
        }

        val batch = db.batch()
        batch.set(checkInRef, payload)
        if (!skipPuStatusRegression && (pu.statusEnum == PuOperationalStatus.NOT_STARTED || pu.statusEnum == PuOperationalStatus.AGENT_ASSIGNED)) {
            batch.update(
                db.collection("polling_units").document(pu.id),
                mapOf(
                    "operationalStatus" to PuOperationalStatus.AGENT_CHECKED_IN.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }
        batch.set(
            db.collection("timeline_events").document(),
            timelinePayload(
                "AGENT_CHECK_IN",
                "Agent Checked In · ${pu.puCode}",
                "${actor.displayName} arrived at ${pu.name} ($arrivalTimeText)",
                pu.lgaId, pu.wardId, pu.id, pu.puCode, actor, pu.isTestData
            )
        )
        batch.set(
            db.collection("audit_logs").document(),
            auditPayload(actor, "AGENT_CHECK_IN", "check_ins", clientSubmissionId, "Agent checked in at ${pu.puCode}")
        )
        try {
            batch.commit().await()
            clientSubmissionId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, checkInRef.path, auth)
            throw e
        }
    }

    suspend fun updatePollingUnitStatus(
        actor: UserAccount,
        pu: PollingUnit,
        newStatus: PuOperationalStatus
    ): Result<Unit> = runCatching {
        requireUid()
        val puRef = db.collection("polling_units").document(pu.id)
        val batch = db.batch()
        batch.update(
            puRef,
            mapOf(
                "operationalStatus" to newStatus.name,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(
            db.collection("timeline_events").document(),
            timelinePayload(
                "STATUS_UPDATE",
                "${newStatus.label} · ${pu.puCode}",
                "${pu.name} status updated to ${newStatus.label}",
                pu.lgaId, pu.wardId, pu.id, pu.puCode, actor, pu.isTestData
            )
        )
        batch.set(
            db.collection("audit_logs").document(),
            auditPayload(actor, "PU_STATUS_UPDATED", "polling_units", pu.id, "${pu.puCode} -> ${newStatus.name}")
        )
        try {
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, puRef.path, auth)
            throw e
        }
    }

    suspend fun submitIncident(
        actor: UserAccount,
        pu: PollingUnit?,
        lgaId: String,
        wardId: String,
        title: String,
        category: String,
        description: String,
        urgency: IncidentUrgency,
        evidenceBase64: String? = null,
        evidenceFileName: String? = null,
        clientSubmissionId: String = "inc_${UUID.randomUUID()}"
    ): Result<String> = runCatching {
        val uid = requireUid()
        require(title.trim().length >= 3) { "Incident title must be at least 3 characters." }
        require(description.trim().length >= 5) { "Incident description must be at least 5 characters." }

        val incRef = db.collection("incidents").document(clientSubmissionId)
        val payload = mutableMapOf<String, Any>(
            "title" to title.trim().take(150),
            "category" to category.take(96),
            "description" to description.trim().take(1900),
            "urgency" to urgency.name,
            "status" to IncidentStatus.NEW.name,
            "lgaId" to (pu?.lgaId ?: lgaId),
            "wardId" to (pu?.wardId ?: wardId),
            "puId" to (pu?.id ?: ""),
            "puCode" to (pu?.puCode ?: "WARD-LEVEL"),
            "puName" to (pu?.name ?: "Ward / LGA Level"),
            "reporterUid" to uid,
            "reporterName" to actor.displayName.ifBlank { actor.email },
            "internalNotes" to "",
            "escalatedTo" to "",
            "reviewedByUid" to "",
            "clientSubmissionId" to clientSubmissionId,
            "isTestData" to (pu?.isTestData ?: false),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (!evidenceBase64.isNullOrBlank()) {
            payload["evidenceBase64"] = evidenceBase64
            payload["evidenceFileName"] = evidenceFileName ?: "incident_evidence.jpg"
        }

        val batch = db.batch()
        batch.set(incRef, payload)
        if (pu != null && urgency == IncidentUrgency.CRITICAL) {
            batch.update(
                db.collection("polling_units").document(pu.id),
                mapOf(
                    "operationalStatus" to PuOperationalStatus.INCIDENT_REPORTED.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }
        batch.set(
            db.collection("timeline_events").document(),
            timelinePayload(
                "INCIDENT_REPORTED",
                "${urgency.label} Incident · ${pu?.puCode ?: lgaId.uppercase()}",
                title.trim(),
                pu?.lgaId ?: lgaId,
                pu?.wardId ?: wardId,
                pu?.id ?: "",
                pu?.puCode ?: "",
                actor,
                pu?.isTestData ?: false
            )
        )
        if (urgency == IncidentUrgency.CRITICAL || urgency == IncidentUrgency.HIGH) {
            batch.set(
                db.collection("notifications").document(),
                mapOf(
                    "title" to "${urgency.label} Alert: ${title.trim().take(100)}",
                    "body" to "${pu?.puCode ?: lgaId.uppercase()}: ${description.trim().take(300)}",
                    "type" to "INCIDENT_ALERT",
                    "targetLgaId" to (pu?.lgaId ?: lgaId),
                    "targetWardId" to (pu?.wardId ?: wardId),
                    "isCritical" to (urgency == IncidentUrgency.CRITICAL),
                    "createdByUid" to uid,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
        }
        batch.set(
            db.collection("audit_logs").document(),
            auditPayload(actor, "INCIDENT_SUBMITTED", "incidents", clientSubmissionId, "Submitted ${urgency.name} incident: ${title.trim()}")
        )
        try {
            batch.commit().await()
            clientSubmissionId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, incRef.path, auth)
            throw e
        }
    }

    suspend fun updateIncidentWorkflow(
        actor: UserAccount,
        incident: IncidentReport,
        newStatus: IncidentStatus,
        internalNotes: String,
        escalatedTo: String
    ): Result<Unit> = runCatching {
        val uid = requireUid()
        val incRef = db.collection("incidents").document(incident.id)
        val batch = db.batch()
        batch.update(
            incRef,
            mapOf(
                "status" to newStatus.name,
                "internalNotes" to internalNotes.trim().take(1400),
                "escalatedTo" to escalatedTo.trim().take(110),
                "reviewedByUid" to uid,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(
            db.collection("audit_logs").document(),
            auditPayload(actor, "INCIDENT_UPDATED", "incidents", incident.id, "${incident.title} -> ${newStatus.name}")
        )
        try {
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, incRef.path, auth)
            throw e
        }
    }

    suspend fun submitPollingUnitResult(
        actor: UserAccount,
        pu: PollingUnit,
        registeredVoters: Long,
        accreditedVoters: Long,
        validVotes: Long,
        rejectedVotes: Long,
        bvasStatus: String,
        bvasNotes: String,
        submissionNotes: String,
        ec8aImageBase64: String? = null,
        ec8aFileName: String? = null,
        existingSubmission: ResultSubmission? = null,
        clientSubmissionId: String = existingSubmission?.id?.takeIf { it.isNotBlank() } ?: "res_${pu.id}_${UUID.randomUUID().toString().take(8)}"
    ): Result<String> = runCatching {
        val uid = requireUid()
        val totalCast = validVotes + rejectedVotes
        require(registeredVoters >= 0 && accreditedVoters >= 0 && validVotes >= 0 && rejectedVotes >= 0) {
            "Vote and accreditation figures cannot be negative."
        }
        val docRef = db.collection("result_submissions").document(clientSubmissionId)
        val historyRef = docRef.collection("history").document()
        val nextVersion = (existingSubmission?.version ?: 0L) + 1L

        val batch = db.batch()
        if (existingSubmission == null) {
            val payload = mutableMapOf<String, Any>(
                "puId" to pu.id,
                "puCode" to pu.puCode,
                "puName" to pu.name,
                "lgaId" to pu.lgaId,
                "wardId" to pu.wardId,
                "wardName" to pu.wardName,
                "submittedByUid" to uid,
                "submittedByName" to actor.displayName.ifBlank { actor.email },
                "registeredVoters" to registeredVoters,
                "accreditedVoters" to accreditedVoters,
                "validVotes" to validVotes,
                "rejectedVotes" to rejectedVotes,
                "totalVotesCast" to totalCast,
                "bvasStatus" to bvasStatus.take(75),
                "bvasNotes" to bvasNotes.trim().take(950),
                "submissionNotes" to submissionNotes.trim().take(950),
                "verificationStatus" to VerificationStatus.SUBMITTED.name,
                "publiclyApproved" to false,
                "reviewNote" to "",
                "reviewedByUid" to "",
                "reviewedByName" to "",
                "version" to 1L,
                "clientSubmissionId" to clientSubmissionId,
                "isTestData" to pu.isTestData,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!ec8aImageBase64.isNullOrBlank()) {
                payload["ec8aImageBase64"] = ec8aImageBase64
                payload["ec8aFileName"] = ec8aFileName ?: "form_ec8a.jpg"
            }
            batch.set(docRef, payload)
        } else {
            val updates = mutableMapOf<String, Any>(
                "registeredVoters" to registeredVoters,
                "accreditedVoters" to accreditedVoters,
                "validVotes" to validVotes,
                "rejectedVotes" to rejectedVotes,
                "totalVotesCast" to totalCast,
                "bvasStatus" to bvasStatus.take(75),
                "bvasNotes" to bvasNotes.trim().take(950),
                "submissionNotes" to submissionNotes.trim().take(950),
                "verificationStatus" to VerificationStatus.SUBMITTED.name,
                "publiclyApproved" to false,
                "version" to nextVersion,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!ec8aImageBase64.isNullOrBlank()) {
                updates["ec8aImageBase64"] = ec8aImageBase64
                updates["ec8aFileName"] = ec8aFileName ?: "form_ec8a.jpg"
            }
            batch.update(docRef, updates)
        }

        batch.set(
            historyRef,
            mapOf(
                "action" to if (existingSubmission == null) "INITIAL_SUBMISSION" else "CORRECTION_RESUBMITTED",
                "previousStatus" to (existingSubmission?.verificationStatus ?: "NONE"),
                "newStatus" to VerificationStatus.SUBMITTED.name,
                "note" to submissionNotes.trim().ifBlank { "Polling unit result submitted" }.take(950),
                "actorUid" to uid,
                "actorName" to actor.displayName.ifBlank { actor.email },
                "registeredVoters" to registeredVoters,
                "accreditedVoters" to accreditedVoters,
                "validVotes" to validVotes,
                "rejectedVotes" to rejectedVotes,
                "totalVotesCast" to totalCast,
                "createdAt" to FieldValue.serverTimestamp()
            )
        )
        batch.update(
            db.collection("polling_units").document(pu.id),
            mapOf(
                "operationalStatus" to PuOperationalStatus.RESULT_SUBMITTED.name,
                "registeredVoters" to registeredVoters,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(
            db.collection("timeline_events").document(),
            timelinePayload(
                "RESULT_SUBMITTED",
                "Result Submitted · ${pu.puCode}",
                "Accredited: $accreditedVoters, Valid: $validVotes, Rejected: $rejectedVotes",
                pu.lgaId, pu.wardId, pu.id, pu.puCode, actor, pu.isTestData
            )
        )
        batch.set(
            db.collection("audit_logs").document(),
            auditPayload(actor, "RESULT_SUBMITTED", "result_submissions", clientSubmissionId, "Submitted result v$nextVersion for ${pu.puCode}")
        )
        try {
            batch.commit().await()
            clientSubmissionId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
            throw e
        }
    }

    suspend fun reviewResultSubmission(
        actor: UserAccount,
        submission: ResultSubmission,
        newStatus: VerificationStatus,
        reviewNote: String,
        publishToPublic: Boolean
    ): Result<Unit> = runCatching {
        val uid = requireUid()
        require(reviewNote.trim().length >= 3) { "A verification/review reason is required." }

        val docRef = db.collection("result_submissions").document(submission.id)
        val historyRef = docRef.collection("history").document()
        val puRef = db.collection("polling_units").document(submission.puId)
        val canPublish = publishToPublic && newStatus == VerificationStatus.VERIFIED && actor.roleEnum.canApprovePublicResults()

        val batch = db.batch()
        batch.update(
            docRef,
            mapOf(
                "verificationStatus" to newStatus.name,
                "publiclyApproved" to canPublish,
                "reviewNote" to reviewNote.trim().take(950),
                "reviewedByUid" to uid,
                "reviewedByName" to actor.displayName.ifBlank { actor.email },
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(
            historyRef,
            mapOf(
                "action" to "VERIFICATION_${newStatus.name}",
                "previousStatus" to submission.verificationStatus,
                "newStatus" to newStatus.name,
                "note" to reviewNote.trim().take(950),
                "actorUid" to uid,
                "actorName" to actor.displayName.ifBlank { actor.email },
                "registeredVoters" to submission.registeredVoters,
                "accreditedVoters" to submission.accreditedVoters,
                "validVotes" to submission.validVotes,
                "rejectedVotes" to submission.rejectedVotes,
                "totalVotesCast" to submission.totalVotesCast,
                "createdAt" to FieldValue.serverTimestamp()
            )
        )

        val puStatus = when (newStatus) {
            VerificationStatus.UNDER_REVIEW -> PuOperationalStatus.RESULT_UNDER_REVIEW
            VerificationStatus.VERIFIED -> PuOperationalStatus.RESULT_VERIFIED
            else -> null
        }
        if (puStatus != null) {
            batch.update(
                puRef,
                mapOf(
                    "operationalStatus" to puStatus.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }

        if (canPublish && !submission.isTestData) {
            batch.set(
                db.collection("public_results").document(submission.puId),
                mapOf(
                    "puCode" to submission.puCode,
                    "puName" to submission.puName,
                    "wardName" to submission.wardName,
                    "lgaId" to submission.lgaId,
                    "registeredVoters" to submission.registeredVoters,
                    "accreditedVoters" to submission.accreditedVoters,
                    "validVotes" to submission.validVotes,
                    "rejectedVotes" to submission.rejectedVotes,
                    "totalVotesCast" to submission.totalVotesCast,
                    "approvedByUid" to uid,
                    "verifiedAt" to FieldValue.serverTimestamp()
                )
            )
        }

        if (newStatus == VerificationStatus.VERIFIED) {
            batch.set(
                db.collection("timeline_events").document(),
                timelinePayload(
                    "RESULT_VERIFIED",
                    "Result Verified · ${submission.puCode}",
                    "Verified by ${actor.displayName} (${submission.totalVotesCast} total votes)",
                    submission.lgaId, submission.wardId, submission.puId, submission.puCode, actor, submission.isTestData
                )
            )
        }

        batch.set(
            db.collection("audit_logs").document(),
            auditPayload(
                actor,
                "RESULT_${newStatus.name}",
                "result_submissions",
                submission.id,
                "${submission.puCode}: ${submission.verificationStatus} -> ${newStatus.name}. Note: ${reviewNote.trim()}"
            )
        )
        try {
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            throw e
        }
    }

    suspend fun postAnnouncement(
        actor: UserAccount,
        title: String,
        body: String,
        targetLgaId: String,
        isCritical: Boolean
    ): Result<Unit> = runCatching {
        val uid = requireUid()
        require(title.trim().length >= 2 && body.trim().length >= 2) { "Title and message are required." }
        val docRef = db.collection("notifications").document()
        val batch = db.batch()
        batch.set(
            docRef,
            mapOf(
                "title" to title.trim().take(150),
                "body" to body.trim().take(950),
                "type" to "ANNOUNCEMENT",
                "targetLgaId" to targetLgaId,
                "targetWardId" to "",
                "isCritical" to isCritical,
                "createdByUid" to uid,
                "createdAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(
            db.collection("audit_logs").document(),
            auditPayload(actor, "NOTIFICATION_SENT", "notifications", docRef.id, "Announcement to $targetLgaId: ${title.trim()}")
        )
        try {
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            throw e
        }
    }

    suspend fun updateGlobalSettings(
        actor: UserAccount,
        settings: GlobalSettings
    ): Result<Unit> = runCatching {
        val uid = requireUid()
        val ref = db.collection("system_settings").document("global")
        val batch = db.batch()
        batch.set(
            ref,
            mapOf(
                "inactivityTimeoutMinutes" to settings.inactivityTimeoutMinutes.coerceIn(5L, 480L),
                "mfaPrepared" to settings.mfaPrepared,
                "publicSummaryEnabled" to settings.publicSummaryEnabled,
                "smsFallbackConfigured" to settings.smsFallbackConfigured,
                "whatsappConfigured" to settings.whatsappConfigured,
                "emailConfigured" to settings.emailConfigured,
                "updatedByUid" to uid,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(
            db.collection("audit_logs").document(),
            auditPayload(actor, "SETTINGS_UPDATED", "system_settings", "global", "Updated inactivity=${settings.inactivityTimeoutMinutes}m, publicSummary=${settings.publicSummaryEnabled}")
        )
        try {
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path, auth)
            throw e
        }
    }

    // --- OFFLINE-FIRST QUEUE, AUTO-SAVE DRAFTS & SAFE SYNC ---
    suspend fun verifyBackendReachable(): Boolean =
        offlineSyncEngine?.verifyBackendReachable() ?: false

    suspend fun saveOfflineDraft(
        actor: UserAccount,
        reportId: String,
        itemType: OfflineItemType,
        lgaId: String,
        wardId: String,
        pu: PollingUnit?,
        title: String,
        subtitle: String,
        payloadJson: JSONObject,
        attachmentDraft: OfflineAttachmentDraft? = null
    ): String {
        val engine = offlineSyncEngine ?: return reportId
        return engine.saveDraft(
            actor = actor,
            reportId = reportId,
            itemType = itemType,
            lgaId = lgaId,
            wardId = wardId,
            pu = pu,
            title = title,
            subtitle = subtitle,
            payloadJson = payloadJson,
            attachmentDraft = attachmentDraft
        )
    }

    suspend fun enqueueCheckInOfflineFirst(
        actor: UserAccount,
        pu: PollingUnit,
        arrivalTimeText: String,
        comments: String,
        batteryPercent: Int,
        networkStatus: String,
        latitude: Double?,
        longitude: Double?,
        reportId: String = "ci_${UUID.randomUUID()}",
        attachmentDraft: OfflineAttachmentDraft? = null
    ): String {
        val engine = offlineSyncEngine ?: return reportId
        val json = JSONObject().apply {
            put("puId", pu.id)
            put("puCode", pu.puCode)
            put("puName", pu.name)
            put("lgaId", pu.lgaId)
            put("wardId", pu.wardId)
            put("isTestData", pu.isTestData)
            put("arrivalTimeText", arrivalTimeText)
            put("comments", comments)
            put("batteryPercent", batteryPercent)
            put("networkStatus", networkStatus)
            if (latitude != null) put("latitude", latitude)
            if (longitude != null) put("longitude", longitude)
        }
        return engine.enqueueForSync(
            actor = actor,
            reportId = reportId,
            itemType = OfflineItemType.CHECK_IN,
            lgaId = pu.lgaId,
            wardId = pu.wardId,
            pu = pu,
            title = "Check-In · ${pu.puCode}",
            subtitle = "$arrivalTimeText · ${pu.name}",
            payloadJson = json,
            attachmentDraft = attachmentDraft
        )
    }

    suspend fun enqueueStatusUpdateOfflineFirst(
        actor: UserAccount,
        pu: PollingUnit,
        newStatus: PuOperationalStatus,
        latitude: Double? = null,
        longitude: Double? = null,
        reportId: String = "st_${UUID.randomUUID()}"
    ): String {
        val engine = offlineSyncEngine ?: return reportId
        val json = JSONObject().apply {
            put("puId", pu.id)
            put("puCode", pu.puCode)
            put("puName", pu.name)
            put("lgaId", pu.lgaId)
            put("wardId", pu.wardId)
            put("isTestData", pu.isTestData)
            put("newStatus", newStatus.name)
            if (latitude != null) put("latitude", latitude)
            if (longitude != null) put("longitude", longitude)
        }
        return engine.enqueueForSync(
            actor = actor,
            reportId = reportId,
            itemType = OfflineItemType.STATUS_UPDATE,
            lgaId = pu.lgaId,
            wardId = pu.wardId,
            pu = pu,
            title = "PU Status · ${pu.puCode} -> ${newStatus.label}",
            subtitle = "${pu.name} · ${pu.wardName}",
            payloadJson = json,
            attachmentDraft = null
        )
    }

    suspend fun enqueueIncidentOfflineFirst(
        actor: UserAccount,
        pu: PollingUnit?,
        lgaId: String,
        wardId: String,
        title: String,
        category: String,
        description: String,
        urgency: IncidentUrgency,
        evidenceBase64: String? = null,
        evidenceFileName: String? = null,
        attachmentDraft: OfflineAttachmentDraft? = null,
        latitude: Double? = null,
        longitude: Double? = null,
        reportId: String = "inc_${UUID.randomUUID()}"
    ): String {
        val engine = offlineSyncEngine ?: return reportId
        val json = JSONObject().apply {
            put("puId", pu?.id ?: "")
            put("puCode", pu?.puCode ?: "WARD-LEVEL")
            put("puName", pu?.name ?: "Ward / LGA Level")
            put("lgaId", pu?.lgaId ?: lgaId)
            put("wardId", pu?.wardId ?: wardId)
            put("isTestData", pu?.isTestData ?: false)
            put("title", title)
            put("category", category)
            put("description", description)
            put("urgency", urgency.name)
            if (attachmentDraft == null && !evidenceBase64.isNullOrBlank()) {
                put("evidenceBase64", evidenceBase64)
                put("evidenceFileName", evidenceFileName ?: "incident_evidence.jpg")
            } else if (!evidenceFileName.isNullOrBlank()) {
                put("evidenceFileName", evidenceFileName)
            }
            if (latitude != null) put("latitude", latitude)
            if (longitude != null) put("longitude", longitude)
        }
        return engine.enqueueForSync(
            actor = actor,
            reportId = reportId,
            itemType = OfflineItemType.INCIDENT_REPORT,
            lgaId = pu?.lgaId ?: lgaId,
            wardId = pu?.wardId ?: wardId,
            pu = pu,
            title = "${urgency.label} Incident · ${title.take(36)}",
            subtitle = "${pu?.puCode ?: lgaId.uppercase()} · $category",
            payloadJson = json,
            attachmentDraft = attachmentDraft
        )
    }

    suspend fun enqueueResultOfflineFirst(
        actor: UserAccount,
        pu: PollingUnit,
        registeredVoters: Long,
        accreditedVoters: Long,
        validVotes: Long,
        rejectedVotes: Long,
        bvasStatus: String,
        bvasNotes: String,
        submissionNotes: String,
        ec8aImageBase64: String? = null,
        ec8aFileName: String? = null,
        attachmentDraft: OfflineAttachmentDraft? = null,
        existingSubmission: ResultSubmission? = null,
        latitude: Double? = null,
        longitude: Double? = null,
        reportId: String = existingSubmission?.id?.takeIf { it.isNotBlank() } ?: "res_${pu.id}_${UUID.randomUUID().toString().take(8)}"
    ): String {
        val engine = offlineSyncEngine ?: return reportId
        val nextVersion = (existingSubmission?.version ?: 0L) + 1L
        val json = JSONObject().apply {
            put("puId", pu.id)
            put("puCode", pu.puCode)
            put("puName", pu.name)
            put("lgaId", pu.lgaId)
            put("wardId", pu.wardId)
            put("wardName", pu.wardName)
            put("isTestData", pu.isTestData)
            put("registeredVoters", registeredVoters)
            put("accreditedVoters", accreditedVoters)
            put("validVotes", validVotes)
            put("rejectedVotes", rejectedVotes)
            put("bvasStatus", bvasStatus)
            put("bvasNotes", bvasNotes)
            put("submissionNotes", submissionNotes)
            put("existingSubmissionId", existingSubmission?.id ?: "")
            put("expectedVersion", nextVersion)
            if (attachmentDraft == null && !ec8aImageBase64.isNullOrBlank()) {
                put("ec8aImageBase64", ec8aImageBase64)
                put("ec8aFileName", ec8aFileName ?: "form_ec8a.jpg")
            } else if (!ec8aFileName.isNullOrBlank()) {
                put("ec8aFileName", ec8aFileName)
            }
            if (latitude != null) put("latitude", latitude)
            if (longitude != null) put("longitude", longitude)
        }
        return engine.enqueueForSync(
            actor = actor,
            reportId = reportId,
            itemType = OfflineItemType.RESULT_SUBMISSION,
            lgaId = pu.lgaId,
            wardId = pu.wardId,
            pu = pu,
            title = "Form EC8A Result · ${pu.puCode}",
            subtitle = "Valid: $validVotes · Accr: $accreditedVoters · ${pu.name}",
            payloadJson = json,
            attachmentDraft = attachmentDraft
        )
    }

    suspend fun archiveConfirmedQueueEntries(ownerUid: String) {
        if (ownerUid.isBlank()) return
        offlineDao?.archiveConfirmedQueueEntries(ownerUid)
    }

    suspend fun clearSyncedOfflineHistory() {
        val uid = auth.currentUser?.uid
        if (!uid.isNullOrBlank()) {
            offlineDao?.archiveConfirmedQueueEntries(uid)
        } else {
            offlineDao?.clearSynced()
        }
    }

    suspend fun syncPendingOfflineQueueDetailed(
        actor: UserAccount,
        pollingUnitsById: Map<String, PollingUnit>,
        resultsById: Map<String, ResultSubmission> = emptyMap(),
        forceRetryIgnoredBackoff: Boolean = false
    ): SyncBatchSummary {
        val engine = offlineSyncEngine ?: return SyncBatchSummary(backendReachable = true)
        return syncMutex.withLock {
            engine.syncPendingForUser(
                actor = actor,
                pollingUnitsById = pollingUnitsById,
                resultsById = resultsById,
                forceRetryIgnoredBackoff = forceRetryIgnoredBackoff
            )
        }
    }

    suspend fun syncPendingOfflineQueue(
        actor: UserAccount,
        pollingUnitsById: Map<String, PollingUnit>
    ): Pair<Int, Int> {
        val summary = syncPendingOfflineQueueDetailed(
            actor = actor,
            pollingUnitsById = pollingUnitsById,
            forceRetryIgnoredBackoff = true
        )
        return summary.syncedCount to summary.failedCount
    }

    private fun timelinePayload(
        eventType: String,
        title: String,
        description: String,
        lgaId: String,
        wardId: String,
        puId: String,
        puCode: String,
        actor: UserAccount,
        isTestData: Boolean
    ): Map<String, Any> = mapOf(
        "eventType" to eventType,
        "title" to title.take(150),
        "description" to description.take(580),
        "lgaId" to lgaId,
        "wardId" to wardId,
        "puId" to puId,
        "puCode" to puCode,
        "actorUid" to actor.uid,
        "actorName" to actor.displayName.ifBlank { actor.email },
        "isTestData" to isTestData,
        "createdAt" to FieldValue.serverTimestamp()
    )

    private fun auditPayload(
        actor: UserAccount,
        action: String,
        entity: String,
        affectedId: String,
        details: String
    ): Map<String, Any> = mapOf(
        "actorUid" to actor.uid,
        "actorName" to actor.displayName.ifBlank { actor.email },
        "actorEmail" to actor.email,
        "actorRole" to actor.role,
        "action" to action,
        "affectedEntity" to entity,
        "affectedId" to affectedId,
        "details" to details.take(980),
        "createdAt" to FieldValue.serverTimestamp()
    )
}
