package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.PollingUnit
import com.example.data.model.PuOperationalStatus
import com.example.data.model.UserAccount
import com.example.data.model.Ward
import kotlinx.coroutines.flow.Flow

enum class OfflineItemType {
    CHECK_IN,
    STATUS_UPDATE,
    INCIDENT_REPORT,
    RESULT_SUBMISSION
}

enum class OfflineSyncStatus(val label: String) {
    SAVED_LOCALLY("SAVED LOCALLY"),
    PENDING_SYNC("PENDING SYNC"),
    SYNCING("SYNCING"),
    SYNC_FAILED("SYNC FAILED"),
    SYNCED("SYNCED"),
    UNDER_REVIEW("UNDER REVIEW"),
    VERIFIED("VERIFIED");

    fun isUnsentOrEditable(): Boolean =
        this == SAVED_LOCALLY || this == PENDING_SYNC || this == SYNC_FAILED

    fun isSyncedWithServer(): Boolean =
        this == SYNCED || this == UNDER_REVIEW || this == VERIFIED

    companion object {
        fun fromString(value: String): OfflineSyncStatus = when (value) {
            "SAVED_OFFLINE" -> SAVED_LOCALLY
            "FAILED" -> SYNC_FAILED
            else -> entries.find { it.name == value } ?: PENDING_SYNC
        }
    }
}

@Entity(
    tableName = "offline_queue",
    indices = [
        Index(value = ["ownerUid"]),
        Index(value = ["syncStatus"]),
        Index(value = ["ownerUid", "itemType", "isDraftEditable"])
    ]
)
data class OfflineQueueEntity(
    @PrimaryKey val clientSubmissionId: String,
    val ownerUid: String = "",
    val ownerEmail: String = "",
    val itemType: String,
    val lgaId: String = "",
    val wardId: String = "",
    val puId: String = "",
    val puCode: String = "",
    val puName: String = "",
    val title: String,
    val subtitle: String,
    val payloadJson: String,
    val syncStatus: String = OfflineSyncStatus.SAVED_LOCALLY.name,
    val isDraftEditable: Boolean = false,
    val serverDocId: String? = null,
    val serverVerifiedAck: Boolean = false,
    val serverVersion: Long = 1L,
    val hasConflict: Boolean = false,
    val conflictMessage: String? = null,
    val lastError: String? = null,
    val retryCount: Int = 0,
    val nextRetryAtMillis: Long = 0L,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = System.currentTimeMillis(),
    val syncedAtMillis: Long? = null,
    val archivedFromQueue: Boolean = false
)

@Entity(
    tableName = "offline_attachments",
    indices = [
        Index(value = ["reportId"]),
        Index(value = ["ownerUid"]),
        Index(value = ["uploadStatus"])
    ]
)
data class OfflineAttachmentEntity(
    @PrimaryKey val attachmentId: String,
    val reportId: String,
    val ownerUid: String,
    val reportType: String,
    val lgaId: String,
    val wardId: String,
    val puId: String,
    val fileName: String,
    val localFilePath: String,
    val sha256Hash: String,
    val sizeBytes: Int,
    val uploadStatus: String = OfflineSyncStatus.SAVED_LOCALLY.name,
    val serverVerified: Boolean = false,
    val retryCount: Int = 0,
    val lastError: String? = null,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val uploadedAtMillis: Long? = null
)

@Entity(
    tableName = "sync_history",
    indices = [Index(value = ["ownerUid"]), Index(value = ["reportId"])]
)
data class SyncHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val ownerUid: String,
    val reportId: String,
    val eventType: String,
    val status: String,
    val message: String,
    val timestampMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_user_profiles")
data class CachedUserProfileEntity(
    @PrimaryKey val uid: String,
    val email: String,
    val displayName: String,
    val phone: String?,
    val role: String,
    val status: String,
    val assignedLgaId: String,
    val assignedWardId: String,
    val assignedPollingUnitId: String,
    val sessionRevoked: Boolean,
    val revokedReason: String?,
    val cachedAtMillis: Long = System.currentTimeMillis()
) {
    fun toUserAccount(): UserAccount = UserAccount(
        id = uid,
        uid = uid,
        email = email,
        displayName = displayName,
        phone = phone,
        role = role,
        status = status,
        assignedLgaId = assignedLgaId,
        assignedWardId = assignedWardId,
        assignedPollingUnitId = assignedPollingUnitId,
        sessionRevoked = sessionRevoked,
        revokedReason = revokedReason
    )

    companion object {
        fun fromUserAccount(u: UserAccount): CachedUserProfileEntity = CachedUserProfileEntity(
            uid = u.uid,
            email = u.email,
            displayName = u.displayName,
            phone = u.phone,
            role = u.role,
            status = u.status,
            assignedLgaId = u.assignedLgaId,
            assignedWardId = u.assignedWardId,
            assignedPollingUnitId = u.assignedPollingUnitId,
            sessionRevoked = u.sessionRevoked,
            revokedReason = u.revokedReason
        )
    }
}

@Entity(
    tableName = "cached_wards",
    primaryKeys = ["cachedForUid", "wardId"]
)
data class CachedWardEntity(
    val cachedForUid: String,
    val wardId: String,
    val lgaId: String,
    val wardCode: String,
    val name: String,
    val coordinatorUid: String,
    val coordinatorName: String,
    val expectedPollingUnits: Long,
    val isTestData: Boolean
) {
    fun toWard(): Ward = Ward(
        id = wardId,
        lgaId = lgaId,
        wardCode = wardCode,
        name = name,
        coordinatorUid = coordinatorUid,
        coordinatorName = coordinatorName,
        expectedPollingUnits = expectedPollingUnits,
        isTestData = isTestData
    )

    companion object {
        fun fromWard(uid: String, w: Ward): CachedWardEntity = CachedWardEntity(
            cachedForUid = uid,
            wardId = w.id,
            lgaId = w.lgaId,
            wardCode = w.wardCode,
            name = w.name,
            coordinatorUid = w.coordinatorUid,
            coordinatorName = w.coordinatorName,
            expectedPollingUnits = w.expectedPollingUnits,
            isTestData = w.isTestData
        )
    }
}

@Entity(
    tableName = "cached_polling_units",
    primaryKeys = ["cachedForUid", "puId"]
)
data class CachedPollingUnitEntity(
    val cachedForUid: String,
    val puId: String,
    val lgaId: String,
    val wardId: String,
    val wardName: String,
    val puCode: String,
    val name: String,
    val locationDescription: String,
    val latitude: Double?,
    val longitude: Double?,
    val coordinatesVerified: Boolean,
    val assignedAgentUid: String,
    val assignedAgentName: String,
    val operationalStatus: String,
    val registeredVoters: Long,
    val puStatusLabel: String,
    val isMasterRecord: Boolean,
    val isTestData: Boolean
) {
    fun toPollingUnit(): PollingUnit = PollingUnit(
        id = puId,
        lgaId = lgaId,
        wardId = wardId,
        wardName = wardName,
        puCode = puCode,
        name = name,
        locationDescription = locationDescription,
        latitude = latitude,
        longitude = longitude,
        coordinatesVerified = coordinatesVerified,
        assignedAgentUid = assignedAgentUid,
        assignedAgentName = assignedAgentName,
        operationalStatus = operationalStatus.ifBlank { PuOperationalStatus.NOT_STARTED.name },
        registeredVoters = registeredVoters,
        puStatusLabel = puStatusLabel,
        isMasterRecord = isMasterRecord,
        isTestData = isTestData
    )

    companion object {
        fun fromPollingUnit(uid: String, pu: PollingUnit): CachedPollingUnitEntity = CachedPollingUnitEntity(
            cachedForUid = uid,
            puId = pu.id,
            lgaId = pu.lgaId,
            wardId = pu.wardId,
            wardName = pu.wardName,
            puCode = pu.puCode,
            name = pu.name,
            locationDescription = pu.locationDescription,
            latitude = pu.latitude,
            longitude = pu.longitude,
            coordinatesVerified = pu.coordinatesVerified,
            assignedAgentUid = pu.assignedAgentUid,
            assignedAgentName = pu.assignedAgentName,
            operationalStatus = pu.operationalStatus,
            registeredVoters = pu.registeredVoters,
            puStatusLabel = pu.puStatusLabel,
            isMasterRecord = pu.isMasterRecord,
            isTestData = pu.isTestData
        )
    }
}

@Dao
interface OfflineQueueDao {
    // User-isolated queries (Req H: prevent one user from seeing another user's private offline reports)
    @Query("SELECT * FROM offline_queue WHERE ownerUid = :ownerUid ORDER BY updatedAtMillis DESC")
    fun observeForUser(ownerUid: String): Flow<List<OfflineQueueEntity>>

    @Query("SELECT * FROM offline_queue ORDER BY updatedAtMillis DESC")
    fun observeAll(): Flow<List<OfflineQueueEntity>>

    @Query(
        "SELECT * FROM offline_queue WHERE ownerUid = :ownerUid AND isDraftEditable = 0 " +
            "AND syncStatus IN ('PENDING_SYNC', 'SYNCING', 'SYNC_FAILED', 'FAILED') " +
            "ORDER BY createdAtMillis ASC"
    )
    suspend fun getAllQueuedForSync(ownerUid: String): List<OfflineQueueEntity>

    @Query(
        "SELECT * FROM offline_queue WHERE isDraftEditable = 0 " +
            "AND syncStatus IN ('PENDING_SYNC', 'SYNCING', 'SYNC_FAILED', 'FAILED') " +
            "ORDER BY createdAtMillis ASC"
    )
    suspend fun getAllPending(): List<OfflineQueueEntity>

    @Query("SELECT * FROM offline_queue WHERE ownerUid = :ownerUid AND itemType = :itemType AND isDraftEditable = 1 ORDER BY updatedAtMillis DESC LIMIT 1")
    suspend fun getActiveDraft(ownerUid: String, itemType: String): OfflineQueueEntity?

    @Query("SELECT * FROM offline_queue WHERE clientSubmissionId = :id AND ownerUid = :ownerUid LIMIT 1")
    suspend fun getByIdForUser(id: String, ownerUid: String): OfflineQueueEntity?

    @Query("SELECT * FROM offline_queue WHERE clientSubmissionId = :id LIMIT 1")
    suspend fun getById(id: String): OfflineQueueEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: OfflineQueueEntity)

    @Query(
        "UPDATE offline_queue SET syncStatus = :status, lastError = :error, " +
            "retryCount = :retryCount, nextRetryAtMillis = :nextRetryAtMillis, " +
            "updatedAtMillis = :updatedAtMillis WHERE clientSubmissionId = :id"
    )
    suspend fun updateSyncAttemptState(
        id: String,
        status: String,
        error: String?,
        retryCount: Int,
        nextRetryAtMillis: Long,
        updatedAtMillis: Long = System.currentTimeMillis()
    )

    @Query(
        "UPDATE offline_queue SET syncStatus = :status, hasConflict = 1, conflictMessage = :conflictMessage, " +
            "lastError = :conflictMessage, updatedAtMillis = :updatedAtMillis WHERE clientSubmissionId = :id"
    )
    suspend fun markConflict(
        id: String,
        conflictMessage: String,
        status: String = OfflineSyncStatus.SYNC_FAILED.name,
        updatedAtMillis: Long = System.currentTimeMillis()
    )

    @Query(
        "UPDATE offline_queue SET syncStatus = :status, lastError = NULL, hasConflict = 0, conflictMessage = NULL, " +
            "serverDocId = :serverDocId, serverVerifiedAck = 1, syncedAtMillis = :syncedAtMillis, " +
            "updatedAtMillis = :syncedAtMillis WHERE clientSubmissionId = :id"
    )
    suspend fun markSyncedVerified(
        id: String,
        serverDocId: String,
        status: String = OfflineSyncStatus.SYNCED.name,
        syncedAtMillis: Long = System.currentTimeMillis()
    )

    @Query("UPDATE offline_queue SET syncStatus = :status, lastError = :error, retryCount = retryCount + 1 WHERE clientSubmissionId = :id")
    suspend fun markStatus(id: String, status: String, error: String?)

    @Query("UPDATE offline_queue SET syncStatus = :status, lastError = NULL, serverVerifiedAck = 1, syncedAtMillis = :syncedAtMillis WHERE clientSubmissionId = :id")
    suspend fun markSynced(id: String, status: String = OfflineSyncStatus.SYNCED.name, syncedAtMillis: Long = System.currentTimeMillis())

    @Query("UPDATE offline_queue SET syncStatus = :newStatus, updatedAtMillis = :updatedAtMillis WHERE clientSubmissionId = :id AND ownerUid = :ownerUid")
    suspend fun updateServerLifecycleStatus(id: String, ownerUid: String, newStatus: String, updatedAtMillis: Long = System.currentTimeMillis())

    // Retention Rule (Req E): only removes temporary queue visibility flag after confirmed receipt; history remains preserved!
    @Query("UPDATE offline_queue SET archivedFromQueue = 1 WHERE ownerUid = :ownerUid AND serverVerifiedAck = 1 AND syncStatus IN ('SYNCED', 'UNDER_REVIEW', 'VERIFIED')")
    suspend fun archiveConfirmedQueueEntries(ownerUid: String)

    @Query("DELETE FROM offline_queue WHERE syncStatus = 'SYNCED' AND serverVerifiedAck = 1 AND ownerUid = ''")
    suspend fun clearSynced()

    @Query("DELETE FROM offline_queue WHERE clientSubmissionId = :id AND ownerUid = :ownerUid AND isDraftEditable = 1")
    suspend fun discardEditableDraft(id: String, ownerUid: String)

    // --- ATTACHMENTS ---
    @Query("SELECT * FROM offline_attachments WHERE ownerUid = :ownerUid ORDER BY createdAtMillis DESC")
    fun observeAttachmentsForUser(ownerUid: String): Flow<List<OfflineAttachmentEntity>>

    @Query("SELECT * FROM offline_attachments WHERE reportId = :reportId AND ownerUid = :ownerUid")
    suspend fun getAttachmentsForReport(reportId: String, ownerUid: String): List<OfflineAttachmentEntity>

    @Query("SELECT * FROM offline_attachments WHERE ownerUid = :ownerUid AND uploadStatus != 'SYNCED' AND uploadStatus != 'SAVED_LOCALLY'")
    suspend fun getPendingAttachmentsForUser(ownerUid: String): List<OfflineAttachmentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAttachment(entity: OfflineAttachmentEntity)

    @Query("UPDATE offline_attachments SET uploadStatus = :status, lastError = :error, retryCount = retryCount + 1 WHERE attachmentId = :attachmentId")
    suspend fun markAttachmentFailed(attachmentId: String, status: String, error: String?)

    @Query("UPDATE offline_attachments SET uploadStatus = 'SYNCING', lastError = NULL WHERE attachmentId = :attachmentId")
    suspend fun markAttachmentSyncing(attachmentId: String)

    @Query("UPDATE offline_attachments SET uploadStatus = 'SYNCED', serverVerified = 1, lastError = NULL, uploadedAtMillis = :uploadedAtMillis WHERE attachmentId = :attachmentId")
    suspend fun markAttachmentVerified(attachmentId: String, uploadedAtMillis: Long = System.currentTimeMillis())

    @Query("UPDATE offline_attachments SET uploadStatus = 'PENDING_SYNC' WHERE reportId = :reportId AND ownerUid = :ownerUid AND uploadStatus = 'SAVED_LOCALLY'")
    suspend fun queueReportAttachments(reportId: String, ownerUid: String)

    // --- SYNC HISTORY ---
    @Query("SELECT * FROM sync_history WHERE ownerUid = :ownerUid ORDER BY timestampMillis DESC LIMIT 120")
    fun observeSyncHistory(ownerUid: String): Flow<List<SyncHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSyncHistory(entry: SyncHistoryEntity)

    // --- OFFLINE AUTH & SCOPED DIRECTORY CACHE ---
    @Query("SELECT * FROM cached_user_profiles WHERE uid = :uid LIMIT 1")
    suspend fun getCachedUser(uid: String): CachedUserProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCachedUser(user: CachedUserProfileEntity)

    @Query("DELETE FROM cached_user_profiles WHERE uid = :uid")
    suspend fun deleteCachedUser(uid: String)

    @Query("SELECT * FROM cached_wards WHERE cachedForUid = :uid")
    fun observeCachedWards(uid: String): Flow<List<CachedWardEntity>>

    @Query("SELECT * FROM cached_wards WHERE cachedForUid = :uid")
    suspend fun getCachedWards(uid: String): List<CachedWardEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCachedWards(wards: List<CachedWardEntity>)

    @Query("SELECT * FROM cached_polling_units WHERE cachedForUid = :uid")
    fun observeCachedPollingUnits(uid: String): Flow<List<CachedPollingUnitEntity>>

    @Query("SELECT * FROM cached_polling_units WHERE cachedForUid = :uid")
    suspend fun getCachedPollingUnits(uid: String): List<CachedPollingUnitEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCachedPollingUnits(pus: List<CachedPollingUnitEntity>)

    @Query("DELETE FROM cached_wards WHERE cachedForUid = :uid")
    suspend fun clearCachedWards(uid: String)

    @Query("DELETE FROM cached_polling_units WHERE cachedForUid = :uid")
    suspend fun clearCachedPollingUnits(uid: String)
}

@Database(
    entities = [
        OfflineQueueEntity::class,
        OfflineAttachmentEntity::class,
        SyncHistoryEntity::class,
        CachedUserProfileEntity::class,
        CachedWardEntity::class,
        CachedPollingUnitEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class FdmisDatabase : RoomDatabase() {
    abstract fun offlineQueueDao(): OfflineQueueDao

    companion object {
        @Volatile
        private var INSTANCE: FdmisDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE offline_queue ADD COLUMN syncedAtMillis INTEGER")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE offline_queue ADD COLUMN ownerUid TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE offline_queue ADD COLUMN ownerEmail TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE offline_queue ADD COLUMN lgaId TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE offline_queue ADD COLUMN wardId TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE offline_queue ADD COLUMN puId TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE offline_queue ADD COLUMN puCode TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE offline_queue ADD COLUMN puName TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE offline_queue ADD COLUMN isDraftEditable INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE offline_queue ADD COLUMN serverDocId TEXT")
                db.execSQL("ALTER TABLE offline_queue ADD COLUMN serverVerifiedAck INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE offline_queue ADD COLUMN serverVersion INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE offline_queue ADD COLUMN hasConflict INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE offline_queue ADD COLUMN conflictMessage TEXT")
                db.execSQL("ALTER TABLE offline_queue ADD COLUMN nextRetryAtMillis INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE offline_queue ADD COLUMN updatedAtMillis INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE offline_queue ADD COLUMN archivedFromQueue INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE offline_queue SET updatedAtMillis = createdAtMillis")
                db.execSQL("UPDATE offline_queue SET syncStatus = 'SAVED_LOCALLY' WHERE syncStatus = 'SAVED_OFFLINE'")
                db.execSQL("UPDATE offline_queue SET syncStatus = 'SYNC_FAILED' WHERE syncStatus = 'FAILED'")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_offline_queue_ownerUid ON offline_queue(ownerUid)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_offline_queue_syncStatus ON offline_queue(syncStatus)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_offline_queue_ownerUid_itemType_isDraftEditable ON offline_queue(ownerUid, itemType, isDraftEditable)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS offline_attachments (
                        attachmentId TEXT NOT NULL PRIMARY KEY,
                        reportId TEXT NOT NULL,
                        ownerUid TEXT NOT NULL,
                        reportType TEXT NOT NULL,
                        lgaId TEXT NOT NULL,
                        wardId TEXT NOT NULL,
                        puId TEXT NOT NULL,
                        fileName TEXT NOT NULL,
                        localFilePath TEXT NOT NULL,
                        sha256Hash TEXT NOT NULL,
                        sizeBytes INTEGER NOT NULL,
                        uploadStatus TEXT NOT NULL,
                        serverVerified INTEGER NOT NULL,
                        retryCount INTEGER NOT NULL,
                        lastError TEXT,
                        createdAtMillis INTEGER NOT NULL,
                        uploadedAtMillis INTEGER
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_offline_attachments_reportId ON offline_attachments(reportId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_offline_attachments_ownerUid ON offline_attachments(ownerUid)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_offline_attachments_uploadStatus ON offline_attachments(uploadStatus)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS sync_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        ownerUid TEXT NOT NULL,
                        reportId TEXT NOT NULL,
                        eventType TEXT NOT NULL,
                        status TEXT NOT NULL,
                        message TEXT NOT NULL,
                        timestampMillis INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_sync_history_ownerUid ON sync_history(ownerUid)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_sync_history_reportId ON sync_history(reportId)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS cached_user_profiles (
                        uid TEXT NOT NULL PRIMARY KEY,
                        email TEXT NOT NULL,
                        displayName TEXT NOT NULL,
                        phone TEXT,
                        role TEXT NOT NULL,
                        status TEXT NOT NULL,
                        assignedLgaId TEXT NOT NULL,
                        assignedWardId TEXT NOT NULL,
                        assignedPollingUnitId TEXT NOT NULL,
                        sessionRevoked INTEGER NOT NULL,
                        revokedReason TEXT,
                        cachedAtMillis INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS cached_wards (
                        cachedForUid TEXT NOT NULL,
                        wardId TEXT NOT NULL,
                        lgaId TEXT NOT NULL,
                        wardCode TEXT NOT NULL,
                        name TEXT NOT NULL,
                        coordinatorUid TEXT NOT NULL,
                        coordinatorName TEXT NOT NULL,
                        expectedPollingUnits INTEGER NOT NULL,
                        isTestData INTEGER NOT NULL,
                        PRIMARY KEY(cachedForUid, wardId)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS cached_polling_units (
                        cachedForUid TEXT NOT NULL,
                        puId TEXT NOT NULL,
                        lgaId TEXT NOT NULL,
                        wardId TEXT NOT NULL,
                        wardName TEXT NOT NULL,
                        puCode TEXT NOT NULL,
                        name TEXT NOT NULL,
                        locationDescription TEXT NOT NULL,
                        latitude REAL,
                        longitude REAL,
                        coordinatesVerified INTEGER NOT NULL,
                        assignedAgentUid TEXT NOT NULL,
                        assignedAgentName TEXT NOT NULL,
                        operationalStatus TEXT NOT NULL,
                        registeredVoters INTEGER NOT NULL,
                        puStatusLabel TEXT NOT NULL,
                        isMasterRecord INTEGER NOT NULL,
                        isTestData INTEGER NOT NULL,
                        PRIMARY KEY(cachedForUid, puId)
                    )
                    """.trimIndent()
                )
            }
        }

        fun getInstance(context: Context): FdmisDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    FdmisDatabase::class.java,
                    "fdmis_offline_queue.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
