package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.AuthRepository
import com.example.data.firebase.DirectoryRepository
import com.example.data.firebase.OfflineAttachmentDraft
import com.example.data.firebase.OperationsRepository
import com.example.data.local.CachedPollingUnitEntity
import com.example.data.local.CachedUserProfileEntity
import com.example.data.local.CachedWardEntity
import com.example.data.local.DirectoryValidationReport
import com.example.data.local.OfficialDirectoryCatalog
import com.example.data.local.OfficialDirectoryDataset
import com.example.data.local.OfflineAttachmentEntity
import com.example.data.local.OfflineItemType
import com.example.data.local.OfflineQueueDao
import com.example.data.local.OfflineQueueEntity
import com.example.data.local.OfflineSyncStatus
import com.example.data.local.SessionPreferences
import com.example.data.local.SyncHistoryEntity
import com.example.data.model.AccountStatus
import com.example.data.model.AgentCheckIn
import com.example.data.model.AuditLog
import com.example.data.model.DirectoryImportSummary
import com.example.data.model.GlobalSettings
import com.example.data.model.IncidentReport
import com.example.data.model.IncidentStatus
import com.example.data.model.IncidentUrgency
import com.example.data.model.LgaDefinition
import com.example.data.model.NotificationItem
import com.example.data.model.PollingUnit
import com.example.data.model.PublicVerifiedResult
import com.example.data.model.PuOperationalStatus
import com.example.data.model.ResultHistoryEntry
import com.example.data.model.ResultSubmission
import com.example.data.model.TimelineEvent
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.model.VerificationStatus
import com.example.data.model.Ward
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONObject

data class SituationMetrics(
    val totalLgas: Int = 2,
    val totalWardsRegistered: Int = 0,
    val totalPollingUnitsRegistered: Int = 0,
    val pollingUnitsReporting: Int = 0,
    val pollingUnitsNotReporting: Int = 0,
    val agentsAssigned: Int = 0,
    val agentsCheckedIn: Int = 0,
    val activeIncidents: Int = 0,
    val criticalIncidents: Int = 0,
    val pendingIncidentReviews: Int = 0,
    val resultsSubmitted: Int = 0,
    val resultsUnderReview: Int = 0,
    val resultsVerified: Int = 0,
    val resultsPendingVerification: Int = 0,
    val pusOutstandingSubmission: Int = 0
)

data class SyncDashboardMetrics(
    val savedLocallyCount: Int = 0,
    val pendingSyncCount: Int = 0,
    val syncingCount: Int = 0,
    val syncFailedCount: Int = 0,
    val syncedCount: Int = 0,
    val underReviewCount: Int = 0,
    val verifiedCount: Int = 0,
    val conflictCount: Int = 0,
    val lastSuccessfulSyncMillis: Long = 0L,
    val isOnline: Boolean = true,
    val backendReachable: Boolean = true
) {
    val outstandingSyncCount: Int
        get() = pendingSyncCount + syncingCount + syncFailedCount
}

data class OfflineReportEditRequest(
    val reportId: String,
    val itemType: OfflineItemType,
    val payloadJson: String,
    val attachments: List<OfflineAttachmentEntity>,
    val nonce: Long = System.currentTimeMillis()
)

data class AuthGateState(
    val isCheckingProfile: Boolean = true,
    val needsBootstrap: Boolean = false,
    val userAccount: UserAccount? = null,
    val errorMessage: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class FdmisViewModel(
    private val currentUserId: String,
    private val authRepo: AuthRepository,
    private val dirRepo: DirectoryRepository,
    private val opsRepo: OperationsRepository,
    private val offlineDao: OfflineQueueDao,
    private val sessionPrefs: SessionPreferences,
    private val officialDirectory: OfficialDirectoryDataset,
    private val onScheduleBackgroundSync: () -> Unit = {}
) : ViewModel() {

    val validationReport: DirectoryValidationReport = OfficialDirectoryCatalog.validate(officialDirectory)

    private val _authGate = MutableStateFlow(AuthGateState())
    val authGate: StateFlow<AuthGateState> = _authGate.asStateFlow()

    private val _selectedLgaFilter = MutableStateFlow<String?>(null)
    val selectedLgaFilter: StateFlow<String?> = _selectedLgaFilter.asStateFlow()

    private val _selectedWardFilter = MutableStateFlow<String?>(null)
    val selectedWardFilter: StateFlow<String?> = _selectedWardFilter.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _sessionExpiredByInactivity = MutableStateFlow(false)
    val sessionExpiredByInactivity: StateFlow<Boolean> = _sessionExpiredByInactivity.asStateFlow()

    private val _latestImportSummary = MutableStateFlow<DirectoryImportSummary?>(null)
    val latestImportSummary: StateFlow<DirectoryImportSummary?> = _latestImportSummary.asStateFlow()

    private val _isOnline = MutableStateFlow(true)
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    private val _backendReachable = MutableStateFlow(true)
    val backendReachable: StateFlow<Boolean> = _backendReachable.asStateFlow()

    private val _pendingEditRequest = MutableStateFlow<OfflineReportEditRequest?>(null)
    val pendingEditRequest: StateFlow<OfflineReportEditRequest?> = _pendingEditRequest.asStateFlow()

    private var lastInteractionMs = System.currentTimeMillis()
    private var attemptedAutoMasterSync = false
    private var triggeredLoginSync = false
    private var isSyncingQueue = false

    val showTestData: StateFlow<Boolean> = sessionPrefs.showTestData
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), false)

    val lastSuccessfulSyncMillis: StateFlow<Long> = sessionPrefs.observeLastSuccessfulSyncMillis(currentUserId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), 0L)

    val globalSettings: StateFlow<GlobalSettings> = authRepo.observeGlobalSettings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), GlobalSettings())

    val userAccount: StateFlow<UserAccount?> = authRepo.observeUserAccount(currentUserId)
        .catch { emit(null) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    // Combine live Firestore user with Room/AuthGate cached user so offline cold-starts still load directory & queue
    private val effectiveUserFlow: StateFlow<UserAccount?> = combine(userAccount, authGate) { live, gate ->
        live ?: gate.userAccount
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    private val cachedWardsFlow = offlineDao.observeCachedWards(currentUserId)
    private val cachedPusFlow = offlineDao.observeCachedPollingUnits(currentUserId)

    private val liveWardsFlow = effectiveUserFlow
        .flatMapLatest { u ->
            if (u != null && u.isAuthorizedActive) dirRepo.observeWards(u).catch { emit(emptyList()) }
            else flowOf(emptyList())
        }

    private val livePollingUnitsFlow = effectiveUserFlow
        .flatMapLatest { u ->
            if (u != null && u.isAuthorizedActive) dirRepo.observePollingUnits(u).catch { emit(emptyList()) }
            else flowOf(emptyList())
        }

    val wards: StateFlow<List<Ward>> = combine(
        liveWardsFlow,
        cachedWardsFlow,
        effectiveUserFlow
    ) { live, cached, u ->
        when {
            live.isNotEmpty() -> live
            cached.isNotEmpty() -> cached.map { it.toWard() }
            u != null && u.isAuthorizedActive -> {
                val lgaFilter = when (u.roleEnum) {
                    UserRole.FUNTUA_SUPER_ADMIN -> "funtua"
                    UserRole.DANDUME_SUPER_ADMIN -> "dandume"
                    UserRole.WARD_COORDINATOR, UserRole.POLLING_UNIT_AGENT -> u.assignedLgaId.takeIf { it.isNotBlank() }
                    else -> null
                }
                OfficialDirectoryCatalog.toScopedWards(officialDirectory, lgaFilter)
            }
            else -> emptyList()
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val pollingUnits: StateFlow<List<PollingUnit>> = combine(
        livePollingUnitsFlow,
        cachedPusFlow,
        effectiveUserFlow
    ) { live, cached, u ->
        when {
            live.isNotEmpty() -> live
            cached.isNotEmpty() -> cached.map { it.toPollingUnit() }
            u != null && u.isAuthorizedActive -> OfficialDirectoryCatalog.toScopedPollingUnits(officialDirectory, u)
            else -> emptyList()
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val managedUsers: StateFlow<List<UserAccount>> = effectiveUserFlow
        .flatMapLatest { u ->
            if (u != null && u.isAuthorizedActive) dirRepo.observeUsers(u).catch { emit(emptyList()) }
            else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val checkIns: StateFlow<List<AgentCheckIn>> = effectiveUserFlow
        .flatMapLatest { u ->
            if (u != null && u.isAuthorizedActive) opsRepo.observeCheckIns(u).catch { emit(emptyList()) }
            else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val incidents: StateFlow<List<IncidentReport>> = effectiveUserFlow
        .flatMapLatest { u ->
            if (u != null && u.isAuthorizedActive) opsRepo.observeIncidents(u).catch { emit(emptyList()) }
            else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val results: StateFlow<List<ResultSubmission>> = effectiveUserFlow
        .flatMapLatest { u ->
            if (u != null && u.isAuthorizedActive) opsRepo.observeResults(u).catch { emit(emptyList()) }
            else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val publicResults: StateFlow<List<PublicVerifiedResult>> = effectiveUserFlow
        .flatMapLatest { u ->
            if (u != null && u.isAuthorizedActive) opsRepo.observePublicResults().catch { emit(emptyList()) }
            else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val timeline: StateFlow<List<TimelineEvent>> = effectiveUserFlow
        .flatMapLatest { u ->
            if (u != null && u.isAuthorizedActive) opsRepo.observeTimeline(u).catch { emit(emptyList()) }
            else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val notifications: StateFlow<List<NotificationItem>> = effectiveUserFlow
        .flatMapLatest { u ->
            if (u != null && u.isAuthorizedActive) opsRepo.observeNotifications(u).catch { emit(emptyList()) }
            else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val auditLogs: StateFlow<List<AuditLog>> = effectiveUserFlow
        .flatMapLatest { u ->
            if (u != null && u.isAuthorizedActive && u.roleEnum.canViewAuditLogs()) {
                dirRepo.observeAuditLogs(u).catch { emit(emptyList()) }
            } else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    // Strict per-user isolation in local storage & UI
    val offlineQueue: StateFlow<List<OfflineQueueEntity>> = combine(
        offlineDao.observeForUser(currentUserId),
        results
    ) { localReports, serverResults ->
        val resultsById = serverResults.associateBy { it.id }
        val resultsByClientId = serverResults.filter { it.clientSubmissionId.isNotBlank() }.associateBy { it.clientSubmissionId }
        localReports.map { item ->
            val currentStatus = OfflineSyncStatus.fromString(item.syncStatus)
            if (item.itemType == OfflineItemType.RESULT_SUBMISSION.name && currentStatus.isSyncedWithServer()) {
                val matched = resultsById[item.serverDocId ?: item.clientSubmissionId]
                    ?: resultsByClientId[item.clientSubmissionId]
                val mappedStatus = when (matched?.verificationEnum) {
                    VerificationStatus.UNDER_REVIEW -> OfflineSyncStatus.UNDER_REVIEW.name
                    VerificationStatus.VERIFIED -> OfflineSyncStatus.VERIFIED.name
                    else -> currentStatus.name
                }
                if (mappedStatus != item.syncStatus) item.copy(syncStatus = mappedStatus) else item
            } else {
                item
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val offlineAttachments: StateFlow<List<OfflineAttachmentEntity>> =
        offlineDao.observeAttachmentsForUser(currentUserId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val syncHistory: StateFlow<List<SyncHistoryEntity>> =
        offlineDao.observeSyncHistory(currentUserId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val syncDashboardMetrics: StateFlow<SyncDashboardMetrics> = combine(
        offlineQueue,
        lastSuccessfulSyncMillis,
        isOnline,
        backendReachable
    ) { items, lastSync, online, reachable ->
        var savedLocally = 0
        var pendingSync = 0
        var syncing = 0
        var syncFailed = 0
        var synced = 0
        var underReview = 0
        var verified = 0
        var conflicts = 0

        items.forEach { item ->
            if (item.hasConflict) conflicts++
            when (OfflineSyncStatus.fromString(item.syncStatus)) {
                OfflineSyncStatus.SAVED_LOCALLY -> savedLocally++
                OfflineSyncStatus.PENDING_SYNC -> pendingSync++
                OfflineSyncStatus.SYNCING -> syncing++
                OfflineSyncStatus.SYNC_FAILED -> syncFailed++
                OfflineSyncStatus.SYNCED -> synced++
                OfflineSyncStatus.UNDER_REVIEW -> {
                    synced++
                    underReview++
                }
                OfflineSyncStatus.VERIFIED -> {
                    synced++
                    verified++
                }
            }
        }
        SyncDashboardMetrics(
            savedLocallyCount = savedLocally,
            pendingSyncCount = pendingSync,
            syncingCount = syncing,
            syncFailedCount = syncFailed,
            syncedCount = synced,
            underReviewCount = underReview,
            verifiedCount = verified,
            conflictCount = conflicts,
            lastSuccessfulSyncMillis = lastSync,
            isOnline = online,
            backendReachable = reachable
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), SyncDashboardMetrics())

    val metrics: StateFlow<SituationMetrics> = combine(
        wards,
        pollingUnits,
        checkIns,
        incidents,
        results,
        selectedLgaFilter,
        selectedWardFilter,
        showTestData
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val allWards = (values[0] as List<Ward>).filter { values[7] as Boolean || !it.isTestData }
        @Suppress("UNCHECKED_CAST")
        val allPus = (values[1] as List<PollingUnit>).filter { values[7] as Boolean || !it.isTestData }
        @Suppress("UNCHECKED_CAST")
        val allCheckIns = (values[2] as List<AgentCheckIn>).filter { values[7] as Boolean || !it.isTestData }
        @Suppress("UNCHECKED_CAST")
        val allIncidents = (values[3] as List<IncidentReport>).filter { values[7] as Boolean || !it.isTestData }
        @Suppress("UNCHECKED_CAST")
        val allResults = (values[4] as List<ResultSubmission>).filter { values[7] as Boolean || !it.isTestData }
        val lga = values[5] as String?
        val ward = values[6] as String?

        val fWards = allWards.filter { lga == null || it.lgaId == lga }
        val fPus = allPus.filter { (lga == null || it.lgaId == lga) && (ward == null || it.wardId == ward) }
        val fCheckIns = allCheckIns.filter { (lga == null || it.lgaId == lga) && (ward == null || it.wardId == ward) }
        val fIncidents = allIncidents.filter { (lga == null || it.lgaId == lga) && (ward == null || it.wardId == ward) }
        val fResults = allResults.filter { (lga == null || it.lgaId == lga) && (ward == null || it.wardId == ward) }

        val reporting = fPus.count { it.statusEnum.isReporting() }
        val checkedInAgentUids = fCheckIns.map { it.agentUid }.distinct().size
        val verifiedCount = fResults.count { it.verificationStatus == VerificationStatus.VERIFIED.name }
        val underReviewCount = fResults.count { it.verificationStatus == VerificationStatus.UNDER_REVIEW.name }
        val pendingVerificationCount = fResults.count {
            it.verificationStatus == VerificationStatus.SUBMITTED.name ||
                it.verificationStatus == VerificationStatus.UNDER_REVIEW.name ||
                it.verificationStatus == VerificationStatus.REQUIRES_CORRECTION.name
        }
        val submittedPuIds = fResults.map { it.puId }.toSet()
        val outstanding = fPus.count { it.id !in submittedPuIds }

        SituationMetrics(
            totalLgas = if (lga == null) LgaDefinition.entries.size else 1,
            totalWardsRegistered = fWards.size,
            totalPollingUnitsRegistered = fPus.size,
            pollingUnitsReporting = reporting,
            pollingUnitsNotReporting = (fPus.size - reporting).coerceAtLeast(0),
            agentsAssigned = fPus.count { it.assignedAgentUid.isNotBlank() },
            agentsCheckedIn = checkedInAgentUids,
            activeIncidents = fIncidents.count { it.statusEnum.isActive() },
            criticalIncidents = fIncidents.count { it.statusEnum.isActive() && it.urgency == IncidentUrgency.CRITICAL.name },
            pendingIncidentReviews = fIncidents.count { it.status == IncidentStatus.NEW.name },
            resultsSubmitted = fResults.size,
            resultsUnderReview = underReviewCount,
            resultsVerified = verifiedCount,
            resultsPendingVerification = pendingVerificationCount,
            pusOutstandingSubmission = outstanding
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), SituationMetrics())

    init {
        refreshUserProfile()

        // Cache active user profile + sync on login
        viewModelScope.launch {
            effectiveUserFlow.collect { account ->
                if (account != null) {
                    runCatching { offlineDao.upsertCachedUser(CachedUserProfileEntity.fromUserAccount(account)) }
                    if (account.roleEnum == UserRole.FUNTUA_SUPER_ADMIN) {
                        _selectedLgaFilter.value = LgaDefinition.FUNTUA.id
                    } else if (account.roleEnum == UserRole.DANDUME_SUPER_ADMIN) {
                        _selectedLgaFilter.value = LgaDefinition.DANDUME.id
                    }
                    _authGate.value = AuthGateState(
                        isCheckingProfile = false,
                        needsBootstrap = false,
                        userAccount = account
                    )
                    if (account.isAuthorizedActive) {
                        if (account.roleEnum == UserRole.FULL_CONTROL_ADMIN && !attemptedAutoMasterSync && _isOnline.value) {
                            attemptedAutoMasterSync = true
                            importMasterDirectory(silentIfAlreadySynced = true)
                        }
                        if (!triggeredLoginSync) {
                            triggeredLoginSync = true
                            syncOfflineQueueNow(silentIfEmpty = true, forceRetry = false)
                        }
                    }
                }
            }
        }

        // Persist scoped wards offline in Room whenever live snapshot updates
        viewModelScope.launch {
            liveWardsFlow.collect { liveList ->
                if (liveList.isNotEmpty()) {
                    runCatching {
                        offlineDao.clearCachedWards(currentUserId)
                        offlineDao.insertCachedWards(liveList.map { CachedWardEntity.fromWard(currentUserId, it) })
                    }
                }
            }
        }

        // Persist scoped polling units offline in Room whenever live snapshot updates
        viewModelScope.launch {
            livePollingUnitsFlow.collect { liveList ->
                if (liveList.isNotEmpty()) {
                    runCatching {
                        offlineDao.clearCachedPollingUnits(currentUserId)
                        offlineDao.insertCachedPollingUnits(liveList.map { CachedPollingUnitEntity.fromPollingUnit(currentUserId, it) })
                    }
                }
            }
        }

        // Inactivity monitor + periodic exponential backoff retry ticker
        viewModelScope.launch {
            while (true) {
                delay(20_000L)
                val actor = effectiveUserFlow.value
                val timeoutMinutes = globalSettings.value.inactivityTimeoutMinutes.coerceAtLeast(5L)
                val elapsedMinutes = (System.currentTimeMillis() - lastInteractionMs) / 60_000L
                if (actor?.isAuthorizedActive == true && elapsedMinutes >= timeoutMinutes) {
                    _sessionExpiredByInactivity.value = true
                }
                val now = System.currentTimeMillis()
                val dueForRetry = offlineQueue.value.any { item ->
                    val status = OfflineSyncStatus.fromString(item.syncStatus)
                    !item.isDraftEditable && !item.hasConflict &&
                        (status == OfflineSyncStatus.PENDING_SYNC ||
                            (status == OfflineSyncStatus.SYNC_FAILED && item.nextRetryAtMillis <= now))
                } || offlineAttachments.value.any {
                    it.uploadStatus == OfflineSyncStatus.PENDING_SYNC.name ||
                        it.uploadStatus == OfflineSyncStatus.SYNC_FAILED.name
                }
                if (dueForRetry && actor?.isAuthorizedActive == true && _isOnline.value && !isSyncingQueue) {
                    syncOfflineQueueNow(silentIfEmpty = true, forceRetry = false)
                }
            }
        }
    }

    fun recordUserInteraction() {
        lastInteractionMs = System.currentTimeMillis()
    }

    fun onNetworkConnectivityChanged(online: Boolean) {
        val wasOffline = !_isOnline.value
        _isOnline.value = online
        if (!online) {
            _backendReachable.value = false
            return
        }
        val actor = effectiveUserFlow.value
        if (actor?.isAuthorizedActive == true && (wasOffline || !isSyncingQueue)) {
            syncOfflineQueueNow(silentIfEmpty = true, forceRetry = true)
        }
    }

    fun onAppResumed() {
        recordUserInteraction()
        if (effectiveUserFlow.value?.isAuthorizedActive == true && !isSyncingQueue) {
            syncOfflineQueueNow(silentIfEmpty = true, forceRetry = false)
        }
    }

    fun refreshUserProfile() {
        viewModelScope.launch {
            _authGate.value = _authGate.value.copy(isCheckingProfile = true, errorMessage = null)
            val res = authRepo.ensureUserProfileOrCheckBootstrap()
            res.fold(
                onSuccess = { account ->
                    _authGate.value = AuthGateState(
                        isCheckingProfile = false,
                        needsBootstrap = account == null,
                        userAccount = account
                    )
                },
                onFailure = { err ->
                    val cached = runCatching { offlineDao.getCachedUser(currentUserId)?.toUserAccount() }.getOrNull()
                    if (cached != null) {
                        _authGate.value = AuthGateState(
                            isCheckingProfile = false,
                            needsBootstrap = false,
                            userAccount = cached
                        )
                    } else {
                        _authGate.value = AuthGateState(
                            isCheckingProfile = false,
                            needsBootstrap = false,
                            userAccount = null,
                            errorMessage = err.localizedMessage ?: "Failed to verify profile"
                        )
                    }
                }
            )
        }
    }

    fun initializeFullControlAdmin(displayName: String, phone: String?) {
        viewModelScope.launch {
            _authGate.value = _authGate.value.copy(isCheckingProfile = true, errorMessage = null)
            authRepo.initializeFullControlAdmin(displayName, phone).fold(
                onSuccess = { account ->
                    _authGate.value = AuthGateState(
                        isCheckingProfile = false,
                        needsBootstrap = false,
                        userAccount = account
                    )
                },
                onFailure = { err ->
                    _authGate.value = _authGate.value.copy(
                        isCheckingProfile = false,
                        errorMessage = err.localizedMessage ?: "Admin initialization failed"
                    )
                }
            )
        }
    }

    fun registerPendingAccount(displayName: String, phone: String?) {
        viewModelScope.launch {
            _authGate.value = _authGate.value.copy(isCheckingProfile = true, errorMessage = null)
            authRepo.registerPendingAccount(displayName, phone).fold(
                onSuccess = { account ->
                    _authGate.value = AuthGateState(
                        isCheckingProfile = false,
                        needsBootstrap = false,
                        userAccount = account
                    )
                },
                onFailure = { err ->
                    _authGate.value = _authGate.value.copy(
                        isCheckingProfile = false,
                        errorMessage = err.localizedMessage ?: "Registration failed"
                    )
                }
            )
        }
    }

    fun setLgaFilter(lgaId: String?) {
        recordUserInteraction()
        _selectedLgaFilter.value = lgaId
        _selectedWardFilter.value = null
    }

    fun setWardFilter(wardId: String?) {
        recordUserInteraction()
        _selectedWardFilter.value = wardId
    }

    fun toggleShowTestData(enabled: Boolean) {
        viewModelScope.launch { sessionPrefs.setShowTestData(enabled) }
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun showMessage(msg: String) {
        _snackbarMessage.value = msg
    }

    fun clearPendingEditRequest() {
        _pendingEditRequest.value = null
    }

    fun openOfflineReportForEditing(entity: OfflineQueueEntity) {
        recordUserInteraction()
        viewModelScope.launch {
            val type = OfflineItemType.valueOf(entity.itemType)
            val attachments = offlineDao.getAttachmentsForReport(entity.clientSubmissionId, currentUserId)
            _pendingEditRequest.value = OfflineReportEditRequest(
                reportId = entity.clientSubmissionId,
                itemType = type,
                payloadJson = entity.payloadJson,
                attachments = attachments
            )
        }
    }

    fun importMasterDirectory(silentIfAlreadySynced: Boolean = false) {
        val actor = effectiveUserFlow.value ?: return
        viewModelScope.launch {
            _isBusy.value = true
            dirRepo.importPreloadedOfficialDirectory(actor, officialDirectory).fold(
                onSuccess = { summary ->
                    _latestImportSummary.value = summary
                    if (!silentIfAlreadySynced || summary.totalNewlyImported > 0) {
                        _snackbarMessage.value = "Master Directory verified: ${summary.funtuaVerifiedInDatabase} Funtua + ${summary.dandumeVerifiedInDatabase} Dandume = ${summary.totalVerifiedInDatabase} PUs (+${summary.totalNewlyImported} imported)"
                    }
                },
                onFailure = { err ->
                    if (!silentIfAlreadySynced) {
                        _snackbarMessage.value = err.localizedMessage ?: "Master directory verification failed"
                    }
                }
            )
            _isBusy.value = false
        }
    }

    fun correctMasterPollingUnit(
        pu: PollingUnit,
        correctedName: String,
        correctedLocation: String,
        lat: Double?,
        lng: Double?,
        coordsVerified: Boolean,
        registeredVoters: Long,
        reason: String
    ) {
        val actor = effectiveUserFlow.value ?: return
        runBusy("Backup saved & master record ${pu.puCode} corrected") {
            dirRepo.correctMasterPollingUnit(
                actor = actor,
                pu = pu,
                correctedName = correctedName,
                correctedLocation = correctedLocation,
                latitude = lat,
                longitude = lng,
                coordinatesVerified = coordsVerified,
                registeredVoters = registeredVoters,
                reason = reason
            )
        }
    }

    fun assignAgentToPu(pu: PollingUnit, agent: UserAccount) {
        val actor = effectiveUserFlow.value ?: return
        runBusy("Assigned ${agent.displayName} to ${pu.puCode}") {
            dirRepo.assignAgentToPollingUnit(actor, pu, agent)
        }
    }

    fun updateUserRoleAndScope(
        target: UserAccount,
        newRole: UserRole,
        newStatus: AccountStatus,
        lgaId: String,
        wardId: String,
        puId: String
    ) {
        val actor = effectiveUserFlow.value ?: return
        runBusy("Updated permissions for ${target.displayName}") {
            dirRepo.updateUserRoleAndScope(actor, target, newRole, newStatus, lgaId, wardId, puId)
        }
    }

    fun revokeUserEmergency(target: UserAccount, reason: String) {
        val actor = effectiveUserFlow.value ?: return
        runBusy("Emergency access revocation executed for ${target.displayName}") {
            dirRepo.revokeUserAccessEmergency(actor, target, reason)
        }
    }

    // --- AUTO-SAVE DRAFTS & OFFLINE-FIRST SUBMISSIONS (ALL 4 TYPES) ---
    fun autoSaveCheckInDraft(
        reportId: String,
        pu: PollingUnit?,
        arrivalTime: String,
        comments: String,
        latitude: Double?,
        longitude: Double?
    ) {
        val actor = effectiveUserFlow.value ?: return
        if (pu == null && comments.isBlank()) return
        viewModelScope.launch {
            val json = JSONObject().apply {
                put("puId", pu?.id ?: "")
                put("puCode", pu?.puCode ?: "")
                put("puName", pu?.name ?: "")
                put("lgaId", pu?.lgaId ?: actor.assignedLgaId)
                put("wardId", pu?.wardId ?: actor.assignedWardId)
                put("isTestData", pu?.isTestData ?: false)
                put("arrivalTimeText", arrivalTime)
                put("comments", comments)
                if (latitude != null) put("latitude", latitude)
                if (longitude != null) put("longitude", longitude)
            }
            opsRepo.saveOfflineDraft(
                actor = actor,
                reportId = reportId,
                itemType = OfflineItemType.CHECK_IN,
                lgaId = pu?.lgaId ?: actor.assignedLgaId,
                wardId = pu?.wardId ?: actor.assignedWardId,
                pu = pu,
                title = "Draft Check-In · ${pu?.puCode ?: "Unassigned"}",
                subtitle = "$arrivalTime · ${comments.ifBlank { pu?.name ?: "In progress" }}",
                payloadJson = json
            )
        }
    }

    fun submitCheckIn(
        pu: PollingUnit,
        arrivalTime: String,
        comments: String,
        batteryPercent: Int,
        networkStatus: String,
        isOnlineNow: Boolean,
        lat: Double?,
        lng: Double?,
        existingReportId: String? = null
    ) {
        val actor = effectiveUserFlow.value ?: return
        recordUserInteraction()
        viewModelScope.launch {
            _isBusy.value = true
            val id = if (existingReportId.isNullOrBlank()) {
                opsRepo.enqueueCheckInOfflineFirst(
                    actor = actor,
                    pu = pu,
                    arrivalTimeText = arrivalTime,
                    comments = comments,
                    batteryPercent = batteryPercent,
                    networkStatus = networkStatus,
                    latitude = lat,
                    longitude = lng
                )
            } else {
                opsRepo.enqueueCheckInOfflineFirst(
                    actor = actor,
                    pu = pu,
                    arrivalTimeText = arrivalTime,
                    comments = comments,
                    batteryPercent = batteryPercent,
                    networkStatus = networkStatus,
                    latitude = lat,
                    longitude = lng,
                    reportId = existingReportId
                )
            }
            onScheduleBackgroundSync()
            if (isOnlineNow) {
                val summary = syncQueueLocked(actor, forceRetry = true)
                _snackbarMessage.value = when {
                    !summary.backendReachable -> "Saved locally ($id); queued until server is reachable"
                    summary.syncedCount > 0 -> "Check-in synced & confirmed (kept in local history)"
                    else -> "Saved locally; queued for retry"
                }
            } else {
                _snackbarMessage.value = "Saved locally ($id): Check-in queued for automatic sync"
            }
            _isBusy.value = false
        }
    }

    fun updatePuStatus(pu: PollingUnit, status: PuOperationalStatus) {
        val actor = effectiveUserFlow.value ?: return
        recordUserInteraction()
        viewModelScope.launch {
            _isBusy.value = true
            opsRepo.enqueueStatusUpdateOfflineFirst(
                actor = actor,
                pu = pu,
                newStatus = status
            )
            onScheduleBackgroundSync()
            if (_isOnline.value) {
                val summary = syncQueueLocked(actor, forceRetry = true)
                _snackbarMessage.value = when {
                    !summary.backendReachable -> "Saved locally: Status update queued until server returns"
                    summary.conflictCount > 0 -> "Conflict protection triggered: Check Sync Dashboard"
                    summary.syncedCount > 0 -> "${pu.puCode} updated to ${status.label} & synced"
                    else -> "Saved locally: Status update queued for retry"
                }
            } else {
                _snackbarMessage.value = "Saved locally: ${pu.puCode} -> ${status.label} queued for sync"
            }
            _isBusy.value = false
        }
    }

    fun autoSaveIncidentDraft(
        reportId: String,
        pu: PollingUnit?,
        lgaId: String,
        wardId: String,
        title: String,
        category: String,
        description: String,
        urgency: IncidentUrgency,
        attachmentDraft: OfflineAttachmentDraft?
    ) {
        val actor = effectiveUserFlow.value ?: return
        if (title.isBlank() && description.isBlank() && attachmentDraft == null) return
        viewModelScope.launch {
            val json = JSONObject().apply {
                put("puId", pu?.id ?: "")
                put("puCode", pu?.puCode ?: "WARD-LEVEL")
                put("puName", pu?.name ?: "Ward / LGA Level")
                put("lgaId", pu?.lgaId ?: lgaId)
                put("wardId", pu?.wardId ?: wardId)
                put("isTestData", pu?.isTestData ?: false)
                put("title", title)
                put("category", category)
                put("description", description)
                put("urgency", urgency.name)
                if (attachmentDraft != null) put("evidenceFileName", attachmentDraft.fileName)
            }
            opsRepo.saveOfflineDraft(
                actor = actor,
                reportId = reportId,
                itemType = OfflineItemType.INCIDENT_REPORT,
                lgaId = pu?.lgaId ?: lgaId,
                wardId = pu?.wardId ?: wardId,
                pu = pu,
                title = "Draft Incident · ${title.ifBlank { category }}",
                subtitle = pu?.puCode ?: lgaId.uppercase(),
                payloadJson = json,
                attachmentDraft = attachmentDraft
            )
        }
    }

    fun submitIncident(
        pu: PollingUnit?,
        lgaId: String,
        wardId: String,
        title: String,
        category: String,
        description: String,
        urgency: IncidentUrgency,
        evidenceBase64: String?,
        evidenceFileName: String?,
        isOnlineNow: Boolean,
        attachmentDraft: OfflineAttachmentDraft? = null,
        existingReportId: String? = null
    ) {
        val actor = effectiveUserFlow.value ?: return
        recordUserInteraction()
        viewModelScope.launch {
            _isBusy.value = true
            val id = if (existingReportId.isNullOrBlank()) {
                opsRepo.enqueueIncidentOfflineFirst(
                    actor = actor,
                    pu = pu,
                    lgaId = lgaId,
                    wardId = wardId,
                    title = title,
                    category = category,
                    description = description,
                    urgency = urgency,
                    evidenceBase64 = evidenceBase64,
                    evidenceFileName = evidenceFileName,
                    attachmentDraft = attachmentDraft
                )
            } else {
                opsRepo.enqueueIncidentOfflineFirst(
                    actor = actor,
                    pu = pu,
                    lgaId = lgaId,
                    wardId = wardId,
                    title = title,
                    category = category,
                    description = description,
                    urgency = urgency,
                    evidenceBase64 = evidenceBase64,
                    evidenceFileName = evidenceFileName,
                    attachmentDraft = attachmentDraft,
                    reportId = existingReportId
                )
            }
            onScheduleBackgroundSync()
            if (isOnlineNow) {
                val summary = syncQueueLocked(actor, forceRetry = true)
                _snackbarMessage.value = when {
                    !summary.backendReachable -> "Incident saved locally ($id); queued until server is reachable"
                    summary.syncedCount > 0 && summary.attachmentRetryPendingCount == 0 ->
                        "Incident submitted & confirmed (retained in local history)"
                    summary.syncedCount > 0 ->
                        "Incident synced; photo attachment queued for retry"
                    else -> "Saved locally ($id); queued for automatic retry"
                }
            } else {
                _snackbarMessage.value = "Saved locally ($id): Incident & evidence queued for auto-sync"
            }
            _isBusy.value = false
        }
    }

    fun updateIncidentWorkflow(
        incident: IncidentReport,
        newStatus: IncidentStatus,
        internalNotes: String,
        escalatedTo: String
    ) {
        val actor = effectiveUserFlow.value ?: return
        runBusy("Incident updated to ${newStatus.label}") {
            opsRepo.updateIncidentWorkflow(actor, incident, newStatus, internalNotes, escalatedTo)
        }
    }

    fun autoSaveResultDraft(
        reportId: String,
        pu: PollingUnit?,
        registered: Long,
        accredited: Long,
        valid: Long,
        rejected: Long,
        bvasStatus: String,
        bvasNotes: String,
        submissionNotes: String,
        existingSubmission: ResultSubmission?,
        attachmentDraft: OfflineAttachmentDraft?
    ) {
        val actor = effectiveUserFlow.value ?: return
        if (pu == null) return
        if (accredited == 0L && valid == 0L && bvasNotes.isBlank() && submissionNotes.isBlank() && attachmentDraft == null) {
            return
        }
        viewModelScope.launch {
            val json = JSONObject().apply {
                put("puId", pu.id)
                put("puCode", pu.puCode)
                put("puName", pu.name)
                put("lgaId", pu.lgaId)
                put("wardId", pu.wardId)
                put("wardName", pu.wardName)
                put("isTestData", pu.isTestData)
                put("registeredVoters", registered)
                put("accreditedVoters", accredited)
                put("validVotes", valid)
                put("rejectedVotes", rejected)
                put("bvasStatus", bvasStatus)
                put("bvasNotes", bvasNotes)
                put("submissionNotes", submissionNotes)
                put("existingSubmissionId", existingSubmission?.id ?: "")
                put("expectedVersion", (existingSubmission?.version ?: 0L) + 1L)
                if (attachmentDraft != null) put("ec8aFileName", attachmentDraft.fileName)
            }
            opsRepo.saveOfflineDraft(
                actor = actor,
                reportId = reportId,
                itemType = OfflineItemType.RESULT_SUBMISSION,
                lgaId = pu.lgaId,
                wardId = pu.wardId,
                pu = pu,
                title = "Draft Form EC8A · ${pu.puCode}",
                subtitle = "Accr: $accredited · Valid: $valid",
                payloadJson = json,
                attachmentDraft = attachmentDraft
            )
        }
    }

    fun submitResult(
        pu: PollingUnit,
        registered: Long,
        accredited: Long,
        valid: Long,
        rejected: Long,
        bvasStatus: String,
        bvasNotes: String,
        submissionNotes: String,
        ec8aBase64: String?,
        ec8aFileName: String?,
        existing: ResultSubmission?,
        attachmentDraft: OfflineAttachmentDraft? = null,
        existingReportId: String? = null
    ) {
        val actor = effectiveUserFlow.value ?: return
        recordUserInteraction()
        viewModelScope.launch {
            _isBusy.value = true
            val id = if (existingReportId.isNullOrBlank()) {
                opsRepo.enqueueResultOfflineFirst(
                    actor = actor,
                    pu = pu,
                    registeredVoters = registered,
                    accreditedVoters = accredited,
                    validVotes = valid,
                    rejectedVotes = rejected,
                    bvasStatus = bvasStatus,
                    bvasNotes = bvasNotes,
                    submissionNotes = submissionNotes,
                    ec8aImageBase64 = ec8aBase64,
                    ec8aFileName = ec8aFileName,
                    attachmentDraft = attachmentDraft,
                    existingSubmission = existing
                )
            } else {
                opsRepo.enqueueResultOfflineFirst(
                    actor = actor,
                    pu = pu,
                    registeredVoters = registered,
                    accreditedVoters = accredited,
                    validVotes = valid,
                    rejectedVotes = rejected,
                    bvasStatus = bvasStatus,
                    bvasNotes = bvasNotes,
                    submissionNotes = submissionNotes,
                    ec8aImageBase64 = ec8aBase64,
                    ec8aFileName = ec8aFileName,
                    attachmentDraft = attachmentDraft,
                    existingSubmission = existing,
                    reportId = existingReportId
                )
            }
            onScheduleBackgroundSync()
            if (_isOnline.value) {
                val summary = syncQueueLocked(actor, forceRetry = true)
                _snackbarMessage.value = when {
                    !summary.backendReachable -> "Result saved locally ($id); queued until server is reachable"
                    summary.conflictCount > 0 -> "Conflict detected on ${pu.puCode}: Server verified record preserved"
                    summary.syncedCount > 0 && summary.attachmentRetryPendingCount == 0 ->
                        "Result submitted & verified for ${pu.puCode} (retained locally)"
                    summary.syncedCount > 0 ->
                        "Result synced for ${pu.puCode}; Form EC8A photo queued for retry"
                    else -> "Saved locally ($id); result queued for automatic sync"
                }
            } else {
                _snackbarMessage.value = "Saved locally ($id): Form EC8A result queued for automatic sync"
            }
            _isBusy.value = false
        }
    }

    fun reviewResult(
        submission: ResultSubmission,
        newStatus: VerificationStatus,
        reviewNote: String,
        publishToPublic: Boolean
    ) {
        val actor = effectiveUserFlow.value ?: return
        runBusy("Result ${newStatus.label} for ${submission.puCode}") {
            opsRepo.reviewResultSubmission(actor, submission, newStatus, reviewNote, publishToPublic)
        }
    }

    suspend fun loadResultHistory(resultId: String): List<ResultHistoryEntry> =
        opsRepo.getResultHistory(resultId).getOrElse { emptyList() }

    fun syncOfflineQueueNow(silentIfEmpty: Boolean = false, forceRetry: Boolean = true) {
        val actor = effectiveUserFlow.value ?: return
        if (isSyncingQueue) return
        viewModelScope.launch {
            _isBusy.value = true
            val summary = syncQueueLocked(actor, forceRetry = forceRetry)
            if (!silentIfEmpty || summary.syncedCount > 0 || summary.failedCount > 0) {
                _snackbarMessage.value = when {
                    !summary.backendReachable -> "Backend unreachable right now; local data safely preserved"
                    summary.conflictCount > 0 ->
                        "Synced ${summary.syncedCount}; ${summary.conflictCount} conflict(s) flagged without overwriting server"
                    summary.syncedCount == 0 && summary.failedCount == 0 && summary.attachmentRetryPendingCount == 0 ->
                        "All local submissions & attachments are up to date"
                    summary.failedCount == 0 && summary.attachmentRetryPendingCount == 0 ->
                        "Synced & server-verified ${summary.syncedCount} report(s)"
                    else ->
                        "Synced ${summary.syncedCount}; ${summary.failedCount} report(s) & ${summary.attachmentRetryPendingCount} photo(s) queued for retry"
                }
            }
            _isBusy.value = false
        }
    }

    private suspend fun syncQueueLocked(
        actor: UserAccount,
        forceRetry: Boolean
    ): com.example.data.firebase.SyncBatchSummary {
        isSyncingQueue = true
        return try {
            val puMap = pollingUnits.value.associateBy { it.id }
            val resultsMap = results.value.associateBy { it.id }
            val summary = opsRepo.syncPendingOfflineQueueDetailed(
                actor = actor,
                pollingUnitsById = puMap,
                resultsById = resultsMap,
                forceRetryIgnoredBackoff = forceRetry
            )
            _backendReachable.value = summary.backendReachable
            if (summary.backendReachable && (summary.syncedCount > 0 || (summary.failedCount == 0 && summary.attachmentRetryPendingCount == 0))) {
                sessionPrefs.recordSuccessfulSync(currentUserId)
            }
            summary
        } finally {
            isSyncingQueue = false
        }
    }

    fun archiveConfirmedQueueEntries() {
        viewModelScope.launch {
            opsRepo.archiveConfirmedQueueEntries(currentUserId)
            _snackbarMessage.value = "Confirmed items archived from active queue (submission history preserved)"
        }
    }

    fun clearSyncedOfflineHistory() {
        archiveConfirmedQueueEntries()
    }

    fun postAnnouncement(title: String, body: String, targetLgaId: String, isCritical: Boolean) {
        val actor = effectiveUserFlow.value ?: return
        runBusy("Notification dispatched") {
            opsRepo.postAnnouncement(actor, title, body, targetLgaId, isCritical)
        }
    }

    fun updateGlobalSettings(settings: GlobalSettings) {
        val actor = effectiveUserFlow.value ?: return
        runBusy("System settings saved") {
            opsRepo.updateGlobalSettings(actor, settings)
        }
    }

    private fun runBusy(successMsg: String, block: suspend () -> Result<*>) {
        recordUserInteraction()
        viewModelScope.launch {
            _isBusy.value = true
            block().fold(
                onSuccess = { _snackbarMessage.value = successMsg },
                onFailure = { err -> _snackbarMessage.value = err.localizedMessage ?: "Operation failed" }
            )
            _isBusy.value = false
        }
    }
}
