package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.data.firebase.onGoogleSignInClicked
import com.example.data.model.AccountStatus
import com.example.data.model.UserAccount
import com.example.ui.theme.AlertCritical
import com.example.ui.theme.AlertCriticalContainer
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CivicGold
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.WhiteBackground

@Composable
fun AuthGateScreen(
    isSignedIn: Boolean,
    isCheckingProfile: Boolean,
    needsBootstrap: Boolean,
    userAccount: UserAccount?,
    errorMessage: String?,
    onAuthSuccess: () -> Unit,
    onInitializeAdmin: (String, String?) -> Unit,
    onRegisterPending: (String, String?) -> Unit,
    onRefreshProfile: () -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    var isSigningIn by remember { mutableStateOf(false) }
    var localError by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(WhiteBackground)
            .systemBarsPadding()
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Institutional Command Crest
            Image(
                painter = painterResource(id = R.drawable.ic_launcher_art),
                contentDescription = "FDMIS Situation Room Emblem",
                modifier = Modifier
                    .size(84.dp)
                    .clip(RoundedCornerShape(20.dp)),
                contentScale = ContentScale.Crop
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "FDMIS SITUATION ROOM",
                    style = MonoCodeStyle,
                    color = EmeraldPrimary
                )
                Text(
                    text = "Funtua–Dandume Mandate Intelligence System",
                    style = MaterialTheme.typography.headlineMedium,
                    color = EmeraldDeep,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Katsina State · 2027 Election Cycle Monitoring & Field Operations",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondaryLight,
                    textAlign = TextAlign.Center
                )
            }

            if (isCheckingProfile) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator()
                        Text("Verifying authorization & session status...", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            } else if (!isSignedIn) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Filled.Lock, contentDescription = null, tint = EmeraldPrimary)
                            Text("Authorized Access Only", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
                        }
                        Text(
                            text = "Sign in with your authorized Google account. All field reports, check-ins, and verification actions are role-restricted and recorded in the security audit trail.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondaryLight
                        )

                        val displayedError = localError ?: errorMessage
                        if (!displayedError.isNullOrBlank()) {
                            Surface(
                                color = AlertCriticalContainer,
                                contentColor = AlertCritical,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = displayedError,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }

                        Button(
                            onClick = {
                                localError = null
                                isSigningIn = true
                                onGoogleSignInClicked(
                                    context = context,
                                    credentialManager = credentialManager,
                                    onAuthSuccess = {
                                        isSigningIn = false
                                        onAuthSuccess()
                                    },
                                    onAuthError = { msg ->
                                        isSigningIn = false
                                        localError = msg
                                    },
                                    scope = scope,
                                    onAuthCancelled = {
                                        isSigningIn = false
                                    }
                                )
                            },
                            enabled = !isSigningIn,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("google_sign_in_button")
                        ) {
                            if (isSigningIn) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(Icons.Filled.Shield, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.size(8.dp))
                                Text("Sign in with Google")
                            }
                        }
                    }
                }
            } else if (needsBootstrap) {
                BootstrapAdminCard(
                    errorMessage = errorMessage,
                    onInitializeAdmin = onInitializeAdmin,
                    onRegisterPending = onRegisterPending,
                    onSignOut = onSignOut
                )
            } else if (userAccount != null && (userAccount.sessionRevoked || userAccount.statusEnum == AccountStatus.SUSPENDED)) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AlertCriticalContainer),
                    border = BorderStroke(1.dp, AlertCritical)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Filled.Block, contentDescription = "Access Revoked", tint = AlertCritical)
                            Text(
                                text = "Access Suspended / Revoked",
                                style = MaterialTheme.typography.titleMedium,
                                color = AlertCritical,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = userAccount.revokedReason?.takeIf { it.isNotBlank() }
                                ?: "Your account session has been revoked or suspended by a Situation Room administrator. Contact your LGA Super Admin or Full Control Admin.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = AlertCritical
                        )
                        Button(
                            onClick = onSignOut,
                            colors = ButtonDefaults.buttonColors(containerColor = AlertCritical),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("revoked_sign_out_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                            Spacer(modifier = Modifier.size(8.dp))
                            Text("Sign Out & Clear Session")
                        }
                    }
                }
            } else {
                // Pending Approval / Unassigned role
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = WhiteBackground),
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Filled.HourglassTop, contentDescription = "Pending Approval", tint = CivicGold)
                            Text("Awaiting Operational Authorization", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
                        }
                        Text(
                            text = "Account ${userAccount?.email ?: ""} is registered as Pending Approval. A Full Control Admin or LGA Super Admin must activate your account and assign your Role, LGA, Ward, or Polling Unit before operational data is accessible.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondaryLight
                        )
                        if (!errorMessage.isNullOrBlank()) {
                            Text(errorMessage, style = MaterialTheme.typography.bodySmall, color = AlertCritical)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = onRefreshProfile,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("refresh_approval_button")
                            ) {
                                Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.size(6.dp))
                                Text("Refresh")
                            }
                            OutlinedButton(
                                onClick = onSignOut,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("pending_sign_out_button")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.size(6.dp))
                                Text("Sign Out")
                            }
                        }
                    }
                }
            }

            Text(
                text = "Funtua (11 Wards · 298 PUs) · Dandume 20/07 (11 Wards · 177 PUs)",
                style = MonoCodeStyle,
                color = TextSecondaryLight,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun BootstrapAdminCard(
    errorMessage: String?,
    onInitializeAdmin: (String, String?) -> Unit,
    onRegisterPending: (String, String?) -> Unit,
    onSignOut: () -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = WhiteBackground),
        border = BorderStroke(1.dp, EmeraldPrimary)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, tint = EmeraldPrimary)
                Text("Initial Situation Room Setup", style = MaterialTheme.typography.titleMedium, color = EmeraldDeep)
            }
            Text(
                text = "No Full Control Admin has been configured yet for this database. Enter your operational details to initialize the system securely.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondaryLight
            )
            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it },
                label = { Text("Administrator Full Name") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("bootstrap_name_input")
            )
            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Operational Phone (Optional)") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("bootstrap_phone_input")
            )
            if (!errorMessage.isNullOrBlank()) {
                Text(errorMessage, style = MaterialTheme.typography.bodySmall, color = AlertCritical)
            }
            Button(
                onClick = { onInitializeAdmin(fullName, phone.takeIf { it.isNotBlank() }) },
                enabled = fullName.trim().length >= 2,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("bootstrap_admin_button")
            ) {
                Text("Initialize Full Control Admin")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { onRegisterPending(fullName.ifBlank { "Field User" }, phone.takeIf { it.isNotBlank() }) },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Register as Field User")
                }
                OutlinedButton(
                    onClick = onSignOut,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Sign Out")
                }
            }
        }
    }
}
