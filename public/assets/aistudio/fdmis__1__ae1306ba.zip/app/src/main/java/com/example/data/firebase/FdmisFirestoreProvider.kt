package com.example.data.firebase

import android.content.Context
import com.example.R
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings

object FdmisFirestoreProvider {
    @Volatile
    private var configured = false

    fun getInstance(context: Context): FirebaseFirestore {
        val appCtx = context.applicationContext
        val dbId = appCtx.getString(R.string.firestore_database_id)
        val db = FirebaseFirestore.getInstance(dbId)
        if (!configured) {
            synchronized(this) {
                if (!configured) {
                    runCatching {
                        val settings = FirebaseFirestoreSettings.Builder()
                            .setLocalCacheSettings(
                                PersistentCacheSettings.newBuilder()
                                    .setSizeBytes(100L * 1024L * 1024L)
                                    .build()
                            )
                            .build()
                        db.firestoreSettings = settings
                    }
                    configured = true
                }
            }
        }
        return db
    }
}
