package com.example.data.local

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import com.example.data.firebase.FdmisFirestoreProvider
import com.example.data.firebase.OperationsRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * OS-scheduled background sync service triggered by JobScheduler whenever network returns,
 * using exponential backoff and server reachability verification.
 */
class OfflineSyncJobService : JobService() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onStartJob(params: JobParameters?): Boolean {
        val currentUser = Firebase.auth.currentUser
        if (currentUser == null) {
            jobFinished(params, false)
            return false
        }

        serviceScope.launch {
            val db = FdmisDatabase.getInstance(applicationContext)
            val dao = db.offlineQueueDao()
            val cachedProfile = dao.getCachedUser(currentUser.uid)?.toUserAccount()
            val pending = dao.getAllQueuedForSync(currentUser.uid)
            if (cachedProfile == null || !cachedProfile.isAuthorizedActive || pending.isEmpty()) {
                jobFinished(params, false)
                return@launch
            }

            val firestore = FdmisFirestoreProvider.getInstance(applicationContext)
            val opsRepo = OperationsRepository(firestore, dao)
            val puMap = dao.getCachedPollingUnits(currentUser.uid)
                .map { it.toPollingUnit() }
                .associateBy { it.id }

            val summary = opsRepo.syncPendingOfflineQueueDetailed(
                actor = cachedProfile,
                pollingUnitsById = puMap,
                forceRetryIgnoredBackoff = false
            )
            if (summary.syncedCount > 0) {
                SessionPreferences(applicationContext).recordSuccessfulSync(currentUser.uid)
            }
            val needsReschedule = dao.getAllQueuedForSync(currentUser.uid).isNotEmpty()
            jobFinished(params, needsReschedule)
        }
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean {
        return true
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    companion object {
        private const val JOB_ID = 202708

        fun schedule(context: Context) {
            val appCtx = context.applicationContext
            val scheduler = appCtx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as? JobScheduler ?: return
            val component = ComponentName(appCtx, OfflineSyncJobService::class.java)
            val jobInfo = JobInfo.Builder(JOB_ID, component)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setBackoffCriteria(15_000L, JobInfo.BACKOFF_POLICY_EXPONENTIAL)
                .build()
            runCatching { scheduler.schedule(jobInfo) }
        }
    }
}
