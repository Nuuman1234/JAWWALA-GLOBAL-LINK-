package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val WhiteModeColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color.White,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = OnEmeraldContainer,
    secondary = SlateNeutral,
    onSecondary = Color.White,
    secondaryContainer = SlateContainer,
    onSecondaryContainer = OnSlateContainer,
    tertiary = CivicGold,
    onTertiary = Color.White,
    tertiaryContainer = CivicGoldContainer,
    onTertiaryContainer = OnCivicGoldContainer,
    background = WhiteBackground,
    onBackground = TextPrimaryLight,
    surface = WhiteBackground,
    onSurface = TextPrimaryLight,
    surfaceVariant = SoftGreySurface,
    onSurfaceVariant = TextSecondaryLight,
    surfaceContainerLowest = WhiteBackground,
    surfaceContainerLow = SoftGreySurface,
    surfaceContainer = SoftGreySurface,
    surfaceContainerHigh = SoftGreyVariant,
    outline = BorderLight,
    outlineVariant = BorderLight,
    error = AlertCritical,
    onError = Color.White,
    errorContainer = AlertCriticalContainer,
    onErrorContainer = Color(0xFF7F1D1D)
)

val FdmisShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

/**
 * Enforces White Mode Only as the sole active visual theme regardless of OS dark mode preference.
 */
@Composable
fun FdmisTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = WhiteModeColorScheme,
        typography = FdmisTypography,
        shapes = FdmisShapes,
        content = content
    )
}
